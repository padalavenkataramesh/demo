import React, { Fragment } from "react";
import { BrowserRouter as Router, Route, Switch, } from "react-router-dom";

import checkCors from "./components/checkCors";

function App() {
  return (
    <Router>
      <Fragment>
      
        <Switch>
          <Route path="/" exact component={checkCors} />         
        </Switch>
    
      </Fragment>
    </Router>
  );
}

export default App;
