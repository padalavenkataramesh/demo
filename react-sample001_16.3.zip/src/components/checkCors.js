import React from "react";
import axios from "axios";

export default class checkCors extends React.Component {
  componentDidMount() {
    axios
      .get("/api/decks/?page=1&page_size=1")
      .then(function(response) {
        console.log("Response fetching Fine..");
        console.log(response && response.data);
        console.log("Status Code: - " + response.status);
        alert("Status Code: - " + response.status);
      })
      // .catch(function(error) {
      //   console.log("Response fetching Errors..");
      //   console.log(error);
      //   console.log("Status Code: - " + error.response.status);
      //   alert("Status Code: - " + error.response.status);
      // });
  }

  render() {
    return (
      <div>Please check developer console for URL response getting or not.</div>
    );
  }
}
