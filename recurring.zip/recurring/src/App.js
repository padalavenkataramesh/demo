/* eslint-disable no-undef */
import React, { useState } from 'react';
import './App.css';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import TextField from '@mui/material/TextField';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import Button from '@mui/material/Button';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import TheaterComedyIcon from '@mui/icons-material/TheaterComedy';
import Check from '@mui/icons-material/Check';
import ListAltIcon from '@mui/icons-material/ListAlt';
import LocalDiningIcon from '@mui/icons-material/LocalDining';
import PeopleIcon from '@mui/icons-material/People';
import CelebrationIcon from '@mui/icons-material/Celebration';
import CommuteIcon from '@mui/icons-material/Commute';

function App() {

  const [type, setType] = useState('');
  const [openTime, setOpenTime] = useState(false);
  const [totime, setTotime] = useState('');
  const [openToTime, setOpenToTime] = useState(false);
  const [time, setTime] = useState('');
  const [open, setOpen] = useState(false);
  const [showCheckIcon, setShowCheckIcon] = useState(false);
  const [text, setText] = useState('');
  const handleInputChange = (event) => {
    const { value } = event.target;
    // Check if the input value exceeds the maximum length
    if (value.length <= 40) {
      setText(value);
    }
  };
  const handleChangeTime = (event) => {
    setTime(event.target.value);
  };

  const handleCloseTime = () => {
    setOpenTime(false);
  };

  const handleOpenTime = () => {
    setOpenTime(true);
  };
  const handleChange = (event) => {
    const selectedValue = event.target.value;

    // Check if the selected option should show the checkbox icon
    const shouldShowCheckIcon = selectedValue === 'option1' || selectedValue === 'option2';

    setType(selectedValue);
    setShowCheckIcon(shouldShowCheckIcon);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleOpen = () => {
    setOpen(true);
  };
  const handleChangeTo = (event) => {
    setTotime(event.target.value);
  };

  const handleCloseTo = () => {
    setOpenToTime(false);
  };

  const handleOpenTo = () => {
    setOpenToTime(true);
  };
  const options = [
    { label: 'Event', value: 'option1', icon: <TheaterComedyIcon color='success' fontSize="medium" /> },
    { label: 'Celebration', value: 'option2', icon: <CelebrationIcon color='success' fontSize="medium" /> },
    { label: 'Trip', value: 'option3', icon: <CommuteIcon color='success' fontSize="medium" /> },
    { label: 'With caregiver(s)', value: 'option4', icon: <PeopleIcon color='success' fontSize="medium" /> },
    { label: 'Meal', value: 'option5', icon: <LocalDiningIcon color='success' fontSize="medium" /> },
    { label: 'Playtime', value: 'option6', icon: <TheaterComedyIcon color='success' fontSize="medium" /> },
    { label: 'Other', value: 'option7', icon: <ListAltIcon color='success' fontSize="medium" /> },
  ];
  const weeks = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
  const timeZoon = ['10:30', '10:45', '11:00', '11:15', '11:30', '11:45', '12:00', '12:15', '12:30', '12:45', '1:00', '2:15', '2:30']
  const ITEM_HEIGHT = 48;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
      },
    },
  };
  return (
    <div className='flexCol fullHeight alignCntr justifyCntr '>
      <div className='mainCntr whiteBg pdngMD brdrRadiusSM'>
        <div className='flexRow'>
          <div className='flexMinWidthRow'>
            <h2 className='pdngHSM'>
              New recurring activity
            </h2>
          </div>
          <div className='flexAutoRow'>
            <IconButton
              aria-label="more"
              id="long-button"
              aria-haspopup="true"
              color='success'
            >
              <CloseIcon />
            </IconButton>
          </div>
        </div>
        <div className='flexRow'>
          <div className='flexGrow flexCol pdngSM'>
            <span className='pdngVXS'>Title *</span>
            <TextField color='success' inputProps={{ maxLength: 40 }} onChange={handleInputChange} value={text} id="outlined-basic" InputLabelProps={{ shrink: false }} placeholder="Optional description" variant="outlined" />
            <span className='pdngVXXS'>{40 - text.length} characters remaining</span>
          </div>
          <div className='flexGrow pdngSM'>
            <FormControl color='success' fullWidth>
              <span className='pdngVXS'>Type </span>
              <Select
                labelId="demo-controlled-open-select-label"
                id="demo-controlled-open-select"
                open={open}
                onClose={handleClose}
                displayEmpty
                onOpen={handleOpen}
                value={type}
                onChange={handleChange}
                inputProps={{ 'aria-label': 'Without label' }}
              >
                {options.map((option, index) => (
                  <MenuItem key={index} value={option.value}>
                    <div className='flexRow'>
                      <div className='flexAutoRow'>
                        {option.icon}
                      </div>
                      <div className='flexMinWidthRow pdngHSM'>
                        {option.label}
                      </div>
                      {type === option.value && (
                        <div className='flexAutoRow'>
                          <Check color='success' fontSize="medium" />
                        </div>
                      )}
                    </div>
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

          </div>
          {/* </form> */}

        </div>
        <div className='flexCol pdngSM'>
          <span className='pdngBSM'>Description</span>
          <TextField color='success' id="outlined-basic" InputLabelProps={{ shrink: false }} placeholder="Optional description" variant="outlined" />
        </div>
        <span className='pdngSM'>Time</span>
        <div className='flexRow  alignCntr'>
          <div className='flexAutoCol pdngSM'>

            <FormControl color='success' sx={{ width: 200 }}>
              <Select
                labelId="demo-controlled-open-select-label"
                id="demo-controlled-open-select"
                open={openTime}
                onClose={handleCloseTime}
                displayEmpty
                onOpen={handleOpenTime}
                value={time}
                MenuProps={MenuProps}
                onChange={handleChangeTime}
                inputProps={{ 'aria-label': 'Without label' }}
              >
                {
                  timeZoon.map((timeZoon, index) => (
                    <MenuItem value={20}>

                      <div className='flexRow' key={index} value={timeZoon}>
                        <div className='flexMinWidthRow pdngHSM'>
                          {timeZoon}
                        </div>
                        <div className='flexAutoRow'>
                          <Check color='success' fontSize="medium" />
                        </div>
                      </div>
                    </MenuItem>))}
              </Select>
            </FormControl>
          </div>
          <div className='flexAutoRow pdngHSM'><span className='pdngVXS' >to</span></div>
          <FormControl color='success' sx={{ width: 200 }}>
              <Select
                labelId="demo-controlled-open-select-label"
                id="demo-controlled-open-select"
                open={openToTime}
                onClose={handleCloseTo}
                displayEmpty
                onOpen={handleOpenTo}
                value={time}
                MenuProps={MenuProps}
                onChange={handleChangeTo}
                inputProps={{ 'aria-label': 'Without label' }}
              >
                {
                  timeZoon.map((timeZoon, index) => (
                    <MenuItem value={20}>

                      <div className='flexRow' key={index} value={timeZoon}>
                        <div className='flexMinWidthRow pdngHSM'>
                          {timeZoon}
                        </div>
                        <div className='flexAutoRow'>
                          <Check color='success' fontSize="medium" />
                        </div>
                      </div>
                    </MenuItem>))}
              </Select>
            </FormControl>

        </div>
        <div className='flexRow pdngHSM'>
          <FormControlLabel color='success' control={<Checkbox color='success' defaultChecked />} label="All day" />
        </div>
        <div className='flexCol pdngSM'>
          <h4>Repeat every</h4>
          <div className='flexRow pdngVSM'>
            {weeks.map((day, index) => (
              <div className='flexAutoRow pdngHXXS' key={index} value={day}>
                <div className='flexInline alignCntr justifyCntr mediaBtns'>
                  {day}
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className='flexRow pdngSM mrgnTSM justifyEnd brdrTop'>
          <div className='flexInline mrgnTSM mrgnRSM'>
            <Button variant="outlined" color='success' >Cancel</Button>
          </div>
          <div className='flexInline mrgnTSM mrgnRSM'>
            <Button variant="contained" color='success'>Add</Button>
          </div>
        </div>
      </div>

    </div>
  );
}

export default App;
