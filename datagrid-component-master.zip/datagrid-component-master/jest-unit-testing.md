﻿### Setting up Jest Unit Testing

Let’s initialize our new project:
    `npm init`
   Now let’s go ahead and install the packages that we are going to use.In this example we are going to write unit tests in typescript.
`npm install --save-dev jest ts-jest @types/jest`

jest - This is what we’re going to use to test the logic of our program.
ts-jest - is a TypeScript preprocessor with source map support for Jest that lets you use Jest to test projects written in TypeScript.
@types/jest - This package contains type definitions for Jest 

Please add types for jest in index.d.ts in typings folder if you are using ts file to write unit tests.
/// <reference path="<path>" />
Ex:
----
/// <reference path="../node_modules/@types/jest/index.d.ts" />


Create a file jest.config.js in root folder of project.
####
    module.exports = {
        globals: {
            'ts-jest': {
                diagnostics: false
              }
        },
        preset: 'ts-jest',
        verbose: true,    
        testRegex: "(/tests/.*|\\.(test|spec))\\.(ts|tsx|js)$",
        moduleFileExtensions: ["ts", "tsx", "js"]
    };

preset - A preset that is used as a base for Jest's configuration. A preset should point to an npm module that has a jest-preset.json or jest-preset.js file at the root.Here we are telling compiler to use ts-jest inside node_modules folder.

Create a file called “sum.ts” and insert the following code:
####
    class Sum {
      Add(a, b) {
        return a + b;
      }
    }
    
    export default Sum;`
Now, go ahead and create a file called “sum.test.js”.
#### 
    import Sum from './sum';
    var sum:any = new Sum();
    
    describe('Sum', () => {
        test('adds 1 + 2 to equal 3', () => {  
        expect(sum.Add(1, 2)).toBe(3);
      });
    })

In your “package.json” insert the following script:

"scripts": {
  "test": "jest --watch"
}

Then execute it from the command line like so:

`npm test`

You should be able to see output in command line.









