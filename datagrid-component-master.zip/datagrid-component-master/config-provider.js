requirejs(['require-config'], function (common) {
  requirejs(['demos/config-provider/config-provider.js']);
});
