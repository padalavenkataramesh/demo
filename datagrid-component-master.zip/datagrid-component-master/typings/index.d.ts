/// <reference path="globals/jquery/index.d.ts" />
/// <reference path="../node_modules/@types/jest/index.d.ts" />
/// <reference path="../node_modules/@types/node/index.d.ts" />
