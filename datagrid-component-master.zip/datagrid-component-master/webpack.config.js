const path = require('path');

module.exports = {
  mode: 'production',
  // target: 'node',
  optimization: {
    minimize: true
  },
  watch: true,
  // devtool: 'source-map',
  entry: {
    'datagrid': ['./node_modules/@webcomponents/custom-elements/src/native-shim.js','./node_modules/aux-spinner/dist/spinner.js','./src/component/datagrid.ts'],
  },
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: '[name].js'
  },
  module: {
    rules: [{
      test: /\.tsx?$/,
      use: 'ts-loader',
      exclude: /node_modules/
    },
    {
      test: /\.html?$/,
      use: 'html-loader',
      exclude: /node_modules/
    }
  ]
  },
  resolveLoader: {
    alias: {
      // Support for require('text!file.json').
      text: 'text-loader',
      //html: 'html-loader'
      //'text-loader': './node_modules/text-loader'
    }
  },
  resolve: {
    extensions: ['.tsx', '.ts', '.js'],
    modules: ['node_modules'],
    alias: {
      // jquery: path.resolve(__dirname, './lib/jquery.js'),
      // devExpress: path.resolve(__dirname, './lib/dx.dev.js')
    }
  }
};