requirejs(['require-config'], function (common) {
    requirejs(['demos/remote-data/remote-data-example.js']);
});
  