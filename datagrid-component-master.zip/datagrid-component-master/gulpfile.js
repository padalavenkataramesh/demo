const { src, dest, parallel, series, watch } = require('gulp');
const rename = require('gulp-rename');
const gulpsass = require('gulp-sass');
const concat = require('gulp-concat');

const webpack = require('webpack');
const webpackConfig = require('./webpack.config.js');
const typescript = require('gulp-typescript');
const tsProject = typescript.createProject('tsconfig.json'); 

/* Directories here */
var paths = {
    dist: './dist/',
    scss: './styles/**/*.scss',
    ts: './src/**/*.ts',
    node_modules : './node_modules',
    bower_components : './bower_components'
};

function ts() {
    return tsProject.src()
        .pipe(tsProject()).js.pipe(dest(function (file) {
            return file.base;
        }));
}

function tsWatch(){
    watch(paths.ts, series('ts'));
}

function sass() {
    return src(['./styles/dx-styles.scss', './styles/grid.scss', './styles/button-styles.scss', './styles/menu-styles.scss', './styles/dropdown-styles.scss', './styles/pager-styles.scss', './styles/popup-styles.scss', './styles/settings.scss', './styles/simple-settings.scss', './styles/advanced-filter.scss', './styles/styles.scss', './styles/dx-custom-icons.scss', './node_modules/aux-spinner/styles/spinner.scss'])
        .pipe(concat('default.scss'))
        .pipe(gulpsass({
            //outputStyle: 'compressed',
            includePaths: [paths.node_modules, paths.bower_components],
        }).on('error', gulpsass.logError))
        .pipe(rename('_datagrid.css'))
        .pipe(dest('./dist'));
}

function sassWatch(){
    return watch(paths.scss, series('sass'));
}

function js(done){
    webpack(webpackConfig).run();
    done();
}  

exports.ts = ts; 
exports['ts:watch'] = tsWatch;
exports.sass = sass;
exports['sass:watch'] = sassWatch;
exports.js = js;

exports.watch = parallel(tsWatch, sassWatch);
exports.build = series(ts, js, sass);
exports.dist = series(ts, js, sass);
exports.default = series(ts, js, sass);
