 export class Component{
     constructor(options){
        if('registerElement' in document){
            (<any>document)!.registerElement(options.name, options.controller);
        } else if('customElements' in window && 'define' in window.customElements){
            window.customElements.define(options.name, options.controller);
        }  
      }
 }
 export default Component;