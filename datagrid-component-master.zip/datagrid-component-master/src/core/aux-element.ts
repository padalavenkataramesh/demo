export class EventData {
  bubbles: boolean = true;
  composed: boolean = true;
  cancelable: boolean = true;
  detail: any = null;
}

export interface AUXElementBaseController{
    onInit();
    onRender();
    onConnected();
    onAttributeChanged(attrName: string, oldVal, newVal);
    onDisconnected();
}

export class AUXElement extends HTMLElement{
  _element: any;
  _$element: any;
  _view: any;
  private _isInitialized: boolean;
  private _isConnected: boolean;
  get isInitialized() {
    return this._isInitialized;
  }
  get isConnected() {
    return this._isConnected;
  }
  _attributes: any;
  _events: object;
  // static get observedAttributes() {
  //   return [];
  // }
  constructor(options?) {
    super();
    this._onInit();
  }
  protected showDeprecationWarningFor(tagName: string, newTagName: string) {
    if (this.tagName.toLocaleLowerCase() === tagName.toLocaleLowerCase()) {
      console.warn(
        "[Deprecation] Consider using '" +
          newTagName +
          "' tag in place of '" +
          tagName +
          "'. We would be deprecating '" +
          tagName +
          "' tag in our next major release, API would remain same for both tags. For updates follow https://github.build.ge.com/APM-UI-Extensions/asset-component/wiki ."
      );
    }
  }
  createdCallback() {
    this._onInit();
  }
  private _onInit(): void {
    let view: any = this.onRender();
    // $(this)
    //   .empty()
    //   .append(view);
    this._view = $('<div/>').addClass('aux-element-container').css('height','auto').append(view)[0];
    this._element = this._view;
    this._$element = $(this);
    this.registerProperties();
    this.onInit();
    this._isInitialized = true;
  }
  protected _getProperties(){
      return {};
  }
  protected onRender(): any {
    return "";
  }
  private registerProperties() {
      let props:PropertyDescriptorMap = this._getProperties();
    return props && Object.defineProperties(this, props);
  }
  protected onInit() {}
  attachedCallback() {
    this._onConnected();
  }
  public connectedCallback() {
    this._onConnected();
  }
  private _upgradeProperties(props?: Array<string>) {
    let propsMap: Array<string> = props || Object.keys(this['_properties']);
    for (const prop of propsMap) {
      this._upgradeProperty(prop);
    }
  }
  private _upgradeProperty(prop: string): void {
    if (this.hasOwnProperty(prop)) {
      let value = this[prop];
      delete this[prop];
      this[prop] = value;
    }
  }
  private _onConnected(): void {
    //this._upgradeProperties();
    $(this)
      //.empty()
      .append(this._view);
    this._element = this;
    this._$element = $(this._$element);
    this.onConnected();
    this._isConnected = true;
  }
  protected onConnected() {}
  attributeChangedCallback(attrName: string, oldVal, newVal) {
    this.onAttributeChanged(attrName, oldVal, newVal);
  }
  protected onAttributeChanged(attrName: string, oldVal, newVal) {}
  detachedCallback() {
    this._onDisconnected();
  }
  public disconnectedCallback() {
    this._onDisconnected();
  }
  private _onDisconnected(): void {
    this.onDisconnected();
  }
  protected onDisconnected() {}
  protected dispatchCustomEvent(evName: string, data?: any) {
    var evData: EventData = new EventData();

    if (data !== undefined) {
      evData.detail = data;
    }

    var event = new CustomEvent(evName, evData);
    this._element.dispatchEvent(event);
  }
}
export default AUXElement;