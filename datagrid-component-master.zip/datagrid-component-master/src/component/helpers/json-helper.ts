/// <reference path="../../../node_modules/devextreme/dist/ts/dx.all.d.ts" />
 
import Utils from "../helpers/utils";
import Converter  from "../core/converter";
const converter = new Converter();
const utils:any = new Utils();

class JsonHelper extends Utils{

    public preSelectRows (self: any, data: any) {
        try {
            var dataGrid = self.getGridInstance();
            if (dataGrid) {
                dataGrid.selectRows(data, false);
            }
        }
        catch (e) {

        }
    }

    public handleCellPrepared (self: any, dataObject: any) {
        utils.handleCellPrepared(self, dataObject);
    }

    public handleInitNewRow (self: any, container: any, options: any) {        
        utils.tryMethod(self, 'onInitNewRowCallback', container, options);
    }

    public handleRowPrepared(self: any, dataObject: any){
        if (dataObject.rowType !== 'data') {
            return;
        }        
        utils.tryMethod(self, 'rowPreparedCallback', dataObject.cellElement, dataObject);
    }

    public handleContentReadyActionForJSON (self: any, onContentReady:any, e: any) {
        utils.highlightGroupingContainer(self);
        utils.replaceGroupIcons(self, e);    
        utils.toggleSearchPanelVisible(self, self.$element, self.showSearchPanel);
        if(self.enableMasterDetail){
            _.delay(function(){
                utils.contentReadyActionForJSONHelper(self, onContentReady, e);
            }, 100);
        } else{
            utils.contentReadyActionForJSONHelper(self, onContentReady, e);
        }
    }

    public handleSelectionChangeForJsonWithoutColumns (self, selecteditems) {
        var data;
        if (self.selectionMode === 'single') {
            data = selecteditems && selecteditems.selectedRowsData[0];
            utils.tryMethod(self, 'singleSelectCallback', data);
        }
        else {            
            data = selecteditems.selectedRowsData;
            utils.tryMethod(self, 'multiSelectCallback', data);
        }
    }

    public handleEditingStart (self, container) {
        utils.tryMethod(self, 'onEditingStart', container);
    } 
    
    public handleRowInserting (self, data) {        
        utils.tryMethod(self, 'onRowInsertingCallback', data);
    }     

    public handleRowUpdating (self, data) {
        utils.tryMethod(self, 'onRowUpdatingCallback', data);
    } 

    public handleRowRemoving (self, data) {
        utils.tryMethod(self, 'onRowRemovingCallback', data);
    } 

    public getColumnsFromData (self, data) {
        const cols: any = [];
        for (var i = 0; i < data.columns.length; i++) {
            const column = _.extend({}, data.columns[i]) || {};
            column.dataField = data.columns[i].dataField || data.columns[i].id;
            if (data.columns[i].alias !== undefined && data.columns[i].alias !== '') {
                column.caption = data.columns[i].alias;
            }
            else if (!column.caption) {
                column.caption = data.columns[i].id;
            }
           

            if (data.columns[i].cellTemplate !== undefined ) {
                column.cellTemplate = data.columns[i].cellTemplate;
            }

            if (data.columns[i].headerCellTemplate !== undefined) {
                column.headerCellTemplate = data.columns[i].headerCellTemplate;
            }

            if (data.columns[i].customizeText !== undefined ) {
                column.customizeText = data.columns[i].customizeText;
            }

            if (data.columns[i].editCellTemplate !== undefined ) {
                column.editCellTemplate = data.columns[i].editCellTemplate;
            }

            column.encodeHtml = true;
            if (data.columns[i].encodeHtml !== undefined) {
                column.encodeHtml = converter.toBoolean(data.columns[i].encodeHtml, true);
            }

            this.assignProperty(data.columns[i], column, 'precision');
            this.assignProperty(data.columns[i], column, 'format');
            this.assignProperty(data.columns[i], column, 'cssClass');
            this.assignProperty(data.columns[i], column, 'alignment');
            this.assignProperty(data.columns[i], column, 'width');
            this.assignProperty(data.columns[i], column, 'allowFiltering', converter.toBoolean(data.columns[i].allowFiltering, 'true'));
            this.assignProperty(data.columns[i], column, 'allowEditing', converter.toBoolean(data.columns[i].allowEditing, 'true'));
            this.assignProperty(data.columns[i], column, 'fixed', converter.toBoolean(data.columns[i].fixed, 'true'));
            this.assignProperty(data.columns[i], column, 'visible', converter.toBoolean(data.columns[i].visible, true));
            this.assignProperty(data.columns[i], column, 'allowSorting', converter.toBoolean(data.columns[i].allowSorting, true));

            //handling column datasource selection
            if (data.columns[i].lookup !== undefined && data[data.columns[i].lookup.dataSource]) {
                column.lookup = $.extend({}, data.columns[i].lookup);
                column.lookup.dataSource = data[data.columns[i].lookup.dataSource];
            }

            cols.push(column);
        }
        return cols;
    };


    assignProperty(obj1: any, obj2: any, prop: any, value: any = '') {
        if (obj1[prop] !== undefined) {
            obj2[prop] = arguments.length === 4 ? value : obj1[prop];
        }
    }

}

export default JsonHelper;