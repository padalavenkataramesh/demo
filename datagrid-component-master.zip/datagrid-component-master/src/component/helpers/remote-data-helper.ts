import Utils from "./utils";

var utils = new Utils();


class RemoteDataHelper{

    public handleRowInserting (self, data) {        
        utils.tryMethod(self, 'onRowInsertingCallback', data);
    }     

    public handleRowUpdating (self, data) {
        utils.tryMethod(self, 'onRowUpdatingCallback', data);
    } 

    public handleRowRemoving (self, data) {
        utils.tryMethod(self, 'onRowRemovingCallback', data);
    }     

    public handleCellPreparedForRemoteData(self, remoteDataHelper, dataObject) {
        utils.handleCellPrepared(self, dataObject);
    }

    public handleInitNewRow (self: any, container: any, options: any) {        
        utils.tryMethod(self, 'onInitNewRowCallback', container, options);
    }

    public handleContentReadyAction(self, options) {
        utils.highlightGroupingContainer(self);
        utils.replaceGroupIcons(self, options);
        utils.toggleSearchPanelVisible(self, self.$element, self.showSearchPanel);        
        var dataGridInstance = self.getGridInstance();
        self.gridInstance = dataGridInstance;
        utils.updateView(self);        
        utils.updateTotalCountMessage(self, options);
        utils.updateRowSelectionCount(self, dataGridInstance.getSelectedRowsData().length);
        utils.tryMethod(self, 'gridLoadedCallback', dataGridInstance, options);
        if(self.selectAllMode === 'allPages'){
            utils.handleSelectAll(self);   
        }
    }    

    public handleRowPrepared(self: any, dataObject: any){
        if (dataObject.rowType !== 'data') {
            return;
        }        
        utils.tryMethod(self, 'rowPreparedCallback', dataObject.cellElement, dataObject);
    }

}
export default RemoteDataHelper;
