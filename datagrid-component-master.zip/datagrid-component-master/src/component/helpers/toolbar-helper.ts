import Utils from "./utils";

const utils = new Utils();

class ToolbarHelper extends Utils {

    public renderToolbarButtons(self, e, loadButtons) {
        var i, element;

        if (!self.buttons) {
            self.buttons = [];
        }
        self.toolbarOptions = e.toolbarOptions;
        if(loadButtons && loadButtons.length ){            
            let loadButtonsArray = loadButtons;
            loadButtonsArray = self.toolbarHelper.extendButtonsArray(self, loadButtonsArray);
            
            self.buttons = loadButtonsArray;
            for (i = 0; i < self.buttons.length; i++) {
                element = self.buttons[i];

                if (element.type === "more-options") {
                    this.createMoreOptions(self, element, e);
                }
                else if(element.type === 'customhtml'){
                    this.renderCustomHTML(self, element, e);
                }
                else if (element.text) {
                    this.createTextButton(self, element, e);
                } else {
                    this.createIconButton(self, element, e);
                }
            }
        }    
    }

    private extendButtonsArray(self, loadButtonsArray){ //if element disabled, visible already set before element rendered, extending loadbuttons with already set items
        var elem;
        return _.map(loadButtonsArray, (loadButton) =>{
            elem = _.find(self.tempButtons, (btn)=>{ return this.getElement(btn, loadButton);});
            return elem ? _.extend(elem, loadButton) : loadButton;
        });
    }

    private getElement(btn, loadButton){
        return !!btn['btnClass'] && ((!!loadButton.btnClass && loadButton.btnClass.indexOf(btn['btnClass']) >= 0 ) || (!!loadButton.iconClass && loadButton.iconClass.indexOf(btn['btnClass']) >= 0) || (!!loadButton.icon && loadButton.icon.indexOf(btn['btnClass']) >= 0));
    }

    private renderCustomHTML(self, element, e) {
        var customHTML;
        customHTML = {
            location: element.align === 'left' ? 'before' : 'after',
            template: element.content,
            icon: 'icomoon ' +element.iconClass,
            elementAttr: {
                'data-action': element.action,
                class: element.btnClass,
            },
            onItemRendered:element.onItemRendered
        };
        e.toolbarOptions.items.unshift(customHTML);
    }

    private createIconButton(self, btn, e) {
        var button;
        button = {
            //locateInMenu: 'always',
            widget: 'dxButton',
            location: btn.align === 'left' ? 'before' : 'after',
            options: {
                onClick: this.onActionClicked.bind(this, self, btn.action, 'button'),
                disabled: btn.disabled || false,
                elementAttr: {
                    id: btn.btnClass,
                    class: btn.btnClass ? btn.btnClass + " aux-button btn--secondary" : " aux-button btn--secondary",  //btn.iconClass + 
                    'data-action': btn.action,
                    title: btn.title
                },
                icon: 'icomoon ' +btn.iconClass,
                stylingMode : "contained",
                visible: true,
                onContentReady: ((btn, options) => { options.element.attr('data-action', btn.action); }).bind(null, btn)
            }
            
        };
        if(btn.visible === false || btn.visible === "false"){
            button.options.visible = btn.visible;
        } 
        if(this.toolbarButtonIndex(e,button) === -1 ){
            e.toolbarOptions.items.unshift(button);
        }
    }

    private createMoreOptions(self, btn, e) {
        var moreOptionsTextButton = {
            widget: "dxMenu",
            location: btn.align === 'left' ? 'before' : 'after',
            options: {
                visible: true,
                disabled: btn.disabled || false,
                elementAttr: {
                    id: '',
                    class: '',
                    'data-action': ''
                },
                showSubmenuMode: {
                    name: 'onClick',
                },
                items: [{
                    text: '',
                    visible: true,
                    icon: '',
                    items: this.createOptions(self, btn)
                }],
                onItemClick: this.onActionClicked.bind(this, self, btn, 'menu-option')
            }
        };
        if(btn.visible === false || btn.visible === "false"){
            moreOptionsTextButton.options.visible = btn.visible;
        } 
        if(btn.text){
            moreOptionsTextButton.options.items[0].text = btn.text;
            moreOptionsTextButton.options.elementAttr.id = btn.btnClass;
            moreOptionsTextButton.options.elementAttr['data-action'] = btn.action;
            moreOptionsTextButton.options.elementAttr.class = btn.btnClass;
        }
        if (btn.icon) {
            moreOptionsTextButton.options.elementAttr['data-action'] = btn.action;
            moreOptionsTextButton.options.items[0].icon = 'icomoon ' + btn.icon;
        }
        if(btn.iconClass){
            moreOptionsTextButton.options.elementAttr['data-action'] = btn.action;
            moreOptionsTextButton.options.items[0].icon = 'icomoon ' + btn.iconClass;
            // moreOptionsTextButton.options.elementAttr.class = btn.icon;
            // moreOptionsTextButton.options.elementAttr.id = btn.icon;
        }
        if(this.toolbarButtonIndex(e,moreOptionsTextButton) === -1 ){
            e.toolbarOptions.items.push(moreOptionsTextButton);
        }
    }

    private createOptions(self, btn) {
        var i, option, items: any = [];
        for (i = 0; i < btn.options.length; i++) {
            option = btn.options[i];
            items.push({
                text: option.text,
                disabled: typeof(option.disabled) === 'function' ? option.disabled() : option.disabled,
                visible: !!option.noaccess ? false: true,
                elementAttr: {
                    id: option.action,
                    action: option.action
                },
                cssClass: option.action
            });
        }
        return items;
    }

    private createTextButton(self, btn, e) {
        var button;
        button = {
            widget: 'dxButton',
            location: btn.align === 'left' ? 'before' : 'after',
            options: {
                onClick: this.onActionClicked.bind(this, self, btn.action, 'button'),
                elementAttr: {
                    // id: btn.btnClass,
                    // class: btn.btnClass,
                    // html: btn.text
                    id: btn.btnClass,
                    class: btn.btnClass + " aux-button btn--secondary",
                    'data-action': btn.action,
                    title: btn.title
                },
                disabled: btn.disabled || false,
                text: btn.text,
                visible: true,
                stylingMode: "contained",
                onContentReady: ((btn, options) => { options.element.attr('data-action', btn.action); }).bind(null, btn)
            }
        };
        if(btn.visible === false || btn.visible === "false"){
            button.options.visible = btn.visible;
        }
        // if(btn.iconClass) {
        //     button.options.icon = 'icomoon ' + btn.iconClass;
        // } 
        if(this.toolbarButtonIndex(e,button) === -1 ){
            e.toolbarOptions.items.unshift(button);
        }
    }


    private buttonIndex(self, button) {
        return _.findIndex(self.buttons, function (btn) {
            return btn.options && btn.options.elementAttr && btn.options.elementAttr.class && btn.options.elementAttr.class.trim() === button.options.elementAttr.class && button.options.elementAttr.class.trim();
        });
    }

    private toolbarButtonIndex(e, button) {
        return _.findIndex(e.toolbarOptions.items, function (btn) {
            return btn.options && btn.options.elementAttr && btn.options.elementAttr.class && btn.options.elementAttr.class.trim() === button.options.elementAttr.class && button.options.elementAttr.class.trim();
        });
    }

    private buttonAlreadyExists(self, button) {
        return _.find(self.buttons, function (btn) {
            if (btn.options && btn.options.elementAttr && btn.options.elementAttr.class && button.options.elementAttr && btn.options.elementAttr.class.trim() === button.options.elementAttr.class && button.options.elementAttr.class.trim()) {
                return btn;
            }
        });
    }

    private menuAlreadyExists(self, menuButton) {
        return _.find(self.buttons, function (menuBtn) {
            if (menuBtn.options.elementAttr && menuBtn.options.elementAttr.class && (menuButton.btnClass || menuButton.iconClass) && (menuBtn.options.elementAttr.class.trim() === menuButton.btnClass.trim() || menuBtn.options.elementAttr.class.trim() === menuButton.iconClass.trim())) {
                return menuBtn;
            }
        });
    }

    private onActionClicked(self, action, className, data) {
        var action, e = data.event, element;  
           
        if(className === 'menu-option' && !e.target.disabled && data && data.itemData && data.itemData.cssClass){//for menu option clicked
            action = data.itemData.cssClass;
            utils.tryMethod(self, 'toolbarItemClickCallback', action, e);
        } else if(className === 'button'){ //for icons, buttons click handler
            utils.tryMethod(self, 'toolbarItemClickCallback', action, e);
        }      
    }    

    private toolbarButtonClicked(self, action) {
        utils.tryMethod(self, 'toolbarButtonClicked', action);
    }

    private disableButton(self, btnClass, boolValue) { //fired when module sets disable on toolbar element
        var i, buttons = self.buttons, button, element, instance;
        boolValue = !!boolValue;
        if (buttons && buttons.length && self.toolbarHelper.isElemExists(self, btnClass)) { //if element not exists set disabled
            for (i = 0; i < buttons.length; i++) {
                self.toolbarHelper.setActionType(self, buttons[i], 'dx-button', 'disabled', btnClass, boolValue); //for setting disabled on dx-button
                self.toolbarHelper.setActionType(self, buttons[i], 'dx-menu', 'disabled', btnClass, boolValue); //for setting disabled on dx-menu
            }
        }
        else{ //if element not exists add to array
            self.toolbarHelper.addActionToArray(self, 'disabled', btnClass, boolValue);
        }
    }

    private setNoAccess(self, btnClass, boolValue) {
        // self.toolbarHelper.showButton(self, btnClass, !boolValue);
        var i, buttons = self.buttons, button, element, instance;
        //boolValue = !boolValue;
        if (buttons && buttons.length && self.toolbarHelper.isElemExists(self, btnClass)) { //if element not exists set visible
            for (i = 0; i < buttons.length; i++) {
                self.toolbarHelper.setActionType(self, buttons[i], 'dx-button', 'noaccess', btnClass, boolValue); //for setting visible on dx-button
                self.toolbarHelper.setActionType(self, buttons[i], 'dx-menu', 'noaccess', btnClass, boolValue); //for setting visible on dx-menu
            }
        }
        else{ //if element not exists add to array
            self.toolbarHelper.addActionToArray(self, 'noaccess', btnClass, boolValue)
        }

    }

    private showButton(self, btnClass, boolValue) { //fired when module sets show on toolbar element
        var i, buttons = self.buttons, button, element, instance;
        boolValue = !!boolValue;
        if (buttons && buttons.length && self.toolbarHelper.isElemExists(self, btnClass)) { //if element not exists set visible
            for (i = 0; i < buttons.length; i++) {
                self.toolbarHelper.setActionType(self, buttons[i], 'dx-button', 'show', btnClass, boolValue); //for setting visible on dx-button
                self.toolbarHelper.setActionType(self, buttons[i], 'dx-menu', 'show', btnClass, boolValue); //for setting visible on dx-menu
            }
        }
        else{ //if element not exists add to array
            self.toolbarHelper.addActionToArray(self, 'show', btnClass, boolValue)
        }
    }    

    private disableMenuOption(self, menuClass, menuOptionClass, boolValue) {
        boolValue = !!boolValue;
        self.toolbarHelper.setActionTypeForMenu(self, menuClass, menuOptionClass, "disabled", boolValue);
    }

    private showMenuOption(self, menuClass, menuOptionClass, boolValue){
        boolValue = !!boolValue;
        self.toolbarHelper.setActionTypeForMenu(self, menuClass, menuOptionClass, "show", boolValue);
    }

    private setNoAccessForMenuOption(self, menuClass, menuOptionClass, boolValue){
        self.toolbarHelper.setActionTypeForMenu(self, menuClass, menuOptionClass, "noaccess", boolValue);
    }

    private isMenuExists(self,value,type){
        if(type === "buttons"){
            return _.find(self.buttons, function (elem)  { 
                return elem.type && elem.type === "more-options" &&  elem.action && elem.action.indexOf(value) > -1;  
            });
        }
        else{
            return _.find(self.toolbarOptions.items, function (elem)  { 
                return elem.widget && elem.widget === "dxMenu" && elem.options.elementAttr['data-action'] === value;
            });
        }
       
       
    }


    private setActionTypeForMenu(self, menuClass, menuOptionClass, property, boolValue){

        var i, buttons = self.buttons, button, element, instance;
        boolValue = !!boolValue;
        if (buttons && buttons.length && self.toolbarHelper.isMenuExists(self, menuClass, "buttons")) { //if element not exists set disabled

            let menu = self.toolbarHelper.isMenuExists(self, menuClass , "buttons");

            for (i = 0; i < menu.options.length; i++) {
                if(menu.options[i].action && menu.options[i].action.indexOf(menuOptionClass) > -1 ){
                    menu.options[i][property] = boolValue;
                    let noaccess, show, access, visible;
                    noaccess =  menu.options[i]["noaccess"];
                    show =  menu.options[i]["show"];
                    if(property === "noaccess" || property === "show"){
                        access = noaccess === undefined ? true : !noaccess;
                        show = show === undefined ? true : show;
                        visible = access && show;
                        menu.options[i]["visible"] = visible;
                    }
                    break;
                }
            }
        }

        if(self.toolbarOptions.items && self.toolbarOptions.items.length && self.toolbarHelper.isMenuExists(self, menuClass)){
            let menu = self.toolbarHelper.isMenuExists(self, menuClass), menuItems;
            menuItems = menu.options.items[0];
            for (i = 0; i < menuItems.items.length; i++) {
                if(menuItems.items[i].cssClass && menuItems.items[i].cssClass.indexOf(menuOptionClass) > -1 ){
                    menuItems.items[i][property] = boolValue;
                    let noaccess, show, access, visible;
                    noaccess =  menuItems.items[i]["noaccess"];
                    show =  menuItems.items[i]["show"];
                    if(property === "noaccess" || property === "show"){
                        access = noaccess === undefined ? true : !noaccess;
                        show = show === undefined ? true : show;
                        visible = access && show;
                        menuItems.items[i]["visible"] = visible;
                    }
                    break;
                }
            }
            //code for updating dXMenu with updated options
            element = self.$element.find('[data-action="' + menuClass+ '"]');
            instance = element && $(element).dxMenu('instance');
            if(element && instance){
                instance.option('items[0].items', menuItems.items);
                instance.repaint();
            }
        }

    }

   
    public isElemExists(self, value){
        return _.find(self.buttons, function (elem)  { 
            return elem.btnClass && elem.btnClass.indexOf(value) > -1  
        }); 
    }    

    public isTempElemExists(self, value){
        return _.find(self.tempButtons, function (elem)  { 
            return elem.btnClass && elem.btnClass.indexOf(value) > -1  
        }); 
    } 

    private setActionType(self, button, elementType, property, className, boolValue) {// elementType - dx-button, dx-menu, property -disabled, visible
        var element, instance;
        if (self.toolbarHelper.isClassNamePresent(button, className)) {
            element = self.toolbarHelper.findElement(self, elementType, className);
            instance = self.toolbarHelper.getInstance(element, elementType === 'dx-button' ? 'dxButton' : 'dxMenu');
            let noaccess, show, access, visible;
            if (element && instance) {
                instance.option(property, boolValue);
                noaccess = instance.option("noaccess");
                show = instance.option("show");
            } else {
                button[property] = boolValue; //setting control disabled or visible
                noaccess = button["noaccess"];
                show = button["show"];
            }
            
            
            if(property === "noaccess" || property === "show"){
                access = noaccess === undefined ? true : !noaccess;
                show = show === undefined ? true : show;
                visible = access && show;
                if (element && instance) {
                    instance.option("visible", visible);
                } else {
                    button["visible"] = visible;
                }
            }
        }
    }

    private addActionToArray(self, property, btnClass, boolValue){
        var element = self.toolbarHelper.isTempElemExists(self, btnClass);
        if(!element){
            element = { 'btnClass': btnClass, height: '', align: '', action: '', title: '', type: '' };
            element[property] = boolValue; 
            if(!self.tempButtons){
                self.tempButtons =[];
            }
           
            var elem = _.find(self.tempButtons, (btn) => { return btn['btnClass']=== btnClass; });
            elem ? _.extend(elem, element) : self.tempButtons.push(element);
        }
        else {
            element[property] = boolValue; 
        }
        let noaccess, show, access, visible;
        noaccess = element["noaccess"];
        show = element["show"];
        if(property === "noaccess" || property === "show"){
            access = noaccess === undefined ? true : !noaccess;
            show = show === undefined ? true : show;
            visible = access && show;
            element["visible"] = visible;
        }
    }

    private findElement(self, elementType, btnClass) {
        return self.$element.find("." + elementType + "." + btnClass);
    }

    private getInstance(element, controlType){
        return !!element[controlType] && element[controlType]('instance');
    }

    private isClassNamePresent(button, className) {
        return button && ((button.btnClass && button.btnClass.trim().indexOf(className) > -1 ) || (button.iconClass && button.iconClass.trim().indexOf(className) > -1));
    }

}
export default ToolbarHelper;