import Converter from "../core/converter";
const converter = new Converter();

class Utils{

    constructor(){
        
    }

    public handleRowPrepared (self: any, rowElement: any, rowInfo:any) {
        if (rowElement.rowType !== "data") {
            return;
        }
        this.tryMethod(self, 'rowPreparedCallback', rowElement, rowInfo);
    }

    public handleCellTemplateForActionColumn(self: any, container: any, options: any) {
        this.tryMethod(self, 'cellHyperlinkCallback', container, options);
    }

    public handleCustomCellTemplate(self, container, options) {
        this.tryMethod(self, 'cellTemplateCallback', container, options);
    }

    public handleHeaderCellTemplate(self, header, info) {
        this.tryMethod(self, 'headerCellTemplateCallback', header, info);
    }   
    
    public tryMethod(context: any, methodName: string, ...addl: any[]): any{
        const args = Array.prototype.slice.call(arguments, 2);
        if (!this.respondsTo(context, methodName)) {
            return undefined;
        }
        return context[methodName].apply(context, args);
    }

    private respondsTo(context: any, methods: any, throwOnUndefined: boolean = false): boolean {
        if (!_.isArray(methods)) {
            methods = [methods];
        }
    
        for (let i = 0; i < methods.length; i++) {
            if (!_.isFunction(context[methods[i]])) {
                if (throwOnUndefined) {
                    throw ('Required method ' + methods[i] + ' is not defined');
                }
                return false;
            }
        }    
        return true;
    }

    public onOptionChanged(self, obj){        
        if (obj.fullName && obj.fullName.indexOf('groupIndex') > -1) { //grouping columns changed 
            var splitFullName, currentColumnSortedIndex, currentColumn; 
            splitFullName = obj.fullName.split('[');
            currentColumnSortedIndex = parseInt(splitFullName[1].split(']')[0]);

            let gridInstance:any = $(self).find('.gridContainer').dxDataGrid('instance');
            let columns = gridInstance.getController('columns').getColumns(), highestGrpIndx: number = 0;
            let groupdColumns: Array<object> = this.columnsFilterByGroup(columns, true);
            let ungroupdColumns: Array<object> = this.columnsFilterByGroup(columns, false);
            currentColumn = columns[currentColumnSortedIndex];
            if(obj.hasOwnProperty('value') && !isNaN(obj.value)){
                currentColumn.fixed = true;
                currentColumn.fixedPosition = 'left';
                currentColumn.allowReordering = false;
                self.hideSortFromGroupingPanel && (currentColumn.allowSorting = false);
                //group index is the sequence of columns in grouping panel
                
                //below line of code to make sure the sequnce of grouped column(s) in grouping panel and datagrid header should be same.
                groupdColumns.map((column: any)=>column.visibleIndex = column.groupIndex);
                //getting highest group index
                highestGrpIndx = groupdColumns.length - 1;

                ungroupdColumns.map((column: any)=>column.visibleIndex = ++highestGrpIndx);
            } else if(obj.hasOwnProperty('previousValue') && !isNaN(obj.previousValue)){
                currentColumn.fixed = false;
                currentColumn.fixedPosition = '';
                currentColumn.allowReordering = true;
                self.hideSortFromGroupingPanel && (currentColumn.allowSorting = true);
                
                if(groupdColumns.length > 0){
                    groupdColumns.map((column: any)=>column.visibleIndex = column.groupIndex);
                    //getting highest group index
                    highestGrpIndx = groupdColumns.length - 1;
                    ungroupdColumns.map((column: any)=>column.visibleIndex = ++highestGrpIndx);
                }
                else{
                    // when grouping panel is empty, column sequence would be default
                    ungroupdColumns.map((column: any)=>column.visibleIndex = column.index);
                }
            }
        }
        this.tryMethod(self, 'onOptionChangedCallback', obj);
    }
    
    private columnsFilterByGroup(columns: Array<object>, isGrouped: Boolean){
        let groupdColumns: Array<object>;
        let ungroupedColumns: Array<object>;
        if(isGrouped){
            groupdColumns = columns.filter((column: any)=>column.groupIndex !== undefined);
            return groupdColumns;
        }
        else{
            ungroupedColumns = columns.filter((column: any)=>column.groupIndex === undefined);
            return ungroupedColumns;
        }
    }

    private toggleSearchIconDisplay(self, display){
        self.$element.find('.dx-datagrid-search-panel .dx-icon.dx-icon-search').css('display', display);
    }

    public toggleSearchPanelVisible(self, gridContainer, showSearchPanel){
        gridContainer.find('.dx-toolbar-items-container .dx-datagrid-search-panel.dx-textbox.dx-texteditor').css('display', showSearchPanel ? 'block': 'none');
        gridContainer.find('.dx-toolbar-items-container .dx-datagrid-search-panel .dx-icon.dx-icon-search').addClass('icomoon icon-global-search');
        gridContainer.find('.dx-toolbar-items-container .dx-datagrid-search-panel .dx-icon.dx-icon-clear').addClass('icomoon icon-close-popup')
        gridContainer.find('.dx-toolbar-items-container .dx-datagrid-search-panel .dx-icon.dx-icon-search').removeClass('dx-icon-search');
    }   

    public handleSelectAll(self){
        var utils = this, selectAllCheckBox = $('.dx-header-row .dx-checkbox').first();  
        selectAllCheckBox.off('dxclick.selectAll');  
        selectAllCheckBox.on('dxclick.selectAll', utils.handleSelectAllClickedEvent.bind(selectAllCheckBox, self, utils));  
    }

    public handleSelectAllClickedEvent(self, utils){
        var selectAllCheckBox:any = this;
        self.isSelectAllCheckboxChecked = selectAllCheckBox.dxCheckBox('instance').option('value');
        utils.tryMethod(self, '_isSelectAllCheboxCheckedCallback', self.isSelectAllCheckboxChecked); 
    }

    public updateTotalCountMessage(self, e){
        var dataGridInstance = self.getGridInstance()
        var ttlCount = dataGridInstance && dataGridInstance.totalCount() > 0 ? dataGridInstance.totalCount() : 0;
        /*var fromRowNumber = (dataGridInstance.pageIndex() * dataGridInstance.pageSize() + 1);
        var toRowNumber = ((dataGridInstance.pageIndex() + 1) * dataGridInstance.pageSize());
        if(fromRowNumber && toRowNumber){
            e.component.option('pager.infoText', (ttlCount > 0 ? fromRowNumber : 0) +" - " + (toRowNumber  > ttlCount  ? ttlCount :  toRowNumber)  +" " + self._resourcesText["DG_PAGER_INFO_TEXT_OF"] +" " + ttlCount + " "+ self._resourcesText["DG_PAGER_INFO_TEXT_RESULTS"]);      
        }*/

        var pageIndex = e.component.pageIndex(); // current page
        var pageCount = e.component.pageCount();
        var pageSize = e.component.pageSize(); //page size
        var total = e.component.totalCount(); //total count

        var min = (pageIndex * pageSize) + 1;
        var max = (pageIndex + 1)  * pageSize;
        var rowsLength = 0;
        _.each(e.component.getVisibleRows(), function(rowData){
           if(rowData.rowType === 'data'){
            rowsLength++;  
           } 
        });
        var isLastPage = pageIndex + 1 === pageCount ? true : false;
        // modify last page total - count the existing and add from previous page total
        max = isLastPage ? (pageIndex * pageSize) + rowsLength : max; 
        // setting min size to zero when there are no records
        min  = (max === 0 ? 0 : min);
        var text = `${min} - ${max} ` + self._resourcesText["DG_PAGER_INFO_TEXT_OF"] +` ${total} ` + self._resourcesText["DG_PAGER_INFO_TEXT_RESULTS"];
        //get the pager object
        var pager = e.component.option("pager");
        // override the text
        pager.infoText = text;
        //return the page object
        e.component.option("pager", pager);

        return ttlCount;
    }

    public updateConfig(self,config){
        self.configProvider.executeConfigMethod("updateConfigData",self,[self, config]);
    }

    public updateView(self){
        self.configProvider.executeConfigMethod("updateView",self,[self]);
        //self.getGridInstance().repaint();
    }

    public pagingConfig(self: any) {
        return {
            enabled: self.showPaging,
            pageSize: self.pageSize
        };
    }

    //callbacks section
    public handleSelectionChanged(self, selecteditems) {
        var data;
        if (self.selectionMode === 'single') {
            this.tryMethod(self, 'singleSelectCallback', selecteditems);
        } else {
            this.tryMethod(self, 'multiSelectCallback', selecteditems);
        }
        this.updateRowSelectionCount(self, selecteditems.selectedRowsData.length);
    }

    public updateRowSelectionCount(self, count){
        var checkBoxDiv = self.$element.find('.dx-header-row .dx-command-select .dx-select-checkbox');
        $(checkBoxDiv).find('.selected-row-count').remove();
        var displayCount = count;
        if(displayCount > 999){
            displayCount = "999+";
        }
        $(checkBoxDiv).append('<span class="selected-row-count" title="'+count+'">('+ displayCount +')</span>');
    }

    public handleEditorPrepared (self, options) {
        this.tryMethod(self, 'editorPreparedCallback', options); //check the name
    }   

    public replaceGroupIcons(self, e){
        e.element.find(".dx-command-expand.dx-datagrid-group-space .dx-datagrid-group-opened").addClass("icomoon icon-arrow").removeClass("dx-datagrid-group-opened");
        e.element.find(".dx-command-expand.dx-datagrid-group-space .dx-datagrid-group-closed").addClass("icomoon icon-right-arrow").removeClass("dx-datagrid-group-closed");    
    }    

    public highlightGroupingContainer(self){
        var dragContainer = $('.dx-datagrid-drag-header.dx-datagrid-text-content dx-widget.dx-datagrid-drag-action');
        var toolbarLabelContainer = self.$element.find('.dx-toolbar-before .dx-item.dx-toolbar-item.dx-toolbar-label');
        if(dragContainer && !!dragContainer.length){
            toolbarLabelContainer.addClass('highlight');
        } else{
            toolbarLabelContainer.removeClass('highlight');
        }
    }

    public changeSpinner(){
        $('.dx-overlay-content.dx-resizable.dx-loadpanel-content').html('<div class="load-spinner"><span class="loading-med loading-active center-block"></span></div>');
    }

    public onCustomizeExportData(self, data, rowsData){        
        this.tryMethod(self, 'onCustomizeExportDataCallback', data, rowsData);
    }

    public onExportingData(self, data){
        this.tryMethod(self, 'onExportingCallback', data);
    }

    public onExportedData(self, data){
        this.tryMethod(self, 'onExportedCallback', data);
    }

    public onEditorPreparing(self, data){
        //adding clear button in row filter
        if(data.parentType = "filterRow"){
            data.editorOptions.placeholder = self._resourcesText["DG_ROW_FILTER_PLACEHOLDER_TEXT"];
            if(data.editorOptions.placeholder === 'Filter'){
                data.editorOptions.showClearButton = true;
            }
        } 
        this.tryMethod(self, 'onEditorPreparingCallback', data);
    }

    public onEditingStart(self, data){
        this.tryMethod(self, 'onEditingStartCallback', data);
    }

    public onToolbarPreparing(self, data){
        this.tryMethod(self, 'onToolbarPreparingCallback', data);
    }

    public onContextMenuPreparing(self, data){
        this.tryMethod(self, 'onContextMenuPreparingCallback', data);
    }    

    public getColumnData(columnsData){
        var i, columns = columnsData;
        var items :any = [];
           
    
        for (i = 0; i < columns.length; i++) {
            var item = {
                order: i + 1,
                originalOrder: i,
                showColumn:columns[i].visible,           
                columnName: columns[i].caption.trim() || columns[i].dataField,
                name: columns[i].dataField,
                freezeColumnLeft:false,
                freezeColumnRight:false,
                visibleIndex: columns[i].visibleIndex,
                sortOrder: columns[i].sortOrder,
                sortIndex: columns[i].sortIndex,
                groupIndex: columns[i].groupIndex,
                columnResizeWidth: columns[i].width,
                allowEditing: !columns[i].inActive,
                inActive: columns[i].inActive
            };

            if(columns[i].fixed){
                columns[i].fixedPosition === "left" ? item.freezeColumnLeft = true : item.freezeColumnRight = true; 
            }
            items.push(item);
        }
        return items;
    }    

    public pushToPageSizes(self, attrName, newVal) {
        var index, newIndex, sortNumber, length;
        if (attrName === 'pagesize') {
            self.pageSize = converter.toInteger(newVal, 'true');
            
        } else if (attrName === 'allowedpagesizes') {
            self.allowedPageSizes = JSON.parse(newVal);            
        }

        index = self.allowedPageSizes.indexOf(self.pageSize);
        sortNumber = (a, b) => a - b;
        if (index === -1) {
            self.allowedPageSizes.push(self.pageSize);
            self.allowedPageSizes.sort(sortNumber);
            length = self.allowedPageSizes.length;

            if(length > 4){
                newIndex = self.allowedPageSizes.indexOf(self.pageSize);
                newIndex < length - 1 ? self.allowedPageSizes.pop() : self.allowedPageSizes.shift();
            }
        }
    }

    public handleCustomizeColumns(self, dxGridColumns){
        this.tryMethod(self, 'customizeColumnsCallback', dxGridColumns);

        var cellTemplate;
        if(converter.toBoolean(self.showGroupingPanel, true)){
            dxGridColumns.forEach(dxGridColumn => {      
                dxGridColumn.showWhenGrouped = true;
                //setting default filter option as contains
                dxGridColumn.selectedFilterOperation = dxGridColumn.selectedFilterOperation || 'contains';
                self.hideSortFromGroupingPanel && dxGridColumn.groupIndex > -1 ? dxGridColumn.allowSorting = false : dxGridColumn.allowSorting = true;
                //setting cell template
                cellTemplate = this.getCellTemplate(self, dxGridColumn);
                if (cellTemplate) {
                    dxGridColumn.cellTemplate = cellTemplate;
                }
                this.handleCustomCellTemplate.bind(this, self);
            });
        }
    }   

    public getCellTemplate(self, dxGridColumn) {
        var cellTemplate;        
            cellTemplate = dxGridColumn.cellTemplate;
        return cellTemplate;
    }

    public handleOnInitialized(self, data){
        if(self.rowFilterAdvancedOperators){
            let view = data.component.getView("columnHeadersView");
            let defaultGetItems = view._getFilterOperationMenuItems.bind(data.component);
            view._getFilterOperationMenuItems = function(column) {
                let result = defaultGetItems(column);
                //for removing clear/remove filter from advanced search operations
                result.pop();
                return result;
            };
        }
        self.dispatchCustomEvent('auxdatagrid.initialized');

        this.tryMethod(self, 'onInitializedCallback', data);
        this.updateView(self);
    }

    public handleCellPrepared(self, dataObject){        
        if (dataObject.rowType !== 'data') {
            return;
        }      
        this.tryMethod(self, 'cellPreparedCallback', dataObject.cellElement, dataObject);
    }

    public assignGridCustomAttributes(self, config){
        this.setGridCustomAttribute(self, config, 'filterPanelVisible');
        this.setGridCustomAttribute(self, config, 'showGroupingPanel');
        this.setGridCustomAttribute(self, config, 'showSearchPanel');
        this.setGridCustomAttribute(self, config, 'columnChooserMode');
        this.setGridCustomAttribute(self, config, 'hasColumnChooser');
        this.setGridCustomAttribute(self, config, 'showRowFilter');
        this.setGridCustomAttribute(self, config, 'showPrint');
        this.setGridCustomAttribute(self, config, 'pageSize');
        this.setGridCustomAttribute(self, config, 'showTextForColumnChooserButton');
        this.setGridCustomAttribute(self, config, 'resourcestext');        
        this.setGridCustomAttribute(self, config, 'showPageSizeSelector');    
        this.setGridCustomAttribute(self, config, 'showPaging');    
        this.setGridCustomAttribute(self, config, 'isRowFilterOpened');    
        this.setGridCustomAttribute(self, config, 'enableMasterDetail');    
        this.setGridCustomAttribute(self, config, 'hideSortFromGroupingPanel');    
    }

    public setGridCustomAttribute(self, config, attrName){
        if(typeof config[attrName] !== 'undefined'){
            self[attrName] = config[attrName];
        } 
    }

    public assignCallbacksForConfig(self, config, extnConfig){
        extnConfig.customizeColumns = this.gridCallbackHelper.bind(null, self, this, this.handleCustomizeColumns, config.customizeColumns);
        extnConfig.onOptionChanged = this.gridCallbackHelper.bind(null, self, this, this.onOptionChanged, config.onOptionChanged);
        extnConfig.onInitialized = this.gridCallbackHelper.bind(null, self, this, this.handleOnInitialized, config.onInitialized);
        extnConfig.onContentReady = this.gridCallbackHelper.bind(null, self, this, self.remoteDataHelper.handleContentReadyAction, config.onContentReady);
        extnConfig.onSelectionChanged = this.gridCallbackHelper.bind(null, self, this, this.handleSelectionChanged , config.onSelectionChanged);
        extnConfig.onEditorPreparing = this.gridCallbackHelper.bind(null, self, this, this.onEditorPreparing , config.onEditorPreparing);
        extnConfig.onRowPrepared = this.gridCallbackHelper.bind(null, self, this, this.handleRowPrepared , config.onRowPrepared);
        extnConfig.onCellPrepared = this.gridCallbackHelper.bind(null, self, this, this.handleCellPrepared , config.onCellPrepared);
        // extnConfig.dataSource = this.gridCallbackHelper.bind(null, self, this, this.handleRemoteDatasource , config.dataSource);
    }
    
    public gridCallbackHelper(self, context, defaultCallback, configCallback, ...rest){
        if(defaultCallback){
            defaultCallback.call(context, self,  ...rest);
        }
        if(configCallback){
            configCallback.call(context, self,...rest);
        }
    }

    public renderNavigateButton(pager,direction){
        var prevButton = pager._$element.find('.dx-navigate-button.dx-prev-button');
        if(prevButton && prevButton.length ){
            $(prevButton).addClass('icomoon icon-arrow-left2');
            $(prevButton).removeClass('dx-prev-button');
        }
        var nextButton = pager._$element.find('.dx-navigate-button.dx-next-button');
        if(nextButton && nextButton.length ){
            $(nextButton).addClass('icomoon icon-arrow-right2');
            $(nextButton).removeClass('dx-next-button');
        }
    }

    private renderPagesSizeChooser(pager, self){
        if(pager._$pagesSizeChooser){
            pager._$element.find('.dx-page-size-message-container').remove();
            if(!pager._$element.find('.dx-page-size-message-container>.dx-page-size-message').length){
                pager._$element.prepend('<div class="dx-page-size-message-container"><div class="dx-page-size-message">'+ self.getTranslation("DG_PAGER_MESSAGE")+ '</div></div>');
            }
            pager._pagesSizeChooserWidth = pager._$pagesSizeChooser.width() + pager._$element.find('.dx-page-size-message-container').width();
        }
    }

    public getColumnChooserMode(self, expectedMode){   
        let columnChooserMode;     
        if(typeof self.columnChooserMode === 'string' && expectedMode.toLowerCase() === self.columnChooserMode.toLowerCase()){
            columnChooserMode = true;
        }else if (typeof self.columnChooserMode === 'object'){
            self.columnChooserMode.forEach(mode => {
                if(mode.toLowerCase() === expectedMode.toLowerCase()){
                    columnChooserMode = true;                    
                }
            });
        }
        return columnChooserMode;
    }

    public handleRemoteDatasource(self) {
        var dataSource = {
            key: self.dataKey ? self.dataKey : "",
            load: this.handleRemoteDataLoad.bind(this, self),
            totalCount: this.handleRemoteDataTotalCount.bind(this, self),
            paginate: true,
            pageSize: self.pageSize,
            allowedPageSizes: self.allowedPageSizes
        };
        return dataSource;
    }

    public handleRemoteDataLoad(self, options){
        return this.tryMethod(self, 'handleRemoteDataLoadCallback', options);
    }  

    public handleRemoteDataTotalCount(self){
        var dfd = $.Deferred();
        var optionsObj = {};

        if (self.totalCountCallback) {
            this.tryMethod(self, 'totalCountCallback', dfd, optionsObj);
        }
        return dfd.promise();
    }

    public handleMasterDetail(self){
        self.enableMasterDetail && self.$element.find('.gridContainer').addClass('master-detail-grid');  
        self.selectionMode === 'multiple' ? self.$element.find('.gridContainer').addClass('command-box-visible') : '';  
    }    

    public contentReadyActionForJSONHelper(self:any, onContentReady:any, e:any){
        var dataGridInstance = self.getGridInstance();      
            
        self.gridInstance = dataGridInstance;
        var ttlCount = this.updateTotalCountMessage(self, e);
        this.tryMethod(self, 'gridLoadedCallback', self, dataGridInstance);        
        if(self.selectAllMode === 'allPages'){
            this.handleSelectAll(self);            
        }
        if (self.customTotalCount !== ttlCount) {
            self.getTotalCount = true;
        }
        if(onContentReady){
            onContentReady.call(null, e, ttlCount);
        }
        this.updateRowSelectionCount(self, dataGridInstance.getSelectedRowsData().length);
        this.updateView(self);    
    }
}

export default Utils;