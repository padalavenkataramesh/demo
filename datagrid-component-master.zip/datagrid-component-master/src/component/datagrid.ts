import DatagridController from "./datagrid-controller";
import Component from "../core/component";
var elName = 'aux-datagrid';

export const newElement = new Component({
    name: elName,
    controller: DatagridController
});