import {AUXElement, AUXElementBaseController} from '../core/aux-element';

import AttrConfig from "./config/attr-config";
import DefaultConfig from "./config/default-config";
import JsonConfig from "./config/json-config";
import PropConfig from "./config/prop-config";
import RemoteDataConfig from "./config/remote-data-config";
import ConfigProvider from "./config/config-provider";
import ExportConfig from "./config/export-config";
import SettingsConfig from "./config/settings-config";
import SimpleSettingsConfig from "./config/simple-settings-config";
import PrintConfig from "./config/print-config";
import PagerConfig from "./config/pager-config";
import RowFilterConfig from "./config/row-filter-config";
import AdvancedFilterConfig from "./config/advanced-filter-config";
import EditConfig from "./config/edit-config";
import GroupingConfig from "./config/grouping-config";
import Utils from "./helpers/utils";
import JsonHelper from "./helpers/json-helper";
import ToolbarHelper from "./helpers/toolbar-helper";
import RemoteDataHelper from './helpers/remote-data-helper';

 
var view = require('./datagrid.html');

var utils = new Utils();
var jsonHelper = new JsonHelper();

const resourcesText = {    
    "DG_SORT_ASCENDING_CAPTION":"Sort Ascending",
    "DG_SORT_DESCENDING_CAPTION":"Sort Descending",
    "DG_CLEAR_SORTING_CAPTION":"Clear Sorting",
    "DG_ADD_ROW_HELP_TEXT":"Add a row",
    "DG_NO_DATA_CAPTION":"No Data",
    "DG_CANCEL_CHANGES_HELP_TEXT":"Discard changes",
    "DG_DELETE":"Delete",
    "DG_SAVE_CHANGES_HELP_TEXT":"Save changes",
    "DG_UNDELETE":"Undelete",
    "DG_SEARCH_TABLE":"Search Table",
    "DG_SHOW_HIDE_COLUMN":"Show/Hide Column",
    "DG_EXPORT_FILENAME":"Data Table",
    "DG_ROW_FILTER_TOGGLE_CAPTION":"Toggle Filter",
    "DG_ROW_FILTER_PLACEHOLDER_TEXT":"Filter",
    "DG_FILTER_ROW_APPLY_FILTER_TEXT":"Apply Filter",
    "DG_FILTER_ROW_BETWEEN_STARTTEXT":"Start",
    "DG_FILTER_ROW_BETWEEN_ENDTEXT":"End",
    "DG_ROW_FILTER_APPLIED_SINGLE_COUNT":"Filter Applied",
    "DG_ROW_FILTER_APPLIED_MULTIPLE_COUNT":"Filters Applied",
    "DG_PAGER_MESSAGE":"Rows per page",
    "DG_PAGER_PAGE_TEXT": "Page",
    "DG_PAGER_INFO_TEXT_OF":"of",
    "DG_PAGER_INFO_TEXT_RESULTS":"Results",
    "DG_CLEAR_FILTER_TEXT":"Clear Filter",
    "DG_SETTINGS_TITLE":"Table Settings",
    "DG_SETTINGS_ORDER":"Order",
    "DG_SETTINGS_RE_ORDER":"Re-Order",
    "DG_SETTINGS_SHOW_COLUMN":"Show Column",
    "DG_SIMPLE_SETTINGS_SEARCH_TEXT":"Search",
    "DG_SIMPLE_SETTINGS_SHOW_COLUMNS":"Show Columns",
    "DG_SETTINGS_COLUMN_NAME":"Column Name",
    "DG_SETTINGS_FREEZE_COLUMN_LEFT":"Freeze Column Left",
    "DG_SETTINGS_FREEZE_COLUMN_RIGHT":"Freeze Column Right",
    "DG_RESET":"Reset",
    "DG_CANCEL":"Cancel",
    "DG_APPLY":"Apply",
    "DG_FILTER_TITLE":"Filter Columns",
    "DG_FILTER_SELECTION_AND":"Show items that match all",
    "DG_FILTER_SELECTION_OR":"Show items that match any",
    "DG_FILTER_SELECTION_NOTAND":"Show items that doesnot match all",
    "DG_FILTER_SELECTION_NOTOR":"Show items that doesnot match any",
    "DG_FILTER_SELECTION_BETWEEN":"Between",
    "DG_FILTER_SELECTION_CONTAINS":"Contains",
    "DG_FILTER_SELECTION_ENDSWITH":"Ends with",
    "DG_FILTER_SELECTION_EQUAL":"Equals",
    "DG_FILTER_SELECTION_GREATERTHAN":"Greater than",
    "DG_FILTER_SELECTION_GREATERTHANOREQUAL":"Greater than or equal to",
    "DG_FILTER_SELECTION_ISBLANK":"Is blank",
    "DG_FILTER_SELECTION_ISNOTBLANK":"Is not blank",
    "DG_FILTER_SELECTION_LESSTHAN":"Less than",
    "DG_FILTER_SELECTION_LESSTHANOREQUAL":"Less than or equal to",
    "DG_FILTER_SELECTION_NOTCONTAINS":"Does not contain",
    "DG_FILTER_SELECTION_NOTEQUAL":"Does not equal",
    "DG_FILTER_SELECTION_STARTSWITH":"Starts with",
    "DG_SIMPLE_SETTINGS_MORE_DATA_TEXT":"More"
};

export class DatagridController extends AUXElement implements AUXElementBaseController{
    
    element: any;
    $element: any;
    dataGridInstance: any;
    _totalCount: number;
    attrConfig: any;
    propConfig: any;
    remoteDataConfig: any;
    public loadJSONData: any;
    public configOptionsCB: any;
    isFirstLoad: boolean;
    _resourcesText: any;
    getTotalCount: boolean; //TODO: check if required
    toolbarHelper: any;
    defaulConfig: any;
    buttons: [];

    configProvider: any;
    exportConfig: any;
    settingConfig: any;
    simpleSettingsConfig: any;
    advancedFiltlerConfig: any;
    printConfig: any;
    pagerConfig: any;
    rowFilterConfig: any;
    updateConfig: any;
    editConfig: any;
    groupingConfig: any;
    _preferenceData:any;
    _gridState:any;
    remoteDataHelper:any;

    static get observedAttributes() {
        return ['data', 'allowcolumnresizing', 'allowcolumnreordering', 'hascolumnchooser', 'rowalternationenabled', 'showrowfilter',
                'selectionmode', 'allowselectall', 'showrowfilter', 'showgroupingpanel', 'allowrowediting', 'allowrowadding',
                'allowrowdeleting', 'editmode', 'sortingmode', 'pagesize', 'allowedpagesizes', 'showcheckboxesmode', 'scrolltype', 'rowrenderingmode',
                'columnautowidth', 'wordwrapenabled', 'showpaging', 'showprint', 'selectallmode', 'autoexpandgroup', 'allowexportdata', 'allowexportselecteddata',
                'showsearchpanel', 'datamode', 'loaderpanelenabled', 'columnchoosermode', 'enablemasterdetail', 'rowfilteradvancedoperators', 'filterpanelvisible',
                'columnresizingmode', 'contextmenuenabled', 'showheaderfilter', 'exporttocsvenabled', 'datakey', 'showtextforcolumnchooserbutton', 'isrowfilteropened',
                'hidesortfromgroupingpanel'
                ];
    }

    constructor(){
        super();
    }

    onInit() {
        var self = this;
        this.element = this;
        this.$element = $(this);
        this.dataGridInstance = null;
        this._resourcesText = resourcesText;
        this._totalCount = 0;

        this.configProvider = new ConfigProvider();

        this.attrConfig = new AttrConfig(self);
        this.defaulConfig = new DefaultConfig(self);
        this.propConfig = new PropConfig();
        this.remoteDataConfig = new RemoteDataConfig(self);
        this.toolbarHelper = new ToolbarHelper();
        this.remoteDataHelper = new RemoteDataHelper();
        this.buttons = [];
        this.addCallbacks(this);
        this.attrConfig.addAttributes(this);
        this.propConfig.addProperties(this);
        this.getTotalCount = true;

        this.simpleSettingsConfig = new SimpleSettingsConfig(self);
        this.configProvider.registerConfig(this.simpleSettingsConfig);

        this.settingConfig = new SettingsConfig(self);
        this.configProvider.registerConfig(this.settingConfig);

        this.exportConfig = new ExportConfig(self);
        this.configProvider.registerConfig(this.exportConfig);        

        this.printConfig = new PrintConfig(self);
        this.configProvider.registerConfig(this.printConfig);

        this.pagerConfig = new PagerConfig(self);
        this.configProvider.registerConfig(this.pagerConfig);

        this.rowFilterConfig = new RowFilterConfig(self);
        this.configProvider.registerConfig(this.rowFilterConfig);

        this.advancedFiltlerConfig = new AdvancedFilterConfig(self);
        this.configProvider.registerConfig(this.advancedFiltlerConfig);

        this.editConfig = new EditConfig(self);
        this.configProvider.registerConfig(this.editConfig);

        this.groupingConfig = new GroupingConfig(self);
        this.configProvider.registerConfig(this.groupingConfig);

        if (this.loadJSONData) {
            this.reload();
        }

        //Flag for checking Datagrid is Loading first time
        this.isFirstLoad = true;
        this._preferenceData = null;
        this._gridState = null;
    }

    getTranslation(key,options){
        return this._resourcesText[key]?this._resourcesText[key]:key;
    }



    public reload() {
        this.load().done();
    }

    public repaint() {
        var self: any = this;
        try {
            self.dataGridInstance = self.getGridInstance();
            self.dataGridInstance.repaint();
        }
        catch (error) {

        }
    }

    public addCallbacks(self) {
        self.disableButton = self.toolbarHelper.disableButton.bind(self.toolbarHelper,self);
        self.setNoAccess = self.toolbarHelper.setNoAccess.bind(self.toolbarHelper,self);
        self.showButton = self.toolbarHelper.showButton.bind(self.toolbarHelper,self);
        self.disableMenuOption = self.toolbarHelper.disableMenuOption.bind(self.toolbarHelper,self);
        self.showMenuOption = self.toolbarHelper.showMenuOption.bind(self.toolbarHelper,self);
        self.setNoAccessForMenuOption = self.toolbarHelper.setNoAccessForMenuOption.bind(self.toolbarHelper,self);
    }

    public init(rgHeader) {
        this.toolbarHelper.init(this, rgHeader);
    }
    onRender(){
        return view;
    }
    onConnected() {
        //this.element.innerHTML = view;
        // if (!this.loadJSONData) { //TODO:check if required
        //    this.refreshRemoteData(this);
        // }
    }

    public refreshRemoteData(self) { //TODO:check if required
        this.handleRemoteData.bind(this, self)();
    }

    public handleRemoteData(self) {
        if (self.data !== '') {
            return;
        }
        self.getTotalCount = true;

        var config = new RemoteDataConfig(self).config;

        if(self._columnsData){
            config.columns = self._columnsData;
        }
        this.loadDxDataGrid(self, config, 'remote');
    }

    onDisconnected() {

    }

    onAttributeChanged(attrName, oldVal, newVal) {
        return this.attrConfig && this.attrConfig.handleAttributeChange(attrName, oldVal, newVal);
    }

    public load() {
        this.getTotalCount = true;
        var dfd;
        if (this.loadJSONData && typeof this.loadJSONData === 'function') {
            dfd = this.loadJSONData();
            dfd.done(this.loaderDone.bind(null, this));
            return dfd.promise();
        } else if (this.loadJSONData && typeof this.loadJSONData === 'object') { //For handling direct assignment of object
            this.loaderDone(this, this.loadJSONData);
            return $.Deferred().promise();
        } else if (this.configOptionsCB && typeof this.configOptionsCB === 'object') { 
            this.loadGridWithConfig(this, this.configOptionsCB);
            return $.Deferred().promise();
        } else {
            return $.Deferred().promise();
        }
    }

    public loadGridWithConfig(self, config){        
        utils.assignGridCustomAttributes(self, config);
        var defaultCnfg = new DefaultConfig(self).defaultConfig;
        var extnConfig = $.extend(true, {}, defaultCnfg, config);
        //if(config.dataSource.length){
        //    self.loadDxDataGrid(self, extnConfig, 'json', config.dataSource);
        //} else {
        utils.assignCallbacksForConfig(self, config, extnConfig);
        self.loadDxDataGrid(self, extnConfig, 'remote');     
        //}
    }
    private loaderDone(self, data) {
        if (data.columns === undefined || data.columns.length === 0) {
            self.handleJSONData(self, data);
        }
        else {
            self.handleJSONDataWithColumns(self, data);
        }
    }

    private handleJSONData(self, data) {
        self._totalCount = data.data ? data.data.length : 0;        
        var config = new JsonConfig(self, data).config;

        self.loadDxDataGrid(self, config, 'json', data);
    }

    private handleJSONDataWithColumns(self, data) {
        var cols = jsonHelper.getColumnsFromData(self, data);
        self._totalCount = data.data ? data.data.length : 0;
        var config = new JsonConfig(self, data, cols).config;

        self.loadDxDataGrid(self, config, 'json', data);
    }

    private loadDxDataGrid(self, config, type: any = '', data: any = null) {
        //resetting Handlers
        var controlHeightBasedOnScrollType;
        var containerEl = self.createContainer(self, controlHeightBasedOnScrollType);
        self.containerEl = containerEl;
        if (type === 'remote') { 
            this.bindConfig(self, containerEl, config, controlHeightBasedOnScrollType);
        } else {
            //for JSON data
            self.bindConfig(self, containerEl, config, controlHeightBasedOnScrollType);
            if (type === 'json' && data.selectedRows !== undefined) {
                setTimeout(function () {
                    jsonHelper.preSelectRows(self, data.selectedRows);
                }, 2000);
            }
        }
    }

    private bindConfig(self, containerEl, config, height) {
        self.replaceContainerEl = self.replaceContainer(self, containerEl);
        if (self.replaceContainerEl.dxDataGrid) {
            utils.updateConfig(self,config);
            self.replaceContainerEl.dxDataGrid(config);
            self.dataGridInstance = self.replaceContainerEl.dxDataGrid('instance');
            self.updateState();
            utils.updateView(self);
            utils.handleMasterDetail(self);
            this.changeSpinner(self);
        }
    }

    public updateView(){
        var self = this;
        utils.updateView(self);
    }

    public updateColumnChanges(){
        var self = this;
        self.settingConfig.updateColumnChanges(self.settingConfig, self, self._preferenceData);
    } 

    public getColumnData(columnsData){
        var self = this;
        return utils.getColumnData(columnsData);
    }

    public getState(){
        if(this.dataGridInstance) {
            return this.dataGridInstance.state();
        }  
        return {};
        
    }

    public setState(gridState){
        this._gridState = gridState;
    }
    
    private updateState(){
        if(this._gridState){
            this.dataGridInstance.state(this._gridState);
            this._gridState = null;
        }
    }

    public loadConfig(type, containerEl, config) {
        var self: any = this;
        self.replaceContainerEl = self.replaceContainer(self, containerEl);
        config.onToolbarPreparing = self.defaulConfig.toolbarPreparing.bind(self.defaulConfig, self);
        config.onContentReady = jsonHelper.handleContentReadyActionForJSON.bind(JsonHelper, self, config.onContentReady);
        if (self.replaceContainerEl.dxDataGrid) {
            utils.updateConfig(self,config);
            self.replaceContainerEl.dxDataGrid(config);
            self.dataGridInstance = self.replaceContainerEl.dxDataGrid('instance');
            self.updateState();
            utils.updateView(self);
            utils.handleMasterDetail(self);
            self.changeSpinner(self);
        }
    }

    private changeSpinner(self) {
        self.$element.find('.dx-loadpanel-indicator.dx-loadindicator.dx-widget').html('<div class="load-spinner"><aux-spinner visible="true" size="60px"></aux-spinner></div>');
    }

    public getGridInstance() {
        var self: any = this;        
        self.dataGridInstance = $(self.element).find('.gridContainer').dxDataGrid('instance');
        return self.dataGridInstance;
    }

    private replaceContainer(self, containerEl) {        
        $(self.element).find('.gridContainer').remove();
        $(self.element).append(containerEl);
        return $(self.element).find('.gridContainer');    
    }

    private createContainer(self, controlHeightBasedOnScrollType) {
        var containerHeight = 'calc(100% - 46px)';
        return $('<div id="gridContainer" class="gridContainer" style=""></div>').css({
            'display': 'block', 'height': containerHeight, 'width': '100%'
        });
    }
}

export default DatagridController;