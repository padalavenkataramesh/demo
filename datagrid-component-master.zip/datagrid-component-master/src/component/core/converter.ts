
    class Converter {

        public toNullable(value) {
            return value ? value : null;
        }
    
        public toObject(value, defaultValue) {
            return value ? value : defaultValue;
        }
    
        public toString(value, defaultValue:any = '') {
            if (value === undefined || value === null) {
                return (defaultValue !== undefined) ? defaultValue : '';
            }
            return value.toString();
        }
    
        public toNullableString(value) {
            return Converter.prototype.toString(value, null);
        }
    
        public toBoolean(value, trueValue) {
            if (typeof value === 'undefined') {
                return false;
            }
    
            if (value === trueValue) { return true; }
            return value === true;
        }
    
        public toNullableBoolean(value, trueValue) {
            if (typeof trueValue === 'undefined' && (typeof value === 'undefined' || value === null)) {
                return null;
            }
    
            if (value === trueValue) { return true; }
            return value === true;
        }
    
        public toInteger(value, defaultValue) {
            var intValue = parseInt(value, 10);
            defaultValue = defaultValue || 0;
            if (isNaN(intValue)) {
                return defaultValue;
            } else {
                return intValue;
            }
        }
    
        public toFloat(value, defaultValue:any = 0) {
            var floatValue = parseFloat(value);
            if (arguments.length < 2) {
                defaultValue = 0;
            }
    
            if (isNaN(floatValue)) {
                return defaultValue;
            } else {
                return floatValue;
            }
        }
    
        public toNullableInteger(value) {
            var intValue = parseFloat(value);
    
            if (isNaN(intValue)) {
                return null;
            } else {
                return intValue;
            }
        }
    
        public toNullableFloat(value) {
            return this.toFloat(value, null);
        }
    }

    export default Converter;