import Utils from "../helpers/utils";
const utils:any = new Utils();

export class SimpleSettingsConfig {
    constructor(self) {

    }

    isEnabled(self) {
        return self.hasColumnChooser && utils.getColumnChooserMode(self, 'select');
    }    

    onToolbarPreparing(e, self) {
        let that = this, settingsBtnText;
        if (self.showTextForColumnChooserButton) {
            settingsBtnText = self.getTranslation("DG_SIMPLE_SETTINGS_SHOW_COLUMNS");
        }
        e.toolbarOptions.items.push(
            //e.toolbarOptions.items.length - 1,
            //0,
            {
                location: "after",
                widget: "dxButton",
                options: {
                    icon: settingsBtnText ? "icomoon icon-arrow" : "icomoon icon-settings", 
                    text: settingsBtnText,
                    rtlEnabled: true,
                    elementAttr: {
                        class: settingsBtnText ? " aux-button btn--secondary simple-settings" : " aux-button simple-settings",
                    },
                    onClick: function() {
                        that.showPopup(self);
                    }
                }
            }
        );
        e.toolbarOptions.items.forEach(item => {
            if (item.name === 'columnChooserButton') {
                item.visible = false;                
            }
        });
    }

    private createColumnChooserList(self) {
        let gridInstance = self.getGridInstance();
        let allColumns = gridInstance.getController('columns').getColumns().map(x => (_.assign({}, {...x})));
        let visibleColumns:any = [], mapSortedColumns:any = [];        
        mapSortedColumns = _.filter(allColumns, mapCol => mapCol.showInColumnChooser === true);
        let sortedColumns = _.sortBy(mapSortedColumns, column =>  column.caption );
        _.forEach(sortedColumns, function(column:any, index:any) {
            if(column.inActive){
                column.disabled = true;
            }
            if (column && column.visible) {
                visibleColumns.push(column)
            }
            if(self.columnchoosercontent){
                column && column.visible ? self.columnchoosercontent.instance('dxList').selectItem(index) : self.columnchoosercontent.instance('dxList').unselectItem(index);
            }
            delete column.visible;
        });
        if(!self.columnchoosercontent){        
        self.columnchoosercontent = $(".aux-datagrid-columnchoosercontent")
            .dxList({
                dataSource: sortedColumns,
                selectedItems: visibleColumns,
                selectionMode: "multiple",
                showSelectionControls: true,
                searchEnabled: true,
                displayExpr:'caption', 
                searchExpr: 'caption',
                nextButtonText: self._resourcesText['DG_SIMPLE_SETTINGS_MORE_DATA_TEXT'],
                noDataText: self._resourcesText['DG_NO_DATA_CAPTION'],
                itemTemplate: function (itemData, itemIndex, itemElement) {
                    itemData.inActive ? itemData.disabled = true : itemData.disabled = false;
                    itemElement.append("<span title="+ itemData.caption +">" + itemData.caption + "</span>");
                },
                onSelectionChanged: function (e: any) {
                    gridInstance.beginCustomLoading();
                    gridInstance.beginUpdate();
                    _.defer(function () {
                        _.each(e.addedItems, function (item) {
                            gridInstance.columnOption(item.dataField, "visible", true);
                        });
                        _.each(e.removedItems, function (item) {
                            gridInstance.columnOption(item.dataField, "visible", false);
                        });
                        gridInstance.endUpdate();
                        gridInstance.endCustomLoading();
                    });
                }
            })
            .dxList("instance");
        }
    }

    private showPopup(self) {
        let that = this;
        this.createColumnChooserList(self);
        let popupOptions: any = {
            width: 220,
            maxHeight: 420,
            height: 'auto',
            contentTemplate: function () {
                return $('.aux-datagrid-columnchoosercontent');
            },
            showTitle: false,
            visible: false,
            dragEnabled: false,
            closeOnOutsideClick: this.handlePopupClose.bind(null, self),
            shading: false,
            position:  { at: 'right', of: '.aux-button.simple-settings', my: 'top right', offset: '0 18' }, 
            searchEnabled: true,
            container: '.gridContainer'
        };

        let popUpContainer;
        let simpleSettingsButton = $(self.element).find('.dx-button.simple-settings');
        if(!self.popup || !self.isColumnChooserVisible){
            if(!self.popup){
                popUpContainer = $(".aux-datagrid-columnchooser-popup").dxPopup(popupOptions);
                self.popup = popUpContainer.dxPopup("instance");
            }
            that.replaceSearchContainerIcons(self, $('.aux-datagrid-columnchoosercontent'));
            self.popup.show();
            self.isColumnChooserVisible = true;
            simpleSettingsButton && simpleSettingsButton.addClass('activeStateEnabled');
        } else{
            self.popup.hide();
            self.isColumnChooserVisible = false;
            simpleSettingsButton && simpleSettingsButton.removeClass('activeStateEnabled');
        }
    }

    private handlePopupClose(self, e){
        let grid = $(e.target).closest(".dx-button.simple-settings");
        let columnChooser = $(e.target).closest(".aux-datagrid-columnchooser-popup");
        if (grid && !grid.length && columnChooser && !columnChooser.length && self.isColumnChooserVisible){
            self.isColumnChooserVisible = false;            
            let simpleSettingsButton = $(self.element).find('.dx-button.simple-settings');
            simpleSettingsButton && simpleSettingsButton.removeClass('activeStateEnabled');
            
            let gridInstance:any, columns:any, columnsData:any;            
            gridInstance = $(self).find('.gridContainer').dxDataGrid('instance');
            columns = gridInstance.getController('columns').getColumns();
            columnsData = utils.getColumnData(columns);
            utils.tryMethod(self, 'gridPreferencesCallback', columnsData);
        }
        return true;
    }

    private replaceSearchContainerIcons(self, container){
        container.find('.dx-list-search .dx-icon.dx-icon-search').addClass('icomoon icon-global-search');
        container.find('.dx-list-search .dx-icon.dx-icon-clear').addClass('icomoon icon-close-popup')
        container.find('.dx-list-search .dx-icon.dx-icon-search').removeClass('dx-icon-search');
    }

}

export default SimpleSettingsConfig;