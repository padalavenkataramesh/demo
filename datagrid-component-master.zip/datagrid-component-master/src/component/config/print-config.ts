import Utils from "../helpers/utils";
const utils:any = new Utils();

class PrintConfig {

    constructor(self){

    }

    isEnabled(self){
        return self.showPrint; 
    }

    onToolbarPreparing(e,self){
        var dataGrid = e.component;
        var that = this;        
        e.toolbarOptions.items.push({
            location: "before",
            widget: "dxButton",
            options: {
                icon: " icomoon icon-printer",
                elementAttr: {
                    id: "icomoon rg-print",
                    class: " aux-button btn--secondary icomoon rg-print",
                },
                onClick: function(e) {
                    e.event.stopPropagation();
                    that.onPrintButtonClicked(self,e,dataGrid)
                }
            }
        });
        
    }

    public onPrintButtonClicked(self,e,datagrid){
        var gridInstance = self;
        var tableHeaderStr = '', tableBodyStr = '',
            headerStr = '', rowStr = '', columnStr = '', colVal = '';

        //Table Header construction
        var headerArr = $(gridInstance).find('.dx-datagrid-text-content');
        var headerLen = headerArr.length;
        headerArr.each(function (index) {
            if (index !== headerLen - 1) {
                headerStr += "<th class='rg-print-header' style='" +
                    $(this).closest('td').attr('style') + "'>" +
                    $(this).text() + "</th>";
            }
        });
        tableHeaderStr = "<thead>" + headerStr +"</thead>";

        //Table Body Construction
        var rowArr = $(gridInstance).find('.dx-datagrid-table').find('.dx-data-row');
        rowArr.each(function () {
            columnStr = '';
            $(this).find(' > td:not(.dx-command-select)').each(function () {
                if ($(this).find('a').length === 0) {
                    colVal = $(this).html();
                } else {
                    colVal = $(this).text();
                }
                columnStr += "<td class='rg-print-col' style='" + $(this).attr('style') + "'>" +
                   colVal + "</td>";
            });
            rowStr += "<tr>" + columnStr + "</tr>";
        });
        tableBodyStr =  "<tbody>" + rowStr + "</tbody>";

        //Merge all strings to Create Complete Table
        var tableStr = "<div class='rg-print-container'><table class='rg-print-table'>" +
                        tableHeaderStr + tableBodyStr + "</table>";
        //openWin(tableStr); //Only For Dev testing - Uncomment this line and comment Next Line
        this.exportToPDF(gridInstance, tableStr);
    };

    private exportToPDF(self, tableStr) {
        var cssLinks = _.map($('head > link'), function (item) { return item.outerHTML; });
        var exportConfig = {
            htmlString: tableStr,
            cssLinks: cssLinks
        };
        utils.tryMethod(self, 'exportToPDFClicked', exportConfig, 'pdf', 'GridData');
    }

    //Only for Dev Testing - To check how styles are applied
    private openWin(tableStr) {
        var myWindow:any = window.open('', '', 'width=400,height=400');
        var doc = myWindow.document;
        doc.open();
        doc.write(tableStr + '<link type="text/css" rel="Stylesheet" href="styles/default.css" />');
        doc.close();
    }

    
}

export default PrintConfig;