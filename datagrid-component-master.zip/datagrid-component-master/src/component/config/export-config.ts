

class ExportConfig {



    constructor(self){

    }

    isEnabled(self){
        return self.exportToCSVEnabled;
    }

    onToolbarPreparing(e,self){
        var dataGrid = e.component;
        var that = this;        
        e.toolbarOptions.items.unshift({
            location: "after",
            widget: "dxButton",
            options: {
                icon: " icomoon icon-export",
                elementAttr: {
                    class: "dx-datagrid-export-button1",
                },
                onClick: function(e) {
                    e.event.stopPropagation();
                    that.onExporting(self,e,dataGrid)
                }
            }
        },
        {
            location: "after",
            widget: "dxButton",
            locateInMenu : "auto",
            options: {
                icon: " icomoon icon-export",
                elementAttr: {
                    class: "dx-datagrid-export-button2",
                },
                onClick: function(e) {
                    e.event.stopPropagation();
                    that.onExporting(self,e,dataGrid)
                }
            }
        });
    }


    onExporting(self, e, datagrid) {
        // e.cancel = true;
        var dataSourceArray = datagrid.getDataSource().items();
        var csv = this.JSON2CSV(dataSourceArray);
        var downloadLink = document.createElement("a");
        var blob = new Blob(["\ufeff", csv]);
        var url = URL.createObjectURL(blob);
        downloadLink.href = url;
        downloadLink.download = "data.csv";
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
    }

    JSON2CSV(objArray) {
		var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;

		var str = '';
		var line = '';

		if ($("#labels").is(':checked')) {
			var head = array[0];
			if ($("#quote").is(':checked')) {
				for (var index in array[0]) {
					var value = index + "";
					line += '"' + value.replace(/"/g, '""') + '",';
				}
			} else {
				for (var index in array[0]) {
					line += index + ',';
				}
			}

			line = line.slice(0, -1);
			str += line + '\r\n';
		}

		for (var i = 0; i < array.length; i++) {
			var line = '';

			if ($("#quote").is(':checked')) {
				for (var index in array[i]) {
					var value = array[i][index] + "";
					line += '"' + value.replace(/"/g, '""') + '",';
				}
			} else {
				for (var index in array[i]) {
					line += "\"" + array[i][index] + "\"" + ',';
				}
			}

			line = line.slice(0, -1);
			str += line + '\r\n';
		}
		return str;

	}
}

export default ExportConfig;