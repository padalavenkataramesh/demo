/// <amd-dependency path="../core/converter" />
import Converter  from "../core/converter";
import Utils from "../helpers/utils";
const converter = new Converter();
const utils = new Utils();

class AttrConfig {
    public vm: any;
    public data: string;
    public allowColumnResizing: boolean;
    public allowColumnReordering: boolean;
    public rowAlternationEnabled:boolean;
    public hasColumnChooser: boolean;
    public selectionMode: string;
    public allowSelectAll: boolean;
    public showRowFilter: boolean;
    public showGroupingPanel: boolean;
    public allowRowEditing: boolean;
    public allowRowAdding: boolean;
    public allowRowDeleting: boolean;
    public editMode: string;
    public sortingMode: string;
    public pageSize: number;
    public showPageSizeSelector: boolean;
    public scrollType: string;
    public rowRenderingMode: string;
    public columnAutoWidth: boolean;
    public wordWrapEnabled: boolean;
    public showPaging: boolean;
    public showPrint: boolean;
    public autoExpandGroup: boolean;
    public showCheckBoxesMode: string;
    public allowedPageSizes: Array<number>;
    public allowExportData: boolean;
    public allowExportSelectedData: boolean;
    public showSearchPanel: boolean;
    public loaderPanelEnabled: boolean;
    public enableMasterDetail: boolean;
    public columnResizingMode: string;    
    public contextMenuEnabled: boolean;
    public exportFileName: string;
    public showHeaderFilter: boolean;
    public exportToCSVEnabled: boolean;
    public dataKey: string;
    public isPreferencesApplied: boolean;

    constructor(self: any) {
        this.vm = self;
        self.data = '';
        self.allowColumnResizing = true;
        self.allowColumnReordering = true;
        self.hasColumnChooser = false;
        self.rowAlternationEnabled = false;
        self.selectionMode = 'multiple';
        self.allowSelectAll = true;
        self.showRowFilter = true;
        self.rowFilterAdvancedOperators = false;
        self.showGroupingPanel = false;
        self.allowRowEditing = false;
        self.allowRowAdding = false;
        self.allowRowDeleting = false;
        self.editMode = 'batch';
        self.sortingMode = 'single';
        self.pageSize = 100;
        self.scrollType = 'standard';
        self.rowRenderingMode = 'standard';
        self.columnAutoWidth = true;
        self.wordWrapEnabled = false;
        self.showPaging = true;
        self.showPrint = false;
        self.autoExpandGroup = true;
        self.allowedPageSizes = [10, 25, 50, 100];
        self.showNavigationButtons = true;
        self.showPageSizeSelector = true;
        self.showCheckBoxesMode = 'always';
        self.allowExportData = false;
        self.allowExportSelectedData = false;
        self.showSearchPanel = false;
        self.dataMode = 'remote';
        self.filterPanelVisible = false;
        self.selectAllMode = 'page';
        self.loaderPanelEnabled = true;
        self.columnChooserMode = 'select';
        self.enableMasterDetail = false;   
        self.columnResizingMode = 'widget';   
        self.contextMenuEnabled = false;  
        self.exportFileName = 'Data Table';
        self.showHeaderFilter = false;
        self.exportToCSVEnabled = false;
        self.dataKey = '';
        self.isPreferencesApplied = false;
        self.showTextForColumnChooserButton = false;
        self.isRowFilterOpened = false;
        self.hideSortFromGroupingPanel = false;
    }

    //Assigning attribute value to vm variable if not null
    //third argument is to convert value to boolean
    //second argument may or may not be a function
    private addAttrValue(self: any, attr: any, callback: any, isBoolean: boolean = false) {
        var attrValue = self.getAttribute(attr), valueToAssign;
        if (!_.isNull(attrValue)) {
            valueToAssign = isBoolean ? converter.toBoolean(attrValue, 'true') : attrValue;
            _.isFunction(callback) ? callback(valueToAssign) : callback = valueToAssign;
        }
    }

    private addAttributes(self: any): void {
        this.addAttrValue(self, 'data', self.data);
        this.addAttrValue(self, 'allowcolumnresizing', self.allowColumnResizing, true);
        this.addAttrValue(self, 'allowcolumnreordering', self.allowColumnReordering, true);
        this.addAttrValue(self, 'hascolumnchooser', self.hasColumnChooser, true);
        this.addAttrValue(self, 'rowalternationenabled', self.rowAlternationEnabled, true);
        this.addAttrValue(self, 'selectionmode', self.selectionMode);
        this.addAttrValue(self, 'allowselectall', self.allowSelectAll);
        this.addAttrValue(self, 'showrowfilter', self.showRowFilter, true);
        this.addAttrValue(self, 'isrowfilteropened', self.isRowFilterOpened, true);
        this.addAttrValue(self, 'showgroupingpanel', self.showGroupingPanel, true);
        this.addAttrValue(self, 'allowrowediting', self.allowRowEditing, true);
        this.addAttrValue(self, 'allowrowadding', self.allowRowAdding, true);
        this.addAttrValue(self, 'allowrowdeleting', self.allowRowDeleting, true);
        this.addAttrValue(self, 'editmode', self.editMode);
        this.addAttrValue(self, 'sortingmode', self.sortingMode);
        this.addAttrValue(self, 'pagesize', self.pageSize);
        this.addAttrValue(self, 'allowedpagesizes', self.allowedPageSizes);
        this.addAttrValue(self, 'showcheckboxesmode', self.showCheckBoxesMode);
        this.addAttrValue(self, 'scrolltype', self.scrollType);
        this.addAttrValue(self, 'rowrenderingmode', self.rowRenderingMode);
        this.addAttrValue(self, 'columnautowidth', self.columnAutoWidth, true);
        this.addAttrValue(self, 'wordwrapenabled', self.wordWrapEnabled, true);
        this.addAttrValue(self, 'showpaging', self.showPaging, true);
        this.addAttrValue(self, 'showprint', self.showPrint, true);
        this.addAttrValue(self, 'selectallmode', self.selectAllMode);
        this.addAttrValue(self, 'autoexpandgroup', self.autoExpandGroup, false);
        this.addAttrValue(self, 'allowexportdata', self.allowExportData, false);
        this.addAttrValue(self, 'allowexportselecteddata', self.allowExportSelectedData, false);
        this.addAttrValue(self, 'showsearchpanel', self.showSearchPanel, true);
        this.addAttrValue(self, 'datamode', self.dataMode);
        this.addAttrValue(self, 'loaderpanelenabled', self.loaderPanelEnabled, true);
        this.addAttrValue(self, 'columnchoosermode', self.columnChooserMode);
        this.addAttrValue(self, 'enablemasterdetail', self.enableMasterDetail, true);
        this.addAttrValue(self, 'rowfilteradvancedoperators', self.rowFilterAdvancedOperators, true);
        this.addAttrValue(self, 'filterpanelvisible', self.filterPanelVisible, true);
        this.addAttrValue(self, 'columnresizingmode', self.columnResizingMode);
        this.addAttrValue(self, 'contextmenuenabled', self.contextMenuEnabled, false);
        this.addAttrValue(self, 'showheaderfilter', self.showHeaderFilter, false);
        this.addAttrValue(self, 'exporttocsvenabled', self.exportToCSVEnabled, false);
        this.addAttrValue(self, 'datakey', self.dataKey);
        this.addAttrValue(self, 'showtextforcolumnchooserbutton', self.showTextForColumnChooserButton, true);
        this.addAttrValue(self, 'hidesortfromgroupingpanel', self.hideSortFromGroupingPanel, false);        
        //Be sure to add any attributes to static get observedAttributes function in data grid controller whenever new attributes are getting added 
       //to notify web components v1 framework changes to pick the attributes set in html 
    };

    private handleAttributeChange(attrName: string, oldVal: any, newVal: any): void {
        var self = this.vm;

        switch (attrName) {
            case 'data': self.data = newVal; self.handleRemoteData(self); break;
            case 'allowcolumnresizing': self.allowColumnResizing = converter.toBoolean(newVal, 'true'); break;
            case 'allowcolumnreordering': self.allowColumnReordering = converter.toBoolean(newVal, 'true'); break;
            case 'hascolumnchooser': self.hasColumnChooser = converter.toBoolean(newVal, 'true'); break;
            case 'rowalternationenabled': self.rowAlternationEnabled = converter.toBoolean(newVal, 'true'); break;
            case 'selectionmode': self.selectionMode = newVal; break;
            case 'allowselectall' : self.allowSelectAll = converter.toBoolean(newVal, 'true'); break;
            case 'showgroupingpanel': self.showGroupingPanel = converter.toBoolean(newVal, 'true'); break;
            case 'allowrowediting': self.allowRowEditing = converter.toBoolean(newVal, 'true'); break;
            case 'allowrowadding': self.allowRowAdding = converter.toBoolean(newVal, 'true'); break;
            case 'allowrowdeleting': self.allowRowDeleting = converter.toBoolean(newVal, 'true'); break;
            case 'editmode': self.editMode = converter.toString(newVal); break;
            case 'sortingmode': self.sortingMode = newVal; break;
            case 'showrowfilter': self.showRowFilter = converter.toBoolean(newVal, 'true'); break;
            case 'isrowfilteropened': self.isRowFilterOpened = converter.toBoolean(newVal, 'true'); break;
            case 'pagesize': utils.pushToPageSizes(self, attrName, newVal,); break;
            case 'allowedpagesizes': utils.pushToPageSizes(self, attrName, newVal);  break;
            case 'showcheckboxesmode': self.showCheckBoxesMode = newVal; break;
            case 'scrolltype': self.scrollType = newVal; break;
            case 'rowrenderingmode': self.rowRenderingMode = newVal; break;
            case 'columnautowidth': self.columnAutoWidth = converter.toBoolean(newVal, 'true'); break;
            case 'wordwrapenabled': self.wordWrapEnabled = converter.toBoolean(newVal, 'true'); break;
            case 'showpaging': self.showPaging = converter.toBoolean(newVal, 'true'); break;
            case 'showprint': self.showPrint = converter.toBoolean(newVal, 'true'); break;
            case 'selectallmode': self.selectAllMode = newVal; break;
            case 'autoexpandgroup': self.autoExpandGroup = converter.toBoolean(newVal, 'true'); break;
            case 'allowexportdata': self.allowExportData = converter.toBoolean(newVal, 'true'); break;
            case 'allowexportselecteddata': self.allowExportSelectedData = converter.toBoolean(newVal, 'true'); break;
            case 'showsearchpanel': self.showSearchPanel = converter.toBoolean(newVal, 'true'); break;
            case 'datamode': self.dataMode = newVal; if (!self.loadJSONData && self.dataMode === 'remote') { self.handleRemoteData(self) }; break;
            case 'loaderpanelenabled': self.loaderPanelEnabled = converter.toBoolean(newVal, 'true'); break;
            case 'columnchoosermode': self.columnChooserMode = newVal; break;
            case 'enablemasterdetail': self.enableMasterDetail = converter.toBoolean(newVal, 'true'); break;
            case 'rowfilteradvancedoperators': self.rowFilterAdvancedOperators = converter.toBoolean(newVal, 'true'); break;
            case 'filterpanelvisible': self.filterPanelVisible = converter.toBoolean(newVal, 'true'); break;
            case 'columnResizingMode': self.columnResizingMode = newVal; break;
            case 'contextmenuenabled': self.contextMenuEnabled = converter.toBoolean(newVal, 'true'); break;
            case 'showheaderfilter': self.showHeaderFilter = converter.toBoolean(newVal, 'true'); break;
            case 'exporttocsvenabled': self.exportToCSVEnabled = converter.toBoolean(newVal, 'true'); break;
            case 'datakey': self.dataKey = newVal; break;
            case 'showtextforcolumnchooserbutton': self.showTextForColumnChooserButton = converter.toBoolean(newVal, 'true'); break;
            case 'hidesortfromgroupingpanel': self.hideSortFromGroupingPanel = converter.toBoolean(newVal, 'true'); break;            
            //Be sure to add any attributes to static get observedAttributes function in data grid controller whenever new attributes are getting added 
            //to notify web components v1 framework changes to pick the attributes set in html
        }
        
    };
}

export default AttrConfig;