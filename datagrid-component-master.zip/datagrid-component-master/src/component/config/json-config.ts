import DefaultConfig from "./default-config";
import JsonHelper from "../helpers/json-helper";
import Utils from "../helpers/utils";
const helper = new JsonHelper();
const utils = new Utils();

class JsonConfig{
    public config: any;

    constructor(self: any, data: any, cols: any = ''){
        this.config =  {
            dataSource: data.data,
            keyExpr: self.dataKey ? self.dataKey : "",
            columns: cols,
            customizeColumns: utils.handleCustomizeColumns.bind(utils, self),
            onCellPrepared: helper.handleCellPrepared.bind(null, self),
            onInitNewRow: helper.handleInitNewRow.bind(null, self),
            onRowPrepared: helper.handleRowPrepared.bind(null, self),
            onContentReady: helper.handleContentReadyActionForJSON.bind(helper, self, null),
            onEditorPrepared: utils.handleEditorPrepared.bind(utils, self),
            onOptionChanged: utils.onOptionChanged.bind(utils, self),
            onInitialized: utils.handleOnInitialized.bind(utils, self),
            onRowInserting: helper.handleRowInserting.bind(null, self),
            onRowUpdating: helper.handleRowUpdating.bind(null, self),
            onRowRemoving: helper.handleRowRemoving.bind(null, self)
        };

        if (self.scrollType === 'standard') { 
            this.config.paging = utils.pagingConfig(self);
        }
        
        if (data.config) {
            $.extend(this.config, data.config); //Extending data config if passed by module
        }
        
        var defaultCnfg = new DefaultConfig(self).defaultConfig;
        $.extend(this.config, defaultCnfg);        
    }
}

export default JsonConfig;