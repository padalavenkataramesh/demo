

class ConfigProvider {

    private configList:any = [];

    constructor(){

    }

    registerConfig(config){
        this.configList.push(config);
    }

    executeConfigMethod(methodName,self,args){
        this.configList.forEach(config => {
            if(config.isEnabled(self) && typeof config[methodName] === 'function'){
                config[methodName].apply(config,args);
            }
        });
    }

}

export default ConfigProvider;