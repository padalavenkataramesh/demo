import Utils from "../helpers/utils";
const utils:any = new Utils();


class SettingsConfig {
    public config;
    public popupOptions;
    public settingsPopupInstance;

    _gridInstance;
   
    _data;
    _prevData;

    columns:any;
    columnsData:any;
   

    constructor(self){

        //this.columns =  this.getColumnTemplate(self);
        
    }

    public isEnabled(self){
        return self.hasColumnChooser && utils.getColumnChooserMode(self, 'advanced');        
    }

    getColumnTemplate(self){
        var that = this;

        return [
            {
                dataField: "visibleIndex",
                calculateDisplayValue: function(row){
                    return row.visibleIndex + 1;
                }, 
                caption: self.getTranslation("DG_SETTINGS_ORDER"),
                dataType: "number",
                allowEditing: false,
                width: 100,
                visible:true
            },
            {
                dataField: "order",
                dataType: "string",
                allowEditing: false,
                width: 100,
                visible:false
            },
            {
                dataField: "showColumn",
                caption: self.getTranslation("DG_SETTINGS_SHOW_COLUMN"),
                dataType: "boolean",
                width: 100,
                /*editorOptions : {
                    onValueChanged:function(newValue, oldValue){
                        console.log(newValue,oldValue)
                    }
                }*/
            },
            {
                dataField: "columnName",
                caption: self.getTranslation("DG_SETTINGS_COLUMN_NAME"),
                dataType: "string",
                allowEditing: false
            },
            {
                dataField: "freezeColumnLeft",
                caption: self.getTranslation("DG_SETTINGS_FREEZE_COLUMN_LEFT"),
                dataType: "boolean"
            },
            {
                dataField: "freezeColumnRight",
                caption: self.getTranslation("DG_SETTINGS_FREEZE_COLUMN_RIGHT"),
                dataType: "boolean",
                visible:false
            },
            {
                width: 100,
                dataField: "Reorder",
                caption: self.getTranslation("DG_SETTINGS_RE_ORDER"),
                allowEditing: false,
                alignment: 'center',
                cssClass: 'reorder-buttons-container',
                cellTemplate:

                    function (container, options) {
                        
                        var firstRow = options.rowIndex == 0;
                        var lastRow = options.rowIndex == (options.component.getVisibleRows().length - 1);
                        $("<div/>").dxButton({
                            icon: "icomoon icon-arrow-up2",
                            disabled: firstRow,
                            visible: !options.row.data.inActive,
                            elementAttr: {
                                class:"aux-button"
                            },
                            onClick: function (e) {
                                that.reorderData(that.columnsData, options.rowIndex, "up");
                                options.component.refresh();
                                options.component.repaint();
                            }
                        }).appendTo(container);

                        $("<div/>").dxButton({
                            icon: "icomoon icon-arrow-down2",
                            disabled: lastRow,
                            visible: !options.row.data.inActive,
                            elementAttr: {
                                class:"aux-button"
                            },
                            onClick: function (e) {
                                that.reorderData(that.columnsData, options.rowIndex, "down");
                                options.component.refresh();
                                options.component.repaint();
                            }
                        }).appendTo(container);


                }
            }
          ]
    }


    

    get data(){
        return this._data;
    }

    set data(newData){
        this._data = _.cloneDeep(newData);
        this._prevData = _.cloneDeep(newData);
    }

    public onToolbarPreparing(e,self){
        var dataGrid = e.component;
        var that = this;      
        e.toolbarOptions.items.push(
            //e.toolbarOptions.items.length - 1,
            //0,
            {
                location: "after",
                widget: "dxButton",
                options: {
                    icon: "icomoon icon-settings", // icomoon 
                    elementAttr: {
                        class: " aux-button btn--secondary",
                    },
                    onClick: function() {
                        that.showPopup(self);
                    }
                }
            }
        );
    }


    

    private _getPopupOptions = function(self,columnData){
        let that = this;
        let grid;
        return {
            contentTemplate: function (contentElement) {
                grid = $("<div id='advancedSettingsGridContainer' class='table-settings-grid'>");
                that._popupContent(self, grid, that.getColumnTemplate(self), columnData,200);
                contentElement.append(grid);
                /*var updButton = $("<div id='updButton'>").dxButton({
                    text: "Update grid",
                    onClick: function () {
                        var grid = $("#gridContainer").dxDataGrid("instance");
                        grid.columnOption(0, 'visible', false);
                    }
                });
                contentElement.append(updButton);*/
            },
            showTitle: true,
            showCloseButton: false,
            title: self.getTranslation("DG_SETTINGS_TITLE"),
            visible: false,
            dragEnabled: false,
            closeOnOutsideClick: true,
            toolbarItems :this._getPopupToolbarItems(self),
            width:"768px",
            onShowing:function(e){
                e.component.$content().addClass("advanced-settings-popup-content");
                e.component.overlayContent().addClass("advanced-settings-popup");
                setTimeout(function(){
                    let gridHeight = e.component.$content().height();
                    e.component.$content().find('.table-settings-grid').dxDataGrid('instance').option("height",gridHeight);
                }, 0);
            },
            onShown: function(e){
                setTimeout(function(){
                    let gridHeight = e.component.$content().height();
                    e.component.$content().find('.table-settings-grid').dxDataGrid('instance').option("height",gridHeight);//repaint();
                }, 0);
                
                
            }
        }
    }

    private _getPopupToolbarItems = function(self) {
        var that = this;
        return [
            {
                toolbar: "bottom",
                location: "before",
                widget: "dxButton",
                options: {
                    text: self.getTranslation("DG_RESET"), //dx.localization.formatMessage("RESET",[]),
                    elementAttr: {
                        class: " aux-button btn--secondary",
                    },
                    onClick: function(e) {
                        that.resetHandler();
                       
                        // that._filterBuilder.option("value", filter);
                        // that._filterBuilderPopup.hide();
                    }
                }
            },
            {
                toolbar: "bottom",
                location: "after",
                widget: "dxButton",
                options: {
                    text: self.getTranslation("DG_CANCEL"), // dx.localization.formatMessage("Cancel",[]),
                    elementAttr: {
                        class: " aux-button btn--secondary",
                    },
                    onClick: function(e) {
                        that.settingsPopupInstance.hide();
                    }
                }
            },
            {
                toolbar: "bottom",
                location: "after",
                widget: "dxButton",
                options: {
                    text: self.getTranslation("DG_APPLY"), // dx.localization.formatMessage("APPLY",[]),
                    elementAttr: {
                        class: " aux-button btn--call-to-action",
                    },
                    onClick: function(e) {
                        // var filter = that._filterBuilder.option("value");
                        // that.option("filterValue", filter);
                        that.settingsPopupInstance.hide();
                        that.applyHandler(self);
                        
                    }
                }
            },
        ];
    }

    private _popupContent(self, gridContainer, columns, columnData,gridHeight) {
        this._gridInstance = gridContainer.dxDataGrid({
            dataSource: {
                store: columnData,
                sort: 'visibleIndex',   
                search: 'columnName'                 
            },
            onInitialized: this.handleOnInitialized.bind(this, self),
            onContentReady: this.handleContentReadyAction.bind(this, self),
            /*stateStoring: {
                enabled: true,
                type: 'custom',
                customSave: function(gridState) {
                    //Send gridState to your server using jQuery.ajax;
                    $.ajax("");
                },
                customLoad: function() {
                    var d = $.Deferred();
                    $.ajax("").done(function(data) {
                        d.resolve(data);
                    });
                    return d.promise();
                }
            },*/
            columns: columns,
            showColumnLines:false,
            editing: {
                allowUpdating: true,
                mode: "batch"
            },
            height:gridHeight,
            scrolling: {
                mode: "standard",//"infinite standard virtual"
                showScrollbar:'onHover'
            },
            loadPanel:{
                enabled:false,
                showIndicator:false
            },
            sorting:{
                mode:"none"
            },
            paging:{
                enabled: false,
                pageSize: 10
            },
            pager:{
                visible: false,
                allowedPageSizes: [5, 10, 15, 20],
                infoText: '0 - 0 ' + self._resourcesText["DG_PAGER_INFO_TEXT_OF"] + ' 0 ' + self._resourcesText["DG_PAGER_INFO_TEXT_RESULTS"],
                showNavigationButtons: self.showNavigationButtons,
                showPageSizeSelector: self.showPageSizeSelector,
                showInfo: true
            },            
            searchPanel: {
                visible: true,
                placeholder: self._resourcesText["DG_SEARCH_TABLE"]
            },
            hoverStateEnabled: true,
            /*onCellClick: function(e:any){
                if( e.parentType === "dataRow" && e.dataField === "showColumn" ){
                    e.editorOptions.disabled = !e.row.data.showColumn;
                    //console.log(e.row.data);
                }

            },*/
            onEditorPreparing: function(e:any){
                 if( e.parentType === "dataRow" && e.dataField === "showColumn" ){
                    e.editorOptions.disabled = !e.row.data.allowEditing;
                }
                if( e.parentType === "dataRow" && e.dataField === "freezeColumnLeft" ){
                    e.editorOptions.disabled = !e.row.data.allowEditing;
                }
                /*if( e.parentType === "dataRow" && e.dataField === "freezeColumnRight" ){
                    e.editorOptions.disabled = e.row.data.disableFreezeColumnRight;
                }
                if( e.parentType === "dataRow" && e.dataField === "freezeColumnLeft" ){
                    e.editorOptions.disabled = e.row.data.disableFreezeColumnLeft;
                }*/
            },
            onToolbarPreparing: function(e:any) {
                //replace close icon for search
                e.component.$element().find('.dx-row.dx-column-lines .dx-show-clear-button .dx-icon.dx-icon-clear').addClass('icomoon').addClass('icon-multiply').removeClass('dx-icon-clear');
                e.toolbarOptions.items.forEach(toolbarOption =>{
                    if(toolbarOption.name === "searchPanel"){
                        toolbarOption.location = 'before';
                    } else{
                        toolbarOption.visible = false;
                    }
                });
            },
        })

        this._gridInstance = this._gridInstance.dxDataGrid('instance');
    }

    private handleOnInitialized(self, e){
        //keeping it since it might be required later
    }

    private handleContentReadyAction(self, e){
        this.updateTotalCountMessage(self, e);
        //let pager = this._gridInstance.getView("pagerView")._getPager();
        //utils.renderNavigateButton(pager);
        //utils.renderPagesSizeChooser(pager, self);
        var gridContainer = e.component.$element();
        utils.toggleSearchPanelVisible(self, gridContainer, true);
    }

    private updateTotalCountMessage(self, e){
        var dataGridInstance = this._gridInstance;
        var ttlCount = dataGridInstance && dataGridInstance.totalCount() > 0 ? dataGridInstance.totalCount() : 0;
        var fromRowNumber = (dataGridInstance.pageIndex() * dataGridInstance.pageSize() + 1);
        var toRowNumber = ((dataGridInstance.pageIndex() + 1) * dataGridInstance.pageSize());
        if(fromRowNumber && toRowNumber){
            e.component.option('pager.infoText', (ttlCount > 0 ? fromRowNumber : 0) +" - " + (toRowNumber  > ttlCount  ? ttlCount :  toRowNumber)  +" " + self._resourcesText["DG_PAGER_INFO_TEXT_OF"] +" " + ttlCount + " "+ self._resourcesText["DG_PAGER_INFO_TEXT_RESULTS"]);      
        }
    }

    private showPopup = function(self) {
        var popupOptions = {};
        let gridInstance:any = $(self).find('.gridContainer').dxDataGrid('instance');
        let columns = gridInstance.getController('columns').getColumns();
        let columnsData = utils.getColumnData(columns);
        this.columnsData = columnsData;
        //this.columnsData.push(...columnsData);
        // this.processColumnData(columnsData);

        $.extend(popupOptions, this._getPopupOptions(self, columnsData));
        
        if(this.settingsPopupInstance) { 
            $(".settings-popup .popup").remove();
        }
        var $popupContainer = $("<div />")
                                .addClass("popup")
                                .appendTo($(self.element).find('.settings-popup'));
        this.settingsPopupInstance = $popupContainer.dxPopup(popupOptions).dxPopup("instance");
        this.settingsPopupInstance.show();
        //utils.changeSpinner();
    };

    private reorderData = function(data, position, order){
        for(var i=0;i< data.length; i++){
            if(order === "up"){
                if(data[i].visibleIndex === position){
                    data[i].visibleIndex--;
                }
                else if(data[i].visibleIndex === position - 1 ){
                    data[i].visibleIndex++;
                }
            }
            else if(order === "down"){
                if(data[i].visibleIndex === position){
                    data[i].visibleIndex++;
                }
                else if(data[i].visibleIndex === position + 1 ){
                    data[i].visibleIndex--;
                }
            }
        }
        // this.processColumnData(data);
    }

    private processColumnData = function(columnData){
        let middle = Math.round(columnData.length / 2);
        for (var i = 0; i < columnData.length; i++) {
            if(columnData[i].visibleIndex <= middle - 1 ){
                columnData[i].disableFreezeColumnRight = true;
            }
            else{
                columnData[i].disableFreezeColumnRight = false;
            }
            if(columnData[i].visibleIndex >= middle - 1) {
                columnData[i].disableFreezeColumnLeft = true;
            }
            else{
                columnData[i].disableFreezeColumnLeft = false;
            }
        }
    }

    private resetHandler = function(){
        // not handling reorder 
        // TODO Need to handle reorder
        this.settingsPopupInstance._$popupContent.find('.table-settings-grid').dxDataGrid('instance').cancelEditData();
        this.columnsData.forEach(column => {
            column.visibleIndex = column.originalOrder;       
        });
        this._gridInstance.refresh();
        this._gridInstance.repaint();
    }

    private applyHandler = function(self){
        let gridInstance:any = $(self).find('.gridContainer').dxDataGrid('instance');
        gridInstance.beginCustomLoading();
        let that = this;
        let advancedSettingsGridInstance = this.settingsPopupInstance._$popupContent.find('.table-settings-grid').dxDataGrid('instance');
        this.settingsPopupInstance._$popupContent.find('.table-settings-grid').dxDataGrid('instance').saveEditData()
            .then(function(){
                // utils.changeSpinner();
                utils.tryMethod(self, 'gridPreferencesCallback', advancedSettingsGridInstance.getDataSource().items());
                
                //utils.changeSpinner();
                setTimeout(that.updateColumnChanges,10,that, self,advancedSettingsGridInstance.getDataSource().items())
                //that.updateColumnChanges(self,advancedSettingsGridInstance.getDataSource().items());
            });
    }

    private updateColumnChanges(that,self,columnData){

        let gridInstance:any = $(self).find('.gridContainer').dxDataGrid('instance');
        columnData && columnData.pageSize && gridInstance.pageSize() !== columnData && columnData.pageSize !== 0 ? gridInstance.pageSize(columnData.pageSize): '';
        //gridInstance.beginCustomLoading();
        //utils.changeSpinner();
        let _columnData = columnData.columns || columnData;
        _columnData.forEach(column => {
            let columnOptions = gridInstance.columnOption(column.columnName);

            if(columnOptions){
                let hasChanges = false;
                if(columnOptions["visibleIndex"] !== column.visibleIndex 
                    || columnOptions["visible"] !== column.showColumn
                    || that.computeFixedPositionChange(columnOptions, column)
                    || columnOptions["sortOrder"] !== column.sortOrder
                    || columnOptions["width"] !== column.columnResizeWidth
                    || columnOptions["groupIndex"] !== column.groupIndex){ 
                        hasChanges = true;
                }
                if(hasChanges){                    
                    columnOptions["visibleIndex"] = column.visibleIndex;
                    columnOptions["visible"] = column.showColumn;
                    if(column.freezeColumnRight || column.freezeColumnLeft){
                        columnOptions["fixed"] = true;
                        columnOptions["fixedPosition"] = column.freezeColumnLeft ? "left" : "";
                    }
                    else if(column.freezeColumnLeft === false && typeof columnOptions["fixedPosition"] !== "undefined"){
                        columnOptions["fixed"] = false;
                        columnOptions["fixedPosition"] = undefined;
                    }
                    columnOptions["sortOrder"] = column.sortOrder;
                    if(column.groupIndex !== ""){
                        columnOptions["groupIndex"] = parseInt(column.groupIndex);
                    }
                    if(column.columnResizeWidth !== 0){
                        columnOptions["width"] = column.columnResizeWidth;
                    }
                    
                    gridInstance.columnOption(column.columnName, columnOptions);
                }
            }
            
        });
        setTimeout(function(){
            gridInstance.endCustomLoading();
        },100);
        //       
    }

    private computeFixedPositionChange(columnOptions, column) {
        if(columnOptions["fixedPosition"] !== "left" && columnOptions["fixedPosition"] !== "" && typeof columnOptions["fixedPosition"] !== "undefined"){
            return true;
        }
        if((column["freezeColumnLeft"] && columnOptions["fixedPosition"] !== "left") || (column["freezeColumnLeft"] === false && columnOptions["fixedPosition"] === "left")){
            return true;
        }
        return false;
    }


    updateRow(e){

    }

}


export default SettingsConfig;