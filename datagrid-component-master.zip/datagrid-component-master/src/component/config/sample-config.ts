


export class SampleConfig {

    

    constructor(self){

    }

    // method to return whether the configruation needs to enabled or not
    isEnabled(){
        // check for condition to enable the feature
        return true;
    }

    // method to add toolar buttons is required
    onToolbarPreparing(e,self){

    }

}