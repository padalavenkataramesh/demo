export default class AdvancedFilterConfig {

    private gridInstance;

    constructor(self: any) {


    }

    isEnabled(self) {
        return self.filterPanelVisible;
    }

    updateConfigData(self, configData) {

        let filtetCOnfigData = {
            filterBuilder: {
                maxGroupLevel: 0,
                filterOperationDescriptions:{
                    between:self.getTranslation("DG_FILTER_SELECTION_BETWEEN"),
                    contains:self.getTranslation("DG_FILTER_SELECTION_CONTAINS"),
                    endsWith:self.getTranslation("DG_FILTER_SELECTION_ENDSWITH"),
                    equal:self.getTranslation("DG_FILTER_SELECTION_EQUAL"),
                    greaterThan:self.getTranslation("DG_FILTER_SELECTION_GREATERTHAN"),
                    greaterThanOrEqual:self.getTranslation("DG_FILTER_SELECTION_GREATERTHANOREQUAL"),
                    isBlank:self.getTranslation("DG_FILTER_SELECTION_ISBLANK"),
                    isNotBlank:self.getTranslation("DG_FILTER_SELECTION_ISNOTBLANK"),
                    lessThan:self.getTranslation("DG_FILTER_SELECTION_LESSTHAN"),
                    lessThanOrEqual:self.getTranslation("DG_FILTER_SELECTION_LESSTHANOREQUAL"),
                    notContains:self.getTranslation("DG_FILTER_SELECTION_NOTCONTAINS"),
                    notEqual:self.getTranslation("DG_FILTER_SELECTION_NOTEQUAL"),
                    startsWith:self.getTranslation("DG_FILTER_SELECTION_STARTSWITH"),
                },
                groupOperationDescriptions: {
                    and: self.getTranslation("DG_FILTER_SELECTION_AND"),
                    or: self.getTranslation("DG_FILTER_SELECTION_OR"),
                    notAnd: self.getTranslation("DG_FILTER_SELECTION_NOTAND"),
                    notOr: self.getTranslation("DG_FILTER_SELECTION_NOTOR")
                },
                elementAttr: {
                    class: "aux-filter-builder",
                },
                onEditorPrepared: this._handleFilterBuilderContentReady
            },
            filterBuilderPopup: {
                showCloseButton: false,
                title:self.getTranslation("DG_FILTER_TITLE"),
                toolbarItems: this.getFilterBuilderToolbarItems(self)
            }
        }

        _.merge(configData,filtetCOnfigData)
    }


    onToolbarPreparing(e, self) {
        this.gridInstance = self.getGridInstance();
        var dataGrid = e.component;
        var that = this;
        e.toolbarOptions.items.push({
            location: "before",
            widget: "dxButton",
            sortIndex: 41,
            options: {
                icon: " icomoon icon-collection-filter",
                elementAttr: {
                    class: " aux-button btn--secondary",
                },
                onClick: function (e) {
                    e.event.stopPropagation();
                    that.gridInstance.option("filterBuilderPopup.visible", true);
                    // that.onExporting(self,e,dataGrid)
                }
            }
        });
    }

    getFilterBuilderToolbarItems(self) {

        return [
            {
                toolbar: "bottom",
                location: "before",
                widget: "dxButton",
                options: {
                    text: self.getTranslation("DG_RESET"), // dx.localization.formatMessage("RESET"),
                    elementAttr: {
                        class: " aux-button btn--secondary",
                    },
                    onClick: function (e) {
                        let dataGridInstance : any = self.getGridInstance();
                        let that = dataGridInstance.getView("filterBuilderView");

                        var filter = that.option("filterValue");
                        that._filterBuilder.option("value", filter);
                        // that._filterBuilderPopup.hide();
                    }
                }
            },
            {
                toolbar: "bottom",
                location: "after",
                widget: "dxButton",
                options: {
                    text: self.getTranslation("DG_CANCEL"), // dx.localization.formatMessage("Cancel"),
                    elementAttr: {
                        class: " aux-button btn--secondary",
                    },
                    onClick: function (e) {
                        let dataGridInstance: any = self.getGridInstance();
                        let that = dataGridInstance.getView("filterBuilderView");
                        that._filterBuilderPopup.hide();
                    }
                }
            },
            {
                toolbar: "bottom",
                location: "after",
                widget: "dxButton",
                cssClass: "dx-primary",
                options: {
                    text: self.getTranslation("DG_APPLY"), // dx.localization.formatMessage("APPLY"),
                    elementAttr: {
                        class: " aux-button btn--call-to-action",
                    },
                    onClick: function (e) {
                        let dataGridInstance: any = self.getGridInstance();
                        let that = dataGridInstance.getView("filterBuilderView");
                        var filter = that._filterBuilder.option("value");
                        that.option("filterValue", filter);
                        that._filterBuilderPopup.hide();
                    }
                }
            },
        ]
    }

    _handleFilterBuilderContentReady(e) {
        var builderContent = e.element.find(".dx-filterbuilder>.dx-filterbuilder-group");
        var actionHolder = $("<div/>").addClass("dx-filterbuilder-group-item");
        builderContent.append(actionHolder);
        builderContent.find(".dx-filterbuilder-action-icon.dx-icon-plus.dx-filterbuilder-action").appendTo(actionHolder);
        // 
    }


}