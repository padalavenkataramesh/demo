import ToolbarHelper  from "../helpers/toolbar-helper";
import Utils from "../helpers/utils";

const utils = new Utils();

class DefaultConfig {
    public vm: any;
    public defaultConfig: any;
    private toolbarHelper: any;
    
    constructor(self: any) {
        let that = this;
        this.vm = self;
        const toolbarHelper = new ToolbarHelper();
        this.toolbarHelper = toolbarHelper;
        this.defaultConfig = {
            allowColumnReordering: self.allowColumnReordering,
            allowColumnResizing: self.allowColumnResizing,
            columnResizingMode : self.columnResizingMode,
            columnAutoWidth: self.columnAutoWidth,
            rowAlternationEnabled: self.rowAlternationEnabled,
            selection: this.selectionConfig(self),
            hoverStateEnabled: true,
            scrolling: {
                mode: self.scrollType,
                rowRenderingMode: self.rowRenderingMode
            },
            grouping: {
                autoExpandAll: self.autoExpandGroup,
                contextMenuEnabled: self.contextMenuEnabled
            },
            summary: {
                groupItems: [{
                    // column: "Id",
                    // summaryType: "count"
                }]
            },
            groupPanel: {
                visible: self.showGroupingPanel
            },
            masterDetail: {
                enabled : self.enableMasterDetail,
                template : this.loadMasterDetailTemplate.bind(that,self)
            },
            headerFilter: {
                visible: self.showHeaderFilter
            },
            sorting: this.loadSortingConfig(self),
            loadPanel: this.loadPanelConfig(self),
            filterPanel: this.filterPanelConfig(self),
            filterRow: this.filterRowonfig(self),
            noDataText: self._resourcesText['DG_NO_DATA_CAPTION'],
            editing: this.editConfig(self),
            wordWrapEnabled: self.wordWrapEnabled,
            pager: this.pagerConfig(self),
            columnChooser: this.columnChooserConfig(self),
            searchPanel: this.searchPanelConfig(self),
            //columnHidingEnabled: true,
            export: this.exportConfig(self),
            onExporting: utils.onExportingData.bind(utils, self), 
            onExported: utils.onExportedData.bind(utils, self), 
            onToolbarPreparing: this.toolbarPreparing.bind(this, self),
            onEditorPreparing: this.editorPreparing.bind(null, self),
            onEditingStart: utils.onEditingStart.bind(utils, self),
            onSelectionChanged: utils.handleSelectionChanged.bind(utils, self),
            customizeExportData : utils.onCustomizeExportData.bind(utils, self),
            onContextMenuPreparing : utils.onContextMenuPreparing.bind(utils, self)
        };
    }

    private editorPreparing(self, e){
        utils.onEditorPreparing(self, e);
    }    

    private loadSortingConfig(self) {
        return {
            mode: self.sortingMode, //'multiple' | 'none' | 'single'
            ascendingText: self._resourcesText["DG_SORT_ASCENDING_CAPTION"],
            descendingText: self._resourcesText["DG_SORT_DESCENDING_CAPTION"],
            clearText: self._resourcesText["DG_CLEAR_SORTING_CAPTION"],
            showSortIndexes: false
        };
    }

    private editConfig(self) {
        return {
            mode: self.editMode, //Accepted Values: 'batch' | 'cell' | 'row' | 'form' | 'popup'
            allowUpdating: self.allowRowEditing,
            allowAdding: self.allowRowAdding,
            allowDeleting: self.allowRowDeleting,
            texts: {
                addRow: self._resourcesText["Dg_Add_Row_Help_Text"],
                cancelAllChanges: self._resourcesText["DG_CANCEL_CHANGES_HELP_TEXT"],
                deleteRow: self._resourcesText["DG_DELETE"],
                saveAllChanges: self._resourcesText["DG_SAVE_CHANGES_HELP_TEXT"],
                undeleteRow: self._resourcesText["DG_UNDELETE"]
            }
        };
    }

    private loadPanelConfig(self) {
        return {
            enabled: self.loaderPanelEnabled,
            showPane: false,
            text: '',
            shading: true,
            shadingColor: 'rgba(255, 255, 255, 0.6)'
        };
    }

    private filterPanelConfig(self) {
        return {
            filterEnabled: true,
            texts: {},
            visible: self.filterPanelVisible
            //Type: {}
        }
    }

    private filterRowonfig(self) {
        return {
            applyFilter: "auto", //Accepted Values: 'auto' | 'onClick'
            applyFilterText: self._resourcesText["DG_FILTER_ROW_APPLY_FILTER_TEXT"],
            betweenStartText: self._resourcesText["DG_FILTER_ROW_BETWEEN_STARTTEXT"],
            betweenEndText: self._resourcesText["DG_FILTER_ROW_BETWEEN_ENDTEXT"],
            resetOperationText: self._resourcesText["DG_CLEAR_FILTER_TEXT"],
            showOperationChooser: self.rowFilterAdvancedOperators,
            visible: self.showRowFilter
        };
    }

    private pagerConfig(self) {
        return {
            visible: self.showPaging,
            allowedPageSizes: self.allowedPageSizes,
            infoText: '{0} - {0} ' + self._resourcesText["DG_PAGER_INFO_TEXT_OF"] +' {0} '+ self._resourcesText["DG_PAGER_INFO_TEXT_RESULTS"],
            showNavigationButtons: self.showNavigationButtons,
            showPageSizeSelector: self.showPageSizeSelector,
            showInfo: true
        };
    }    

    private columnChooserConfig(self) {
        let columnChooserMode = this.getColumnChooserMode(self);
        return {
            enabled: self.hasColumnChooser && (columnChooserMode === "draganddrop"),
            mode: 'dragAndDrop',//Accepted Values: 'dragAndDrop' | 'select' | 'advanced'
            //width: 40,
            title: self._resourcesText["DG_SHOW_HIDE_COLUMN"],
            allowSearch: true, 
            //emptyPanelText: 'Drag a column here to hide it' //this applies by default
        };
    }

    private getColumnChooserMode(self){
        let columnChooserMode;     
        if(typeof self.columnChooserMode === 'string'){
            return self.columnChooserMode.toLowerCase();
        }else if (typeof self.columnChooserMode === 'object'){
            self.columnChooserMode.forEach(mode => {
                mode = mode.toLowerCase();
                if(mode === 'draganddrop'){
                    columnChooserMode = mode;
                }
            });
        }
        return columnChooserMode;
    }

    private searchPanelConfig(self) {
        return {
            //allowSearch: false,
            placeholder: self._resourcesText["DG_SEARCH_TABLE"],
            visible: self.showSearchPanel
        };
    }  

    private exportConfig(self) {
        return {
            enabled: self.allowExportData && !self.exportToCSVEnabled,
            fileName: self._resourcesText["DG_EXPORT_FILENAME"],
            allowExportSelectedData: self.allowExportSelectedData
        }
    }

    public toolbarPreparing(self, e) {
        utils.onToolbarPreparing(self, e);
        self.toolbarItems = e.toolbarOptions.items;
        var searchPanel = this.getSerachPanel(self);
        if(searchPanel) searchPanel.location= 'before'; //moving serach panel to left
        let loadButtons = self._loadConfigurableButtons ? self._loadConfigurableButtons():null;
        if (loadButtons && loadButtons.length){
            this.toolbarHelper.renderToolbarButtons(self, e, loadButtons);
        }
        self.configProvider.executeConfigMethod("onToolbarPreparing",self,[e,self]);
    }

    private getSerachPanel(self){
        return _.find(self.toolbarItems, function (toolbarItem) { return  toolbarItem.name === "searchPanel"; });
    }

    private selectionConfig(self) {
        return {
            allowSelectAll: self.allowSelectAll,
            mode: self.selectionMode, //default: single: Accepted Values: 'multiple' | 'none' | 'single'
            selectAllMode: self.selectAllMode, //Accepted Values: 'allPages' | 'page'
            showCheckBoxesMode: self.showCheckBoxesMode //Accepted Values:'always' | 'none' | 'onClick' | 'onLongTap'
        }
    }

    private loadMasterDetailTemplate(self,container,options){

        let colspan = parseInt(container[0].getAttribute("colspan"));
        if(!isNaN(colspan)){
            container[0].setAttribute("colspan",colspan); // +2 not needed in above v19
        }
        if(!!(self.loadMasterDetailTemplate && self.loadMasterDetailTemplate.constructor && self.loadMasterDetailTemplate.call && self.loadMasterDetailTemplate.apply)){
            self.loadMasterDetailTemplate(container,options);
        }
      
    }
}

export default DefaultConfig;