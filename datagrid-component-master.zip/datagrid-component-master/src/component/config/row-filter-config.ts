export default class RowFilterConfig {    

    constructor(self){

    }

    isEnabled(self){
        return self.showRowFilter;
    }

    onToolbarPreparing(e,self){
        var dataGrid = e.component;
        var that = this;        
        e.toolbarOptions.items.push({
            location: "before",
            widget: "dxButton",
            options: {
                icon: " icomoon icon-search",
                elementAttr: {
                    id: "icon-search",
                    class: " aux-button btn--secondary icomoon show-row-filter",
                    title: self._resourcesText["DG_ROW_FILTER_TOGGLE_CAPTION"] 
                },
                onClick: function(e) {
                    e.event.stopPropagation();
                    var enabled = $(self.element).find('#icon-search').data('isfilterenabled');
                    //dataGrid.option("filterRow.visible",!enabled);

                    if(enabled){
                        $(self.element).find(".dx-row.dx-column-lines.dx-datagrid-filter-row").addClass("dx-hidden");
                        $(self.element).find(".dx-row.dx-column-lines.dx-header-row").addClass("filter-hidden");
                    }
                    else {
                        $(self.element).find(".dx-row.dx-column-lines.dx-datagrid-filter-row").removeClass("dx-hidden");
                        $(self.element).find(".dx-row.dx-column-lines.dx-header-row").removeClass("filter-hidden");
                    }
                    //$(self.element).find(".dx-row dx-column-lines.dx-datagrid-filter-row").toggleClass("dx-hidden",!enabled);
                    //self.repaint();
                    $(self.element).find('#icon-search').data('isfilterenabled', !enabled);
                    !enabled ? $(self.element).find('#icon-search').addClass('filter-opened') : $(self.element).find('#icon-search').removeClass('filter-opened');           

                },
                onContentReady: ((options) => { 
                    options.element.attr('data-isfilterenabled', self.isRowFilterOpened); 
                    _.delay(function() {
                        $(self.element).find('#icon-search').data('isfilterenabled', self.isRowFilterOpened);
                        self.isRowFilterOpened ? $(self.element).find('#icon-search').addClass('filter-opened') : $(self.element).find('#icon-search').removeClass('filter-opened');   
                        //replacing close filter icon
                        $(self.element).find('.dx-row.dx-column-lines .dx-show-clear-button .dx-icon.dx-icon-clear').addClass('icomoon').addClass('icon-multiply').removeClass('dx-icon-clear');      
                    }, 100);

                }).bind(null)
            }
        });
        e.toolbarOptions.items.push({
            location: "before",
            widget: "dxButton",
            options: {
                icon: " icomoon icon-close-tab",
                text: self._resourcesText["DG_ROW_FILTER_APPLIED_SINGLE_COUNT"],//" 0 filters applied"
                elementAttr: {
                    class: " aux-button btn--secondary icomoon applied-filter-count"
                },
                stylingMode: "outlined", 
                onClick: function(e) {
                    e.event.stopPropagation();
                },
                onContentReady: ((options) => { 
                    $(options.element.find(".icon-close-tab")).click(function(){
                        self.getGridInstance().clearFilter();
                        $(self.element).find(".applied-filter-count").addClass("dx-hidden");
                    });
                }).bind(null)
            }
        });
    }

    public updateView(self){
        var enabled = $(self.element).find('#icon-search').data('isfilterenabled');
     
        if(enabled){
            $(self.element).find(".dx-row.dx-column-lines.dx-datagrid-filter-row").removeClass("dx-hidden");
            $(self.element).find(".dx-row.dx-column-lines.dx-header-row").removeClass("filter-hidden");
        }
        else {
            $(self.element).find(".dx-row.dx-column-lines.dx-datagrid-filter-row").addClass("dx-hidden");
            $(self.element).find(".dx-row.dx-column-lines.dx-header-row").addClass("filter-hidden");
        }
        var columnMap = this.mapFilterOptions(self.getGridInstance().getCombinedFilter());
        var count = columnMap.and.length + columnMap.or.length;
        if(count === 1){
            $($(self.element).find(".applied-filter-count .dx-button-text")).html(count + " " + self._resourcesText["DG_ROW_FILTER_APPLIED_SINGLE_COUNT"]);
        }
        else {
            $($(self.element).find(".applied-filter-count .dx-button-text")).html(count + " " + self._resourcesText["DG_ROW_FILTER_APPLIED_MULTIPLE_COUNT"]);
        }
        if(count === 0){
            $(self.element).find(".applied-filter-count").addClass("dx-hidden");
        }else {
            $(self.element).find(".applied-filter-count").removeClass("dx-hidden");
        }
    }

    private mapFilterOptions(filterOptions) {
        var columnMap = {
            and: [],
            or: [],
            columns: {}
        };
        if(filterOptions){
            var tempFilterOptions = JSON.parse(JSON.stringify(filterOptions));
            this.processFilterArray(tempFilterOptions, null, 0);
            this.processAndOrFilter(tempFilterOptions, columnMap);
            this.processColumnMap(columnMap);
        }
        return columnMap;
    }


    private processColumnMap(columnMap) {

        columnMap.and.forEach(function (item) {
            var options = item.split("|");
            var colOptions = {
                selector : options[0],
                operator : options[1],
                query : options[2]
            };
            if (!columnMap.columns[colOptions.selector]) {
                columnMap.columns[colOptions.selector] = this.getColumnMap();
            }
            columnMap.columns[colOptions.selector].and.push(colOptions);
        }.bind(this));

        columnMap.or.forEach(function (item) {
            var options = item.split("|");
            var colOptions = {
                selector : options[0],
                operator : options[1],
                query : options[2]
            };
            if (!columnMap.columns[colOptions.selector]) {
                columnMap.columns[colOptions.selector] = this.getColumnMap();
            }
            columnMap.columns[colOptions.selector].or.push(colOptions);
        }.bind(this));
    }

    private getColumnMap() {
        return {
            and: [],
            or: []
        };
    }

    private processAndOrFilter(filterArray, columnMap) {
        if (filterArray && filterArray.length > 0) {
            if (filterArray.length === 1) {
                columnMap.and.push(filterArray[0]);
            }
            else if (filterArray.length >= 3 && filterArray[1] === "and") {
                filterArray = filterArray.filter(function (item, index) {
                    return index % 2 !== 1;
                });
                for (var i = 0; i < filterArray.length; i++) {
                    if (Array.isArray(filterArray[i])) {
                        this.processAndOrFilter(filterArray[i], columnMap);
                    } else if(columnMap.and.indexOf(filterArray[i]) === -1){
                        columnMap.and.push(filterArray[i]);
                    }
                }
            }
            else if (filterArray.length >= 3 && filterArray[1] === "or") {
                filterArray = filterArray.filter(function (item, index) {
                    return index % 2 !== 1;
                });
                for (var j = 0; j < filterArray.length; j++) {
                    if (Array.isArray(filterArray[j])) {
                        this.processAndOrFilter(filterArray[j], columnMap);
                    } else if(columnMap.or.indexOf(filterArray[j]) === -1){
                        columnMap.or.push(filterArray[j]);
                    }
                }
            }

        }
    }

    private processFilterArray(filterArray, filterArrayParent, index) {
        if (filterArray && filterArray.length > 0) {
            for (var i = 0; i < filterArray.length; i++) {
                if (filterArray.length === 3 && !Array.isArray(filterArray[0]) && !Array.isArray(filterArray[1]) && !Array.isArray(filterArray[2])) {
                    if(filterArray[2] === null){
                        filterArray[2] = "IS_NULL";
                    }
                    var st = filterArray.join("|");
                    if (filterArrayParent) {
                        filterArrayParent[index] = st;
                    }
                    else {
                        filterArray.pop();
                        filterArray.pop();
                        filterArray.pop();
                        filterArray.push(st);
                    }
                    break;
                }
                else if (Array.isArray(filterArray[i])) {
                    this.processFilterArray(filterArray[i], filterArray, i);
                }
            }
        }
    }


    private processFilterExpression(columnOptions, filterExpressionFn){
        let andConditions:any = [];
        var orConditions:any = [];
        var andExpression = "";
        var orExpression = "";
        columnOptions.and.forEach(function (item) {
            andConditions.push(item);
        });

        columnOptions.or.forEach(function (item) {
            orConditions.push(item);
        });
        andExpression = andConditions.join(" AND ");
        orExpression = orConditions.join(" OR ");

        var totalConditions = 0;
        if(!!andExpression || !!orExpression){
            columnOptions.filterExpression = "";
            if (!!andExpression) {
                columnOptions.filterExpression += (andConditions.length>1 ?" ( ":"") + andExpression + (andConditions.length>1 ?" ) ":"");
                totalConditions++;
            }
            if (!!orExpression) {
                columnOptions.filterExpression += (orConditions.length>1 ?" ( ":"") + orExpression + (orConditions.length>1 ?" ) ":"");
                totalConditions++;
            }
            if(totalConditions > 1){
                columnOptions.filterExpression = "( " + columnOptions.filterExpression + " )";
            }
        }
    }


}