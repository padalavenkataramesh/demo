import Utils from "../helpers/utils";
const utils:any = new Utils();

class PagerConfig {

    constructor(self){

    }

    public isEnabled(self){
        return true;
    }

    public updateView(self){
        let pager = self.getGridInstance().getView("pagerView")._getPager();
        let that = this;
        if(pager && !pager.isOverriden){
            pager.isOverriden = true;

            let _getPages = pager._getPages;
            pager._getPages = function(currentPage, count){
                that.getPages.bind(pager)(pager,currentPage, count);
                return _getPages.bind(pager)(currentPage, count);
            }.bind(pager);

            // let _renderInfo = pager._renderInfo;
            // pager._renderInfo = function(){
            //     _renderInfo.bind(pager)();
            //     return that.renderInfo.bind(pager)(pager,self);
            // }.bind(pager);

            let _renderNavigateButton =  pager._renderNavigateButton;
            pager._renderNavigateButton = function(direction){
                _renderNavigateButton.bind(pager)(direction);
                utils.renderNavigateButton.bind(pager)(pager);
            }.bind(pager);

            let _updateButtonsState =  pager._updateButtonsState;
            pager._updateButtonsState = function(pageIndex){
                that.updateButtonsState.bind(pager)(pager,pageIndex);
            }.bind(pager);

            let _renderPagesSizeChooser =  pager._renderPagesSizeChooser;
            pager._renderPagesSizeChooser = function(){
                _renderPagesSizeChooser.bind(pager)();
                utils.renderPagesSizeChooser.bind(pager)(pager, self);
            }.bind(pager);

            let _renderPagesChooser = pager._renderPagesChooser;
            pager._renderPagesChooser = function(){
                _renderPagesChooser.bind(pager)();
                that.renderPagesChooser.bind(pager)(pager,self);
            }

            let _updateLightMode = pager._updateLightMode;
            pager._updateLightMode = function(){
                setTimeout(function(){
                    that._updateLightMode.bind(pager)(pager,self);
                    _updateLightMode.bind(pager)();  
                },10)
            }

            let _renderLightPages = pager._renderLightPages;
            pager._renderLightPages = function(){
                //_renderLightPages.bind(pager)();
                /*if(pager._pageIndexEditor){
                    pager._pageIndexEditor.option({
                        disabled:true,
                        onChange: function(e) {
                            //pager.option("pageIndex", e.value);
                            e.event.stopPropagation();
                        }
                    });
                    
                }*/

                let dataGridInstance = self.getGridInstance();
                let pageIndex = dataGridInstance && dataGridInstance.pageIndex && dataGridInstance.pageIndex();
                this._$infoLight = $("<div>")
                .addClass("dx-light-pages custom-light-pages")
                //.text(stringUtils.format(infoText, this.selectedPage && this.selectedPage.value(), this.option("pageCount")))
                .text(self.getTranslation("DG_PAGER_PAGE_TEXT")+ " " + (pageIndex + 1) + " " + self.getTranslation("DG_PAGER_INFO_TEXT_OF") + " " + this.option("pageCount"))
                .appendTo(this._$pagesChooser);
                
            }

            let _renderContentImpl = pager._renderContentImpl;
            pager._renderContentImpl = function(){
                that._updateLightMode.bind(pager)(pager,self);
                _renderContentImpl.bind(pager)();
            }

            utils.renderNavigateButton.bind(pager)(pager);
            utils.renderPagesSizeChooser.bind(pager)(pager, self);
            this.renderPagesChooser.bind(pager)(pager,self);
            self.repaint();  
        }
    }

    private getPages(pager, currentPage, count){
        pager.option("hasKnownLastPage",true);
    }

    renderInfo(pager,self){
        let dataGridInstance = self.getGridInstance()
        let ttlCount = dataGridInstance && dataGridInstance.totalCount() > 0 ? dataGridInstance.totalCount() : 0;
        let fromRowNumber = (dataGridInstance.pageIndex() * dataGridInstance.pageSize() + 1);
        let toRowNumber = ((dataGridInstance.pageIndex() + 1) * dataGridInstance.pageSize());
        if(fromRowNumber && toRowNumber){
            //pager.option('infoText', (ttlCount > 0 ? fromRowNumber : 0) +" - " + (toRowNumber  > ttlCount  ? ttlCount :  toRowNumber)  +" " + self._resourcesText["Dg_Pager_Info_Text_Message"] +" " + ttlCount + " Results");  
            let infoText = (ttlCount > 0 ? fromRowNumber : 0) +" - " + (toRowNumber  > ttlCount  ? ttlCount :  toRowNumber)  +" " + self.getTranslation("DG_PAGER_INFO_TEXT_OF") +" " + ttlCount + " "+ self.getTranslation("DG_PAGER_INFO_TEXT_RESULTS");
            $(pager._$element.find('.dx-info')).html(infoText);  
        }
        if (!pager._isInfoHide) {
            pager._infoWidth = pager._$info.outerWidth(true);
        }
    }

    private updateButtonsState(pager, pageIndex){
        
        var nextButton = pager._$element.find(".icon-arrow-right2"),
        prevButton = pager._$element.find(".icon-arrow-left2");

        nextButton.toggleClass("dx-button-disable", pager._isPageIndexInvalid("next", pageIndex));
        prevButton.toggleClass("dx-button-disable", pager._isPageIndexInvalid("prev", pageIndex));
    }

    private renderPagesChooser(pager,self){
        let lightModeEnabled = pager.option("lightModeEnabled");

        if(lightModeEnabled){
            pager._$pagesChooser.find(".dx-info").remove();
            pager._renderInfo();
            pager._$pagesChooser.find(".dx-info").prependTo(pager._$pagesChooser);
            pager._$pagesChooser.find(".dx-info").show();
        }
    }

    private _updateLightMode(pager,self){
        let width  = pager.$element().width();
        if(width <= 800){
            pager.option("lightModeEnabled", true)
        }
        if(width <=600){
            pager._$element.addClass("widget-mode");
        }
        else{
            pager._$element.removeClass("widget-mode");
        }
    }

}

export default PagerConfig;