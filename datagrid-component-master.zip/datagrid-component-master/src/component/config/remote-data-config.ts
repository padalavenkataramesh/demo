import DefaultConfig from "./default-config";
import RemoteDataHelper from "../helpers/remote-data-helper";
import Utils from "../helpers/utils";

const remoteDataHelper = new RemoteDataHelper();
const utils = new Utils();

class RemoteDataConfig{
    public config: any;

    constructor(self: any, cols: any = ''){
        this.config = {
            dataSource: utils.handleRemoteDatasource(self),
            keyExpr: self.dataKey ? self.dataKey : "",
            columns: cols,
            customizeColumns: utils.handleCustomizeColumns.bind(utils, self),
            paging: utils.pagingConfig(self),
            onCellPrepared: remoteDataHelper.handleCellPreparedForRemoteData.bind(null, self, remoteDataHelper),
            onInitNewRow: remoteDataHelper.handleInitNewRow.bind(remoteDataHelper, self),
            onContentReady: remoteDataHelper.handleContentReadyAction.bind(remoteDataHelper, self),
            onRowPrepared: remoteDataHelper.handleRowPrepared.bind(null, self),
            onEditorPrepared: utils.handleEditorPrepared.bind(utils, self),
            onInitialized: utils.handleOnInitialized.bind(utils, self),
            remoteOperations: {
                paging: true,
                sorting: true,
                filtering: true
            },
            pager: {
                visible: true,
            },
            onOptionChanged: utils.onOptionChanged.bind(utils, self),
            onRowInserting: remoteDataHelper.handleRowInserting.bind(null, self),
            onRowUpdating: remoteDataHelper.handleRowUpdating.bind(null, self),            
            onRowRemoving: remoteDataHelper.handleRowRemoving.bind(null, self)
        };

        var defaultCnfg = new DefaultConfig(self).defaultConfig;
        $.extend(this.config, defaultCnfg);
    }
}

export default RemoteDataConfig;