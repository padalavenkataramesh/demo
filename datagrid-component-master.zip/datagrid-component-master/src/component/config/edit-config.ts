import Utils from "../helpers/utils";
const utils:any = new Utils();


class EditConfig {


    constructor(self){

    }

    public isEnabled(self){
        return true;
    }


    public onToolbarPreparing(e,self){
        var dataGrid = e.component;
        var that = this;      
        e.toolbarOptions.items.forEach(toolbarItem => {
            if ( toolbarItem.name === "revertButton" ){
                let onClick = toolbarItem.options.onClick;
                toolbarItem.options.onClick = that.beforeRevertHandler.bind(that, self, onClick);
            }
        });
    }


    private beforeRevertHandler(self, method){
        if(self.onBeforeRevertChangesCallback){
            utils.tryMethod(self, 'onBeforeRevertChangesCallback', this.proceedRevert.bind(this,method));
        }
        else{
            this.proceedRevert(method)
        }
    }

    private proceedRevert(method){
        method();
    }


}

export default EditConfig;