import Utils from "../helpers/utils";
const utils:any = new Utils();


class GroupingConfig {


    constructor(self){

    }

    public isEnabled(self){
        return true;
    }


    public onToolbarPreparing(e,self){
        var dataGrid = e.component;
        var that = this;      
        e.toolbarOptions.items.forEach(toolbarItem => {
            if ( toolbarItem.name === "groupPanel" ){
                let onItemRendered = toolbarItem.onItemRendered;
                toolbarItem.onItemRendered = that.onItemRendered.bind(that, self, onItemRendered);
            }
        });
    }

    public onItemRendered(self,method,e){
        method(e);
        var groupPanel = self.$element.find('.dx-toolbar-items-container');//:has(.dx-datagrid-group-panel)
        if(groupPanel && groupPanel.length){
            $(groupPanel).addClass('has-group-panel');
            if(self.hideSortFromGroupingPanel){
                $(groupPanel).find('.dx-datagrid-group-panel').addClass('hide-sort-indicator');
            }
        } 
    }


    


}

export default GroupingConfig;