

class PropertiesConfig {

    constructor() {

    }

    private getButtons(self: any) {
        return self._loadConfigurableButtons;
    }

    private setButtons(self: any, value: any) {
        self._loadConfigurableButtons = value;
        //self.toolbarHelper.renderToolbars(self); //TODO:not required??
    }

    private getLoader(self: any) {
        return self._loadJSONData;
    }

    private setLoader(self: any, value: object) {
        self._loadJSONData = value;
        self.reload();
    }

    private getBorder(self: any) {
        return self._showGridBorder;
    }

    private setBorder(self: any, value: boolean) {
        self._showGridBorder = value;
    }

    private getResourcesText(self){
        return self._resourcesText;
    }

    private setResourcesText(self: any, resourcesText: any) { 
        if(resourcesText){
            $.extend(self._resourcesText, resourcesText);     
        }
    }

    private getConfigOptions(self: any) {
        return self._configOptions;
    }

    private setConfigOptions(self: any, value: object) {
        self._configOptions = value;
        self.reload();
    }

    public addProperties(self: any) {
        self._loadJSONData = null;
        Object.defineProperty(self, 'loadJSONData', {
            get: this.getLoader.bind(null, self),
            set: this.setLoader.bind(null, self)
        });

        self._configOptions = null;
        Object.defineProperty(self, 'configOptionsCB', {
            get: this.getConfigOptions.bind(null, self),
            set: this.setConfigOptions.bind(null, self)
        });

        // self._dataMode = null;
        // Object.defineProperty(self, 'datamode', {
        //     get: function() { return self._dataMode; }.bind(self),
        //     set: function (value) { 
        //         self._dataMode = value;
        //         if (!self.loadJSONData) {
        //             self.handleRemoteData(self); 
        //         }
        //     }.bind(self)
        // });

        Object.defineProperty(self.element, 'handleRemoteDataLoad', {
            get: function () { return self.handleRemoteDataLoadCallback; }.bind(self),
            set: function (value) { self.handleRemoteDataLoadCallback = value;  }.bind(self)
        });

        Object.defineProperty(self.element, 'handleRemoteDataLoadCB', {
            get: function () { return self.handleRemoteDataLoadCallback; }.bind(self),
            set: function (value) { console.log('handleRemoteDataLoadCB', value); self.handleRemoteDataLoadCallback = value;  }.bind(self)
        });

        Object.defineProperty(self.element, 'onRowSelectCB', {
            get: function () { return self.singleSelectCallback; }.bind(self),
            set: function (value) { self.singleSelectCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'onPageChangeCB', {
            get: function () { return self.pageChangeCallback; }.bind(self),
            set: function (value) { self.pageChangeCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'onRowMultiSelectCB', {
            get: function () { return self.multiSelectCallback; }.bind(self),
            set: function (value) { self.multiSelectCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'onRowPreparedCB', {
            get: function () { return self.rowPreparedCallback; }.bind(self),
            set: function (value) { self.rowPreparedCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'cellTemplateCB', {
            get: function () { return self.cellTemplateCallback; }.bind(self),
            set: function (value) { self.cellTemplateCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'customizeColumnsCB', {
            get: function () { return self.customizeColumnsCallback; }.bind(self),
            set: function (value) { self.customizeColumnsCallback = value; }.bind(self)
        });
        
        Object.defineProperty(self.element, 'customizeColumns', {
            get: function () { return self.customizeColumnsCallback; }.bind(self),
            set: function (value) { self.customizeColumnsCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'cellPreparedCB', {
            get: function () { return self.cellPreparedCallback; }.bind(self),
            set: function (value) { self.cellPreparedCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'editorPreparedCB', {
            get: function () { return self.editorPreparedCallback; }.bind(self),
            set: function (value) { self.editorPreparedCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'onInitNewRowCB', {
            get: function () { return self.onInitNewRowCallback; }.bind(self),
            set: function (value) { self.onInitNewRowCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'onInitializedCB', {
            get: function () { return self.onInitializedCallback; }.bind(self),
            set: function (value) { self.onInitializedCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'onRowInsertingCB', {
            get: function () { return self.onRowInsertingCallback; }.bind(self),
            set: function (value) { self.onRowInsertingCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'onRowUpdatingCB', {
            get: function () { return self.onRowUpdatingCallback; }.bind(self),
            set: function (value) { self.onRowUpdatingCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'onRowRemovingCB', {
            get: function () { return self.onRowRemovingCallback; }.bind(self),
            set: function (value) { self.onRowRemovingCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'onOptionChangedCB', {
            get: function () { return self.onOptionChangedCallback; }.bind(self),
            set: function (value) { self.onOptionChangedCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'onExportingCB', {
            get: function () { return self.onExportingCallback; }.bind(self),
            set: function (value) { self.onExportingCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'onExportedCB', {
            get: function () { return self.onExportedCallback; }.bind(self),
            set: function (value) { self.onExportedCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'onCustomizeExportDataCB', {
            get: function () { return self.onCustomizeExportDataCallback; }.bind(self),
            set: function (value) { self.onCustomizeExportDataCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'onEditorPreparingCB', {
            get: function () { return self.onEditorPreparingCallback; }.bind(self),
            set: function (value) { self.onEditorPreparingCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'onEditingStartCB', {
            get: function () { return self.onEditingStartCallback; }.bind(self),
            set: function (value) { self.onEditingStartCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'onToolbarPreparingCB', {
            get: function () { return self.onToolbarPreparingCallback; }.bind(self),
            set: function (value) { self.onToolbarPreparingCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'headerCellTemplateCB', {
            get: function () { return self.headerCellTemplateCallback; }.bind(self),
            set: function (value) { self.headerCellTemplateCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'gridLoadedCB', {
            get: function () { return self.gridLoadedCallback; }.bind(self),
            set: function (value) { self.gridLoadedCallback = value; }.bind(self)
        });
        
        Object.defineProperty(self.element, 'totalCountCB', {
            get: function () { return self.totalCountCallback; }.bind(self),
            set: function (value) { self.totalCountCallback = value; }.bind(self)
        });

        Object.defineProperty(self.element, 'gridPreferencesCB', {
            get: function () { return self.gridPreferencesCallback; }.bind(self),
            set: function (value) { self.gridPreferencesCallback = value; }.bind(self)
        });

        self._loadConfigurableButtons = null;
        Object.defineProperty(self, 'loadConfigurableButtons', {
            get: this.getButtons.bind(null, self),
            set: this.setButtons.bind(null, self)
        });

        self._toolbarItemClickCallback = null;
        Object.defineProperty(self, 'toolbarItemClickCallback', {
            get: function (self) { return self._toolbarItemClickCallback; }.bind(null, self),
            set: function (self, value) { self._toolbarItemClickCallback = value; }.bind(null, self)
        });

        self._showGridBorder = false;
        Object.defineProperty(self, 'showGridBorder', {
            get: this.getBorder.bind(null, self),
            set: this.setBorder.bind(null, self)
        });

        self._changePageClickCallback = null;
        Object.defineProperty(self, 'changePageClickCallback', {
            get: function (self) { return self._changePageClickCallback; }.bind(null, self),
            set: function (self, value) { self._changePageClickCallback = value; }.bind(null, self)
        });

        Object.defineProperty(self, 'resourcestext', {
            get: this.getResourcesText.bind(null, self),
            set: this.setResourcesText.bind(null, self)
        });

        self._loadMasterDetailTemplate = null;
        Object.defineProperty(self, 'loadMasterDetailTemplate', {
            get: function (self) { return self._loadMasterDetailTemplate; }.bind(null, self),
            set: function (self, value) { self._loadMasterDetailTemplate = value; }.bind(null, self)
        });
            
        self._storePreferences = null;
        Object.defineProperty(self, 'storePreferences', {
            get: function () { return self._storePreferences; }.bind(self),
            set: function (value) { self._storePreferences = value; }.bind(self)
        });

        self._preferenceKey = null;
        Object.defineProperty(self, 'preferenceKey', {
            get: function () { return self._preferenceKey; }.bind(self),
            set: function (value) { self._preferenceKey = value; }.bind(self)
        });

        self._preferenceData = null;
        Object.defineProperty(self, 'preferenceData', {
            get: function () { return self._preferenceData; }.bind(self),
            set: function (value) { self._preferenceData = value; }.bind(self)
        });

        self._columnsData = null;
        Object.defineProperty(self,'columnsData', {
            get: function () { return self._columnsData; }.bind(self),
            set: function (value) { self._columnsData = value; }.bind(self)
        });

        self._isSelectAllCheboxCheckedCallback = null;
        self._isSelectAllCheboxChecked = null;
        Object.defineProperty(self, 'isSelectAllCheckboxCheckedCB', {
            get: function () { return self._isSelectAllCheboxCheckedCallback; }.bind(self),
            set: function (value) { self._isSelectAllCheboxCheckedCallback = value; }.bind(self)
        });

        self.onContextMenuPreparingCallback = null;
        Object.defineProperty(self, 'onContextMenuPreparingCB', {
            get: function () { return self.onContextMenuPreparingCallback; }.bind(self),
            set: function (value) { self.onContextMenuPreparingCallback = value; }.bind(self)
        });  
        self.onBeforeRevertChangesCallback = null;
        Object.defineProperty(self, 'onBeforeRevertChangesCB', {
            get: function () { return self.onBeforeRevertChangesCallback; }.bind(self),
            set: function (value) { self.onBeforeRevertChangesCallback = value; }.bind(self)
        });    
           
    }

   
}

export default PropertiesConfig;