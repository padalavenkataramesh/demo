module.exports = {
    globals: {
        'ts-jest': {
            diagnostics: false
          }
    },
    "transform": {
        "^.+\\.html?$": "html-loader-jest"
    },
    preset: 'ts-jest',
    verbose: true,    
    //setTimeout: 30000,
    testRegex: "(/tests/.*|\\*.(test|spec))\\.(ts|tsx|js)$",
    //testRegex: "(/tests/json-config.(test|spec))\\.(ts|tsx|js)$",
    //testMatch: ["./tests/component/datagrid-controller.test.ts"],
    moduleFileExtensions: ["html", "ts", "tsx", "js"],
    "moduleDirectories": [
        "node_modules",
        "typings"
    ]
    // "collectCoverage": false,
    // "collectCoverageFrom": [
    //     "**/*.{ts,tsx}"
    // ],
    // "coveragePathIgnorePatterns":[
    //     "/node_modules/",
    //     "/coverage/",
    //     "/typings/"
    // ]
};