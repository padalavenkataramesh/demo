requirejs(['require-config'], function (common) {
  requirejs(['demos/json-data/test-master-detail.js']);
});
