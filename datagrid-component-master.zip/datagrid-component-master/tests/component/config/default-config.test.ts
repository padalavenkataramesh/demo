import DefaultConfig from "../../../src/component/config/default-config";
import ToolbarHelper from "../../../src/component/helpers/toolbar-helper";

let dataGrid;
let defaulConfig;
let toolbarHelper;

let mockEditorPreparing;
let mockEditorPreparingObj;
let mockEditorPreparingBound;

let mockToolbarPreparing;
let mockToolbarPreparingObj;
let mockToolbarPreparingBound;

const resourcesText = {    
    'Dg_Sort_Ascending_Caption': 'Sort Ascending',
    'Dg_Sort_Descending_Caption': 'Sort Descending',
    'Dg_Clear_Sorting_Caption': 'Clear Sorting',
    'Dg_Add_Row_Help_Text': 'Add a row',
    'Dg_No_Data_Caption': 'No Data',
    'Dg_Cancel_Changes_Help_Text': 'Discard changes',
    'Dg_Delete': 'Delete',
    'Dg_Save_Changes_Help_Text': 'Save changes',
    'Dg_Undelete': 'Undelete',
    'Dg_Invalid_Hyperlink_Format_Msg': 'invalid hyperlink format',
    'Dg_All': '(All)',
    'Dg_Search_Table': 'Search Table',
    'Dg_Show_Hide_Column': 'Show/Hide Column',
    'Dg_Export_FileName': 'Data Table',
    "Dg_Print": "print"
};


describe('default-config', () => {
    beforeAll(() => {
        dataGrid = {
            allowColumnReordering: false,
            allowColumnResizing: true,
            selectionMode: 'single',
            showCheckBoxesMode: false,
            sortingMode: 'single',
            defaultLanguage: 'en',
            _resourcesText: resourcesText,
            columnAutoWidth: true,
            scrollType: 'standard',
            autoExpandGroup: false,
            showGroupingPanel: false
        };

        toolbarHelper = new ToolbarHelper();
        defaulConfig = new DefaultConfig(dataGrid);
        
        //calbacks
        mockToolbarPreparing = jest.fn();
        mockToolbarPreparingObj = new mockToolbarPreparing();
        mockToolbarPreparingBound = mockToolbarPreparing.bind(dataGrid);

        
        mockEditorPreparing = jest.fn();
        mockEditorPreparingObj = new mockEditorPreparing();
        mockEditorPreparingBound = mockEditorPreparing.bind(dataGrid);

    });



    test('constrcutor', () => {
        expect(defaulConfig.toolbarHelper).toMatchObject(toolbarHelper);
        expect(dataGrid.allowColumnReordering).toBe(false);
        expect(dataGrid.allowColumnResizing).toBe(true);
        expect(defaulConfig.defaultConfig.allowColumnReordering).toBe(false);
        expect(defaulConfig.defaultConfig.allowColumnResizing).toBe(true);
        expect(defaulConfig.defaultConfig.columnAutoWidth).toBe(true);
        expect(dataGrid.scrollType).toBe('standard');
        
        expect(mockToolbarPreparing.mock.calls.length).toBe(1);
        mockToolbarPreparingBound();
        expect(mockToolbarPreparing.mock.calls.length).toBe(2);
        expect(mockToolbarPreparing.mock.instances.length).toBe(2);
        
        mockEditorPreparingBound();
        expect(mockEditorPreparing.mock.calls.length).toBe(2);
        expect(mockEditorPreparing.mock.instances.length).toBe(2);
    });
});