import RemoteDataConfig from "../../../src/component/config/remote-data-config";
import * as $ from "jquery";
import RemoteDataHelper from "../../../src/component/helpers/remote-data-helper";
import Utils from "../../../src/component/helpers/utils";


let dataObject;
let dataGrid;
let remoteDataConfig;
let remoteDataHelper;
let utils;

let handleDatasourceFunc;
let handleDatasourceMock;

let customizeColumnsFunc;
let customizeColumnsMock;

let handleCellPreparedForRemoteDataFunc;
let handleCellPreparedForRemoteDataMock;

let handleContentReadyActionFunc;
let handleContentReadyActionMock;

let onRowPreparedFunc;
let onRowPreparedMock;

let onOptionChangedFunc;
let onOptionChangedMock;

let onEditorPreparedFunc;
let onEditorPreparedMock;

const resourcesText = {    
    'Dg_Sort_Ascending_Caption': 'Sort Ascending',
    'Dg_Sort_Descending_Caption': 'Sort Descending',
    'Dg_Clear_Sorting_Caption': 'Clear Sorting',
    'Dg_Add_Row_Help_Text': 'Add a row',
    'Dg_No_Data_Caption': 'No Data',
    'Dg_Cancel_Changes_Help_Text': 'Discard changes',
    'Dg_Delete': 'Delete',
    'Dg_Save_Changes_Help_Text': 'Save changes',
    'Dg_Undelete': 'Undelete',
    'Dg_Invalid_Hyperlink_Format_Msg': 'invalid hyperlink format',
    'Dg_All': '(All)',
    'Dg_Search_Table': 'Search Table',
    'Dg_Show_Hide_Column': 'Show/Hide Column',
    'Dg_Export_FileName': 'Data Table',
    "Dg_Print": "print"
};



describe('Remote Data Config', () =>{

    
    beforeAll(() =>{
        
        dataGrid = {
            allowColumnReordering: false,
            allowColumnResizing: true,
            selectionMode: 'single',
            showCheckBoxesMode: false,
            sortingMode: 'single',
            defaultLanguage: 'en',
            _resourcesText: resourcesText,
            columnAutoWidth: true,
            scrollType: 'standard',
            autoExpandGroup: false,
            showGroupingPanel: false,
           
        };
        
        dataObject = { rowType: ''};
        
        dataGrid.dataObject = dataObject;
        dataGrid.getGridInstance = jest.fn();
        utils = new Utils();
    });

    beforeEach(() =>{        

        remoteDataHelper = new RemoteDataHelper();
        remoteDataConfig = new RemoteDataConfig(dataGrid);

        handleDatasourceFunc = jest.fn((dataGrid) => { remoteDataHelper.handleDatasource(dataGrid) });
        handleDatasourceMock = new handleDatasourceFunc(dataGrid);

        customizeColumnsFunc = jest.fn((remoteHelper, dataGrid) => { remoteDataHelper.customizeColumns(remoteHelper, dataGrid)});
        customizeColumnsMock = new customizeColumnsFunc(remoteDataHelper, dataGrid);

        handleCellPreparedForRemoteDataFunc = jest.fn((dataGrid, remoteHelper, dataObject) => { remoteDataHelper.handleCellPreparedForRemoteData(dataGrid, remoteHelper, dataObject)});
        handleCellPreparedForRemoteDataMock = new handleCellPreparedForRemoteDataFunc(dataGrid, remoteDataHelper, dataObject);

        const element = 
        '<div class="gridContainer">' +
            '<div class="dx-datagrid-pager dx-pager">' +
            '  <div class="dx-page-sizes">' +
            '  </div>' +
            '</div>' +
        '</div>';

        dataGrid.$element = $(element);

        handleContentReadyActionFunc = jest.fn((dataGrid, options) =>{ remoteDataHelper.handleContentReadyAction(dataGrid, options)});
        handleContentReadyActionMock = new handleContentReadyActionFunc(dataGrid, '');

        onRowPreparedFunc = jest.fn((dataGrid, dataObject) => { remoteDataHelper.handleRowPrepared(dataGrid, dataObject);})
        onRowPreparedMock = new onRowPreparedFunc(dataGrid, dataObject);
        
        onOptionChangedFunc = jest.fn((dataGrid, dataObject) => { remoteDataHelper.onOptionChanged(dataGrid, dataObject);})
        onOptionChangedMock = new onOptionChangedFunc(dataGrid, dataObject);        

        onEditorPreparedFunc = jest.fn((dataGrid, dataObject) => { utils.handleEditorPrepared(dataGrid, dataObject);})
        onEditorPreparedMock = new onEditorPreparedFunc(dataGrid, dataObject);

    });

    test('constrcutor', ()=>{       
        expect(remoteDataConfig.config.remoteOperations.paging).toBe(true); 
        expect(remoteDataConfig.config.remoteOperations.sorting).toBe(true); 
        expect(remoteDataConfig.config.remoteOperations.filtering).toBe(true); 
    });

    test('handleDatasource', () =>{
        expect(handleDatasourceFunc).toHaveBeenCalled();
        expect(handleDatasourceFunc).toHaveBeenCalledWith(dataGrid);
        expect(handleDatasourceFunc.mock.calls.length).toBe(1);
    });

    test('customizeColumns', ()=>{
        expect(customizeColumnsFunc).toHaveBeenCalled();
        expect(customizeColumnsFunc).toHaveBeenCalledWith(remoteDataHelper, dataGrid);
        expect(customizeColumnsFunc.mock.calls.length).toEqual(1);

    });

    test('handleCellPreparedForRemoteData', ()=>{
        expect(handleCellPreparedForRemoteDataFunc).toHaveBeenCalled();
        expect(handleCellPreparedForRemoteDataFunc).toHaveBeenCalledWith(dataGrid, remoteDataHelper, dataObject);
        expect(handleCellPreparedForRemoteDataFunc.mock.calls.length).toBeGreaterThan(0);
    });

    test('onContentReadyAction', () =>{        

        expect(handleContentReadyActionFunc).toHaveBeenCalled();
        expect(handleContentReadyActionFunc).toHaveBeenCalledWith(dataGrid, '');
        expect(handleContentReadyActionFunc.mock.calls.length).toBe(1);
    });
    
    test('onRowPrepared', () =>{
        expect(onRowPreparedFunc).toHaveBeenCalled();
        expect(onRowPreparedFunc).toHaveBeenCalledWith(dataGrid, dataObject);
        expect(onRowPreparedFunc.mock.calls.length).toBe(1);
    });

    test('onOptionChanged', () =>{
        expect(onOptionChangedFunc).toHaveBeenCalled();
        expect(onOptionChangedFunc).toHaveBeenCalledWith(dataGrid, dataObject);
        expect(onOptionChangedFunc.mock.calls.length).toBe(1);
    });

    test('onEditorPrepared', () =>{
        expect(onEditorPreparedFunc).toHaveBeenCalled();
        expect(onEditorPreparedFunc).toHaveBeenCalledWith(dataGrid, { rowType: ''});
        expect(onEditorPreparedFunc.mock.calls.length).toBe(1);
    });
});