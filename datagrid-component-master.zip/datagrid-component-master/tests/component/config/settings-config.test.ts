import SettingsConfig from "../../../src/component/config/settings-config";

describe("Settings Config", () => {
	let settingsConfig;
	let dataGrid;
	let toolbarEventObj;
	beforeAll(() => {
		dataGrid = { hasColumnChooser: true, columnChooserMode: "advanced", getTranslation:function(){} };
		settingsConfig = new SettingsConfig(dataGrid);
		toolbarEventObj = {
			component: {},
			toolbarOptions: {
				items: []
			}
		};
	});

	test("constructor", () => {
		expect(settingsConfig.columns.length).toBe(7);
	});

	test("isEnabled", () => {
		dataGrid = { hasColumnChooser: true, columnChooserMode: "advanced" };
		expect(settingsConfig.isEnabled(dataGrid)).toBe(true);

		dataGrid = { hasColumnChooser: true, columnChooserMode: "simple" };
		expect(settingsConfig.isEnabled(dataGrid)).toBe(false);

		dataGrid = { hasColumnChooser: false, columnChooserMode: "advanced" };
		expect(settingsConfig.isEnabled(dataGrid)).toBe(false);
	});

	test("onToolbarPreparing", () => {
		let prevItemsCount = toolbarEventObj.toolbarOptions.items.length;
		settingsConfig.onToolbarPreparing(toolbarEventObj, {});
		expect(toolbarEventObj.toolbarOptions.items.length).toBe(
			prevItemsCount + 1
		);

	});
});
