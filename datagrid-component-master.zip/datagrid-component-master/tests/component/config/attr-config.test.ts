import AttrConfig from "../../../src/component/config/attr-config";

describe('Attr Config', () =>{
    let attrConfig;
    let dataGrid;
    let attrCallback;
    let getAttribute;

    beforeAll(() => {
        attrCallback = jest.fn( () => { return 'allowcolumnresizing' });
        dataGrid = { getAttribute: attrCallback, allowColumnResizing: 'true' };
        attrConfig = new AttrConfig(dataGrid);
        getAttribute = attrConfig.getAttribute;
      });

    test('constrcutor', () => {
        expect(attrConfig.vm.data).toBe('');
        expect(attrConfig.vm.allowColumnResizing).toBe(true);
        expect(attrConfig.vm.allowColumnReordering).toBe(true);
        expect(attrConfig.vm.hasColumnChooser).toBe(false);
        expect(attrConfig.vm.selectionMode).toBe('multiple');
        expect(attrConfig.vm.showRowFilter).toBe(true);
        expect(attrConfig.vm.showGroupingPanel).toBe(false);
        expect(attrConfig.vm.allowRowEditing).toBe(false);
        expect(attrConfig.vm.allowRowAdding).toBe(false);
        expect(attrConfig.vm.allowRowDeleting).toBe(false);
        expect(attrConfig.vm.editMode).toBe('batch');
        expect(attrConfig.vm.sortingMode).toBe('single');
        expect(attrConfig.vm.columnAutoWidth).toBe(false);
        expect(attrConfig.vm.wordWrapEnabled).toBe(false);
        expect(attrConfig.vm.showPaging).toBe(true);
        expect(attrConfig.vm.showPrint).toBe(false);
        expect(attrConfig.vm.autoExpandGroup).toBe(true);
        expect(attrConfig.vm.allowedPageSizes).toEqual([10, 25, 50, 100]);
        expect(attrConfig.vm.showNavigationButtons).toBe(true);
        expect(attrConfig.vm.showPageSizeSelector).toBe(true);
        expect(attrConfig.vm.showCheckBoxesMode).toBe('always');
        expect(attrConfig.vm.allowExportData).toBe(false);
        expect(attrConfig.vm.allowExportSelectedData).toBe(false);
        expect(attrConfig.vm.showSearchPanel).toBe(true);
        expect(attrConfig.vm.dataMode).toBe('remote');
        expect(attrConfig.vm.filterPanelVisible).toBe(false);

    });

    test('addAttrValue', () =>{
        attrConfig.addAttrValue(dataGrid, 'allowcolumnresizing', dataGrid.allowColumnResizing, 'true');
        
        expect(attrConfig.vm.getAttribute('allowcolumnresizing')).toBe('allowcolumnresizing');
        expect(attrConfig.vm.allowColumnResizing).toEqual(true);
    });
    
    test('handleAttributeChange', () => {
        attrConfig.handleAttributeChange('allowcolumnresizing', '', false);
        attrConfig.handleAttributeChange('allowcolumnreordering', '', true);
        attrConfig.handleAttributeChange('hascolumnchooser', '', false);
        attrConfig.handleAttributeChange('selectionmode', '', 'single');
        attrConfig.handleAttributeChange('showgroupingpanel', '', true);
        attrConfig.handleAttributeChange('allowrowediting', '', false);


        expect(attrConfig.vm.allowColumnResizing).toBe(false);
        expect(attrConfig.vm.allowColumnReordering).toBe(true);
        expect(attrConfig.vm.hasColumnChooser).toBe(false);
        expect(attrConfig.vm.selectionMode).toBe('single');
        expect(attrConfig.vm.showGroupingPanel).toBe(true);
        expect(attrConfig.vm.allowRowEditing).toBe(false);

    });
});
