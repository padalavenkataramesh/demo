import JsonConfig from "../../../src/component/config/json-config";
import JsonHelper from "../../../src/component/helpers/json-helper";

let helper = new JsonHelper();
let dataGrid;
let jsonConfig;

const resourcesText = {    
    'Dg_Sort_Ascending_Caption': 'Sort Ascending',
    'Dg_Sort_Descending_Caption': 'Sort Descending',
    'Dg_Clear_Sorting_Caption': 'Clear Sorting',
    'Dg_Add_Row_Help_Text': 'Add a row',
    'Dg_No_Data_Caption': 'No Data',
    'Dg_Cancel_Changes_Help_Text': 'Discard changes',
    'Dg_Delete': 'Delete',
    'Dg_Save_Changes_Help_Text': 'Save changes',
    'Dg_Undelete': 'Undelete',
    'Dg_Invalid_Hyperlink_Format_Msg': 'invalid hyperlink format',
    'Dg_All': '(All)',
    'Dg_Search_Table': 'Search Table',
    'Dg_Show_Hide_Column': 'Show/Hide Column',
    'Dg_Export_FileName': 'Data Table',
    "Dg_Print": "print"
};
 


describe('Json Config', () =>{

    beforeAll(() =>{
        dataGrid = {
            allowColumnReordering: false,
            allowColumnResizing: true,
            selectionMode: 'single',
            showCheckBoxesMode: false,
            sortingMode: 'single',
            defaultLanguage: 'en',
            _resourcesText: resourcesText,
            columnAutoWidth: true,
            scrollType: 'standard',
            autoExpandGroup: false,
            showGroupingPanel: false
        };

        jsonConfig = new JsonConfig(dataGrid, { data: {}});

    });

    test('constrcutor', () =>{
       expect(jsonConfig.config.dataSource).toEqual({});
    });
});