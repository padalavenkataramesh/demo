import ToolbarHelper from "../../../src/component/helpers/toolbar-helper";
import * as $ from 'jquery';

let dataGrid;

let toolbarHelper;
let e;
let _loadConfigurableButtons;
let dataGridEle;
let $dataGridEle;
let datagrid;

describe('Toolbar Helper', () => {

    beforeEach(() => {
        dataGridEle = '<aux-datagrid showsearchpanel=true allowcolumnreordering=false >' +
            '</aux-datagrid>';

        $dataGridEle = $(dataGridEle);

        document.body.innerHTML = dataGridEle;

        datagrid = document.querySelector('aux-datagrid');
        dataGrid = { showPrint: true };
        e = { toolbarOptions: { items: [] } };
        dataGrid.loadConfigurableButtons = loadButtons;

        toolbarHelper = new ToolbarHelper();
    });    

    test('check buttons rendered', () => {
        $(datagrid)[0].loadConfigurableButtons = loadButtons;
        $(datagrid)[0].loadJSONData = loadData.bind(self, datagrid);
        expect($(datagrid)[0].loadConfigurableButtons()[1].btnClass).toContain('delete-selected');
        expect($(datagrid)[0].loadConfigurableButtons()[1].iconClass).toContain('icon-delete-selected');
    });

    test('set attributes', () => {
        $(datagrid).attr('showgroupingpanel', 'true');
        $(datagrid).attr('allowcolumnresizing', 'false');
        $(datagrid).attr('selectionmode', 'selectionmode');

        expect($(datagrid).attr('showsearchpanel')).toEqual('true');
        expect($(datagrid).attr('allowcolumnreordering')).toEqual('false');
        expect($(datagrid).attr('showgroupingpanel')).toBe('true');
        expect($(datagrid).attr('allowcolumnresizing')).toBe('false');
        expect($(datagrid).attr('selectionmode')).toBe('selectionmode');
    });

    function loadButtons() {
        return [{
            btnClass: 'icon-list2', height: '350px', align: 'right', action: 'sendTo', text: 'Send To', title: 'Send To', type: 'more-options', options: [
                { text: 'ACA Analysis', action: 'aca-analysis', noaccess: false, 'disabled': this.hasACAAnalysis },
                { text: 'ASSET_STRATEGY', action: 'asset-strategy', noaccess: false, 'disabled': this.hasStrategy },
                { text: 'SYSTEM_STRATEGY_CAPTION', action: 'sys-strategy', noaccess: false, 'disabled': this.hasSystemStrategy },
                { text: 'FMEA_ANALYSIS', action: 'fmea-analysis', noaccess: true, 'disabled': this.hasFMEAAnalysis },
                { text: 'RCM_ANALYSIS', action: 'rcm-analysis', noaccess: false, 'disabled': this.hasRCMAnalysis },
                { text: 'RBI_ASSET_VIEW', action: 'rbi-assset', noaccess: false, 'disabled': this.disableRBI }
            ]
        }, { 'align': 'right', 'action': 'DeleteItem', 'title': 'Delete', 'iconClass': 'icon-delete-selected', 'btnClass': 'delete-selected' },
        { 'align': 'right', 'action': 'ExportItem', 'title': 'Export', 'iconClass': 'icon-upload', 'btnClass': 'export-selected' },
        { btnClass: 'btn btn-primary', align: 'right', action: 'sendTo', text: 'Send To', title: 'Send To' }, {
            icon: 'icon-options', height: '350px', align: 'right', action: 'sendTo', title: 'Send To', type: 'more-options', options: [
                { text: 'ACA Analysis', action: 'aca-analysis', noaccess: false, 'disabled': this.hasACAAnalysis },
                { text: 'ASSET_STRATEGY', action: 'asset-strategy', noaccess: false, 'disabled': this.hasStrategy },
                { text: 'SYSTEM_STRATEGY_CAPTION', action: 'sys-strategy', noaccess: false, 'disabled': this.hasSystemStrategy },
                { text: 'FMEA_ANALYSIS', action: 'fmea-analysis', noaccess: true, 'disabled': this.hasFMEAAnalysis },
                { text: 'RCM_ANALYSIS', action: 'rcm-analysis', noaccess: false, 'disabled': this.hasRCMAnalysis },
                { text: 'RBI_ASSET_VIEW', action: 'rbi-assset', noaccess: false, 'disabled': this.disableRBI }
            ]
        }
        ];
    }

    function loadData() {
        var dfd = $.Deferred();

        dfd.resolve({
            "paging": { "page": 1, "per_page": 10, "total": 39 },
            "data": [
                { "entityKey": "64253032662", "familyKey": "64253028944", "familyCaption": "RR_TEST RR_TEST familyCaption relationshipCaptions RR_TEST familyCaption relationshipCaptions", "itemID": " & &", "relationshipKeys": [], "relationshipCaptions": [], "score": 3.43795681, "action": "", "searchActions": [] },
                { "entityKey": "64253032663", "familyKey": "64253028944", "familyCaption": "RR_TEST", "itemID": " &123 &", "relationshipKeys": [], "relationshipCaptions": [], "score": 3.43795681, "action": "", "searchActions": [] },
                { "entityKey": "64253032664", "familyKey": "64253028944", "familyCaption": "RR_TEST", "itemID": " &234 &", "relationshipKeys": [], "relationshipCaptions": [], "score": 3.43795681, "action": "", "searchActions": [] },
                { "entityKey": "64253032665", "familyKey": "64253028944", "familyCaption": "RR_TEST", "itemID": " &343 &", "relationshipKeys": [], "relationshipCaptions": [], "score": 3.43795681, "action": "", "searchActions": [] },
                { "entityKey": "64253032666", "familyKey": "64253028944", "familyCaption": "RR_TEST", "itemID": " &455 &", "relationshipKeys": [], "relationshipCaptions": [], "score": 3.43795681, "action": "", "searchActions": [] },
                { "entityKey": "64253032667", "familyKey": "64253028944", "familyCaption": "RR_TEST", "itemID": " &7857 &", "relationshipKeys": [], "relationshipCaptions": [], "score": 3.43795681, "action": "", "searchActions": [] },
                { "entityKey": "64253032668", "familyKey": "64253028944", "familyCaption": "RR_TEST", "itemID": "2 & &", "relationshipKeys": [], "relationshipCaptions": [], "score": 3.43795681, "action": "", "searchActions": [] }
            ]
        }); return dfd;
    }

});