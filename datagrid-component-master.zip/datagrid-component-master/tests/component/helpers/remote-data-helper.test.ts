import RemoteDataHelper from "../../../src/component/helpers/remote-data-helper";
import * as $ from 'jquery';

let dataGrid;
let dataObject;
let rowType;

let remoteDataHelper;

let handleRemoteDataLoadFunc;
let handleRemoteDataLoadMock;

let handleRemoteDataTotalCountFunc;
let handleRemoteDataTotalCountMock;

let customizeColumnsFunc;
let customizeColumnsMock;

let handleCellPreparedForRemoteDataFunc;
let handleCellPreparedForRemoteDataMock;

let handleContentReadyActionFunc;
let handleContentReadyActionMock;


describe('Remote Data Helper', () => {

    beforeAll(() => {        
        dataGrid = {};
        dataObject = {};
        dataGrid.selectionMode = 'single';
        dataGrid.dataObject = dataObject;
        rowType = '';
        dataGrid.rowType = rowType;

        remoteDataHelper = new RemoteDataHelper();

        const element =
            '<div class="gridContainer">' +
            '<div class="dx-datagrid-pager dx-pager">' +
            '  <div class="dx-page-sizes">' +
            '  </div>' +
            '</div>' +
            '</div>';

        dataGrid.$element = $(element);

        handleRemoteDataLoadFunc = jest.fn((dataGrid, options) => { remoteDataHelper.handleRemoteDataLoad(dataGrid, options) });
        handleRemoteDataLoadMock = new handleRemoteDataLoadFunc(dataGrid, {});

        handleRemoteDataTotalCountFunc = jest.fn((dataGrid) => { remoteDataHelper.handleRemoteDataTotalCount(dataGrid) });
        handleRemoteDataTotalCountMock = new handleRemoteDataTotalCountFunc(dataGrid);

        customizeColumnsFunc = jest.fn((dataGrid, dxGridColumns) => { remoteDataHelper.customizeColumns(dataGrid, dxGridColumns) });
        customizeColumnsMock = new customizeColumnsFunc(dataGrid, '');

        handleCellPreparedForRemoteDataFunc = jest.fn((dataGrid, remoteDataHelper, dataObject) => { remoteDataHelper.handleCellPreparedForRemoteData(dataGrid, remoteDataHelper, dataObject) });
        handleCellPreparedForRemoteDataMock = new handleCellPreparedForRemoteDataFunc(dataGrid, remoteDataHelper, rowType);

        dataGrid.getGridInstance = jest.fn();
        
        handleContentReadyActionFunc = jest.fn((dataGrid, options) => { remoteDataHelper.handleContentReadyAction(dataGrid, options) });
        handleContentReadyActionMock = new handleContentReadyActionFunc(dataGrid, '');
    });

    // test(`handleRemoteDataTotalCount async`, async () => {
    //     await expect(remoteDataHelper.handleRemoteDataTotalCount(dataGrid)).resolves.toBe('');
    // });

    test('handleRemoteDataLoad', () => {
        expect(handleRemoteDataLoadFunc).toHaveBeenCalled();
        expect(handleRemoteDataLoadFunc).toHaveBeenCalledWith(dataGrid, {});
        expect(handleRemoteDataLoadFunc.mock.calls.length).toBe(1);
    });

    test('handleRemoteDataTotalCount mock', () => {
        expect(handleRemoteDataTotalCountFunc).toHaveBeenCalled();
        expect(handleRemoteDataTotalCountFunc).toHaveBeenCalledWith(dataGrid);
        expect(handleRemoteDataTotalCountFunc.mock.calls.length).toBe(1);
    });  

    test('handleRemoteDataTotalCount', function () {
        const result = remoteDataHelper.handleRemoteDataTotalCount(dataGrid);
        expect(result).resolves.toBe('');
    });

    test('customizeColumnsFunc', () => {
        expect(customizeColumnsFunc).toHaveBeenCalled();
        expect(customizeColumnsFunc).toHaveBeenCalledWith(dataGrid, '');
        expect(customizeColumnsFunc.mock.calls.length).toBe(1);
    });

    test('handleCellPreparedForRemoteData', ()=>{
        expect(handleCellPreparedForRemoteDataFunc).toHaveBeenCalled();
        expect(handleCellPreparedForRemoteDataFunc).toHaveBeenCalledWith(dataGrid, remoteDataHelper, rowType);
        expect(handleCellPreparedForRemoteDataFunc.mock.calls.length).toBe(1);
    });

    test('handleContentReadyAction', ()=>{
        expect(handleContentReadyActionFunc).toHaveBeenCalled();
        expect(handleContentReadyActionFunc).toHaveBeenCalledWith(dataGrid, '');
        expect(handleContentReadyActionFunc.mock.calls.length).toBe(1);
    });

    test('handleRemoteDataTotalCount', async () =>{
         remoteDataHelper.handleRemoteDataTotalCount(dataGrid).then(data => {
            return expect(remoteDataHelper.handleRemoteDataTotalCount).toHaveBeenCalled();
        });
    });
});