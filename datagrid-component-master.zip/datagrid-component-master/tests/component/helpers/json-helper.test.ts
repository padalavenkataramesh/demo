import JsonHelper from "../../../src/component/helpers/json-helper";
import * as $ from "jquery";
import Utils from "../../../src/component/helpers/utils";

let jsonHelper;
let utils;
let dataGrid;
let dataObject;

let preSelectRowsFunc;
let preSelectRowsMock;

let handleCellPreparedFunc;
let handleCellPreparedMock;

let handleInitNewRowFunc;
let handleInitNewRowMock;

let handleRowPreparedFunc;
let handleRowPreparedMock;

let handleContentReadyActionForJSONFunc;
let handleContentReadyActionForJSONMock;

let handleSelectionChangedFunc;
let handleSelectionChangedMock;

let handleSelectionChangeForJsonWithoutColumnsFunc;
let handleSelectionChangeForJsonWithoutColumnsMock;

let handleEditorPreparedForJsonFunc;
let handleEditorPreparedForJsonMock;

let handleEditingStartFunc;
let handleEditingStartMock;

let onOptionChangedFunc;
let onOptionChangedMock;

let onExportingFunc;
let onExportingMock;


describe('JsonHelper', () => {

    beforeAll(()=>{
        dataGrid = { element : null, $element: null};
        dataObject = {};
        const element = 
        '<div class="gridContainer">' +
            '<div class="dx-datagrid-pager dx-pager">' +
            '  <div class="dx-page-sizes">' +
            '  </div>' +
            '</div>' +
        '</div>';
        dataGrid.$element = $(element);
        dataGrid.dataObject = dataObject;

        jsonHelper = new JsonHelper();
        utils = new Utils();

        preSelectRowsFunc = jest.fn((dataGrid, data) => { jsonHelper.preSelectRows(dataGrid, data)});
        preSelectRowsMock = new preSelectRowsFunc(dataGrid, {});

        handleCellPreparedFunc = jest.fn((dataGrid, dataObject) => { jsonHelper.handleCellPrepared(dataGrid, dataObject)});
        handleCellPreparedMock = new handleCellPreparedFunc(dataGrid, dataObject);

        handleInitNewRowFunc = jest.fn((dataGrid, conatainer, options) => { jsonHelper.handleInitNewRow(dataGrid, conatainer, options)});
        handleInitNewRowMock = new handleInitNewRowFunc(dataGrid, '', '');

        handleRowPreparedFunc = jest.fn((dataGrid, dataObject) => { jsonHelper.handleRowPrepared(dataGrid, dataObject)});
        handleRowPreparedMock = new handleRowPreparedFunc(dataGrid, dataObject);   
        
        handleContentReadyActionForJSONFunc = jest.fn().mockImplementation((dataGrid, onContentReady, event) => { return true; });
        //jest.fn((dataGrid, onContentReady, event) => { jsonHelper.handleContentReadyActionForJSON(dataGrid, onContentReady, event)});
        handleContentReadyActionForJSONMock = new handleContentReadyActionForJSONFunc(dataGrid, '', '');        
        
        dataGrid.selectionMode = 'single';
        handleSelectionChangedFunc = jest.fn((dataGrid, selectedItems) => { utils.handleSelectionChanged(dataGrid, selectedItems)});
        handleSelectionChangedMock = new handleSelectionChangedFunc(dataGrid, '');        

        handleSelectionChangeForJsonWithoutColumnsFunc = jest.fn((dataGrid, selectedItems)=>{ jsonHelper.handleSelectionChangeForJsonWithoutColumns(dataGrid, selectedItems)});
        handleSelectionChangeForJsonWithoutColumnsMock = new handleSelectionChangeForJsonWithoutColumnsFunc(dataGrid, '');        

        handleEditorPreparedForJsonFunc = jest.fn((dataGrid, options)=>{ utils.handleEditorPrepared(dataGrid, options)});
        handleEditorPreparedForJsonMock = new handleEditorPreparedForJsonFunc(dataGrid, '');                
         
        handleEditingStartFunc = jest.fn((dataGrid, container)=>{ jsonHelper.handleEditingStart(dataGrid, container)});
        handleEditingStartMock = new handleEditingStartFunc(dataGrid, '');        

        onOptionChangedFunc = jest.fn((dataGrid, obj)=>{ jsonHelper.onOptionChanged(dataGrid, obj)});
        handleEditingStartMock = new onOptionChangedFunc(dataGrid, {});        
        
        onExportingFunc = jest.fn().mockImplementation((dataGrid, event) => { return true; });
        onExportingMock = new onExportingFunc(dataGrid, undefined);        

    });

    test('preSelectRows', ()=>{
        jsonHelper.preSelectRows(dataGrid, {});
        expect(preSelectRowsFunc).toHaveBeenCalled();
        expect(preSelectRowsFunc).toHaveBeenCalledWith(dataGrid, {});
        expect(preSelectRowsFunc.mock.calls.length).toBe(1);
    });


    test('handleCellPrepared', ()=>{
        jsonHelper.handleCellPrepared(dataGrid, dataObject);
        expect(handleCellPreparedFunc).toHaveBeenCalled();
        expect(handleCellPreparedFunc).toHaveBeenCalledWith(dataGrid, dataObject);
        expect(handleCellPreparedFunc.mock.calls.length).toBe(1);
    });

    test('handleInitNewRow', ()=>{
        jsonHelper.handleCellPrepared(dataGrid, dataObject);
        expect(handleInitNewRowFunc).toHaveBeenCalled();
        expect(handleInitNewRowFunc).toHaveBeenCalledWith(dataGrid, '', '');
        expect(handleInitNewRowFunc.mock.calls.length).toBe(1);
    });

    test('handleRowPrepared', ()=>{
        expect(handleRowPreparedFunc).toHaveBeenCalled();
        expect(handleRowPreparedFunc).toHaveBeenCalledWith(dataGrid, dataObject);
        expect(handleRowPreparedFunc.mock.calls.length).toBe(1);
    });

    test('handleContentReadyActionForJSON', ()=>{
        expect(handleContentReadyActionForJSONFunc).toHaveBeenCalled();
        expect(handleContentReadyActionForJSONFunc).toReturnWith(true);
        expect(handleContentReadyActionForJSONFunc).toHaveBeenCalledWith(dataGrid, '', '');
        expect(handleContentReadyActionForJSONFunc.mock.calls.length).toBe(1);
    });
    
    test('handleSelectionChanged', ()=>{
        expect(handleSelectionChangedFunc).toHaveBeenCalled();
        expect(handleSelectionChangedFunc).toHaveBeenCalledWith(dataGrid, '');
        expect(handleSelectionChangedFunc.mock.calls.length).toBe(1);
    });

    test('handleSelectionChangeForJsonWithoutColumns', ()=>{
        expect(handleSelectionChangeForJsonWithoutColumnsFunc).toHaveBeenCalled();
        expect(handleSelectionChangeForJsonWithoutColumnsFunc).toHaveBeenCalledWith(dataGrid, '');
        expect(handleSelectionChangeForJsonWithoutColumnsFunc.mock.calls.length).toBe(1);
    });

    test('handleEditorPreparedForJson', ()=>{
        expect(handleEditorPreparedForJsonFunc).toHaveBeenCalled();
        expect(handleEditorPreparedForJsonFunc).toHaveBeenCalledWith(dataGrid, '');
        expect(handleEditorPreparedForJsonFunc.mock.calls.length).toBe(1);
    });

    test('handleEditorPreparedForJson', ()=>{
        expect(handleEditingStartFunc).toHaveBeenCalled();
        expect(handleEditingStartFunc).toHaveBeenCalledWith(dataGrid, '');
        expect(handleEditingStartFunc.mock.calls.length).toBe(1);
    });

    test('onExporting', ()=>{
        expect(onExportingFunc).toHaveBeenCalled();
        expect(onExportingFunc).toHaveBeenCalledWith(dataGrid, undefined);
        expect(onExportingFunc.mock.calls.length).toBe(1);
    });
});