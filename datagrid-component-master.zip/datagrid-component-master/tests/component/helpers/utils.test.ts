import * as $ from "jquery";

import Utils from "../../../src/component/helpers/utils";
let dataGrid;
let utils;
var handleRowPreparedfn;
var handleRowPreparedMock;

var handleCellTemplateForActionColumnfn;
var handleCellTemplateForActionColumnMock;

var handleCustomCellTemplatefn;
var handleCustomCellTemplateMock;

var handleHeaderCellTemplatefn;
var handleHeaderCellTemplateMock;

describe('utils', () => {

    beforeAll(() => {
        dataGrid = {};
        // dataGrid.rowPreparedCallback = jest.fn(() => { });
        // dataGrid.rowPreparedCallback.mock();       

    });

    beforeEach(() => {
        utils = new Utils();
        handleRowPreparedfn = jest.fn((dataGrid, rowType, Info) => { utils.handleRowPrepared(dataGrid, rowType, Info) });
        handleRowPreparedMock = new handleRowPreparedfn(dataGrid, { rowType: 'compact' }, '');

        handleCellTemplateForActionColumnfn = jest.fn((dataGrid, container, options) => { utils.handleCellTemplateForActionColumn(dataGrid, container, options); })
        handleCellTemplateForActionColumnMock = new handleCellTemplateForActionColumnfn(dataGrid, '', '');

        handleCustomCellTemplatefn = jest.fn((dataGrid, container, options) => { utils.handleCustomCellTemplate(dataGrid, container, options); })
        handleCustomCellTemplateMock = new handleCustomCellTemplatefn(dataGrid, '', '');

        handleHeaderCellTemplatefn = jest.fn((dataGrid, header, info) => { utils.handleHeaderCellTemplate(dataGrid, header, info); })
        handleHeaderCellTemplateMock = new handleHeaderCellTemplatefn(dataGrid, '', '');        
    });

    test('handleRowPrepared mock', () => {
        expect(handleRowPreparedfn.mock.calls.length).toBe(1);
        expect(handleRowPreparedfn).toHaveBeenCalled();
        expect(handleRowPreparedfn).toHaveBeenCalledWith(dataGrid, { rowType: 'compact' }, '');
    });

    test('handleCellTemplateForActionColumn', () => {
        expect(handleCellTemplateForActionColumnfn.mock.calls.length).toBe(1);
        expect(handleCellTemplateForActionColumnfn).toHaveBeenCalled();
        expect(handleCellTemplateForActionColumnfn).toHaveBeenCalledWith(dataGrid, '', '');
    });

    test('handleCustomCellTemplate', () => {
        expect(handleCustomCellTemplatefn.mock.calls.length).toBe(1);
        expect(handleCustomCellTemplatefn).toHaveBeenCalled();
        expect(handleCustomCellTemplatefn).toHaveBeenCalledWith(dataGrid, '', '');
    });

    test('handleHeaderCellTemplate', () => {
        expect(handleCustomCellTemplatefn.mock.calls.length).toBe(1);
        expect(handleCustomCellTemplatefn).toHaveBeenCalled();
        expect(handleCustomCellTemplatefn).toHaveBeenCalledWith(dataGrid, '', '');
    });

    test('addRowsMessage', ()=>{
        const element = 
        '<div class="gridContainer">' +
            '<div class="dx-datagrid-pager dx-pager">' +
            '  <div class="dx-page-sizes">' +
            '  </div>' +
            '</div>' +
        '</div>';

        dataGrid.$element = $(element);
        
        utils.addRowsMessage(dataGrid);
        expect(dataGrid.$element.find('.dx-datagrid-pager.dx-pager .dx-page-sizes .dx-page-size-message').text()).toEqual('Rows per page');
    });

    test('onOptionChanged', ()=>{
        const searchPanel = 
        '<div class="gridContainer">' +
            '<div class="dx-datagrid-search-panel">' +
            '  <div class="dx-icon dx-icon-search">' +
            '  </div>' +
            '</div>' +
        '</div>';

        dataGrid.$element = $(searchPanel);
        utils.onOptionChanged(dataGrid, { name: 'searchPanel', value: 'search'});
        expect(dataGrid.$element.find('.dx-datagrid-search-panel .dx-icon.dx-icon-search').css('display')).toEqual('none');

        utils.onOptionChanged(dataGrid, { name: 'searchPanel', value: ''});
        expect(dataGrid.$element.find('.dx-datagrid-search-panel .dx-icon.dx-icon-search').css('display')).toEqual('block');
    });
});