//The build will inline common dependencies into this file.

//For any third party dependencies, like jQuery, place them in the lib folder.

//Configure loading modules from the lib directory,
//except for 'app' ones, which are in a sibling
//directory.
requirejs.config({
    // baseUrl: '/',
    paths: {
        // app: '/src',
        // element: '/src/component',
        jquery: 'lib/jquery',
        devExWebJS: 'lib/dx.webappjs',
        text: 'lib/text',
        lodash: 'lib/lodash',
        jszip: 'jszip.min'
    },
    shim: {
        'devExWebJS': {
            deps: ['jquery'],
            exports: "$"
        },
        // 'text': {
        //     deps: ['jquery']
        // }
    }
});
