// import masterDetailData from 'src/test-master-details-data';

define(function (require) {

  var testData = require('text!demos/data-objects/test-data.json');
  require('dist/datagrid');

  var masterDetailData = require("text!demos/data-objects/test-master-details-data.json");

  const datagrid = document.querySelector('aux-datagrid');

  function loadData(grid, options) {
    var dfd = $.Deferred(),
      parsedData,
      pageIndex,
      pageSize;
    parsedData = JSON.parse(testData);
    if (options && (options.skip || options.take)) {
      pageSize = options.take; // options.sort && options.sort.length ? $(grid).find('.gridContainer').dxDataGrid('instance').pageSize(): options.take;
      pageIndex = options.skip / pageSize;
      setTimeout(function(){
        dfd.resolve(parsedData.data.slice(pageIndex, pageSize));
      },0)
      
    } else {
      setTimeout(function(){
        dfd.resolve(parsedData);
      },0);
    }
    console.log('in loadData');
    console.log(arguments);
    return dfd;
  }

  function getData(grid, args){
    var deferred = $.Deferred();
    $.ajax({
      url: "https://js.devexpress.com/Demos/WidgetsGalleryDataService/api/orders",
      dataType: "json",
      data: args,
      success: function(result) { 
        console.log(result.data.length); 
        data = result.data;
          deferred.resolve(result.data, {
              totalCount: result.totalCount,
              summary: result.summary,
              groupCount: result.groupCount
          });
      },
      error: function() {
          deferred.reject("Data Loading Error");
      },
      //timeout: 5000
    });
    return deferred.promise();
  }


  function loadButtons() {
    var buttons = [/*{
      type: 'customhtml',
      iconClass: 'icon-collection-filter',
      btnClass: 'btn btn-icon',
      align: 'left',
      content: $('<mi-filter-no-ko class="date-filter-" custom-filter="true" data-bind="attr: {title: "Filter")}" title="Filter">'+
              '<div class="icon-filter-container">'+
                '<button class="icon-container btn btn-icon">'+
                    '<i class="icon-collection-filter"></i>'+
                '</button>'+
              '</div>'+
            '</mi-filter-no-ko>')
      },*/
    //   {
    //   btnClass: 'icon-list2', height: '350px', align: 'right', action: 'sendTo', text: 'Send To', title: 'Send To', type: 'more-options', options: [
    //     { text: 'ACA Analysis', action: 'aca-analysis', noaccess: false, 'disabled': this.hasACAAnalysis },
    //     { text: 'ASSET_STRATEGY', action: 'asset-strategy', noaccess: false, 'disabled': this.hasStrategy },
    //     { text: 'SYSTEM_STRATEGY_CAPTION', action: 'sys-strategy', noaccess: false, 'disabled': this.hasSystemStrategy },
    //     { text: 'FMEA_ANALYSIS', action: 'fmea-analysis', noaccess: true, 'disabled': this.hasFMEAAnalysis },
    //     { text: 'RCM_ANALYSIS', action: 'rcm-analysis', noaccess: false, 'disabled': this.hasRCMAnalysis },
    //     { text: 'RBI_ASSET_VIEW', action: 'rbi-assset', noaccess: false, 'disabled': this.disableRBI }
    //   ]
    // }, { 'align': 'right', 'action': 'DeleteItem', 'title': 'Delete', 'iconClass': 'icon-delete-selected', 'btnClass': 'delete-selected', 'disabled': true },
    // { 'align': 'right', 'action': 'ExportItem', 'title': 'Export', 'iconClass': 'icon-upload', 'btnClass': 'export-selected' },
    // {
    //   align: 'left', type: 'customhtml', 'title': "ACTIVE_MEASUREMENTS_ONLY", content: $('<mi-checkbox-noko checked="true" text="i am checked"></mi-checkbox-noko>')
    //  },
    //  { btnClass: '', align: 'right', action: 'sendTo', text: 'Send To', title: 'Send To', disabled:false }, 
    {
      icon: 'icon-options', height: '350px', align: 'right', action: 'sendTo', title: 'Send To', type: 'more-options', options: [
        { text: 'ACA Analysis', action: 'aca-analysis', noaccess: false, 'disabled': this.hasACAAnalysis },
        { text: 'ASSET_STRATEGY', action: 'asset-strategy', noaccess: false, 'disabled': this.hasStrategy },
        { text: 'SYSTEM_STRATEGY_CAPTION', action: 'sys-strategy', noaccess: false, 'disabled': this.hasSystemStrategy },
        { text: 'FMEA_ANALYSIS', action: 'fmea-analysis', noaccess: true, 'disabled': this.hasFMEAAnalysis },
        { text: 'RCM_ANALYSIS', action: 'rcm-analysis', noaccess: false, 'disabled': this.hasRCMAnalysis },
        { text: 'RBI_ASSET_VIEW', action: 'rbi-assset', noaccess: false, 'disabled': this.disableRBI }
      ]
    },
    // {
    //   align: 'left', type: 'customhtml', 'title': "ACTIVE_MEASUREMENTS_ONLY", content: $('<button>placeholder</button>').attr('title', 'ACTIVE_MEASUREMENTS_ONLY')
    // },
    {
      align: 'left', type: 'customhtml', 'btnClass': 'btn btn-icon icon-plus pull-left', 'title': "ADD", 'iconClass': 'icon-plus', content: $('<mi-more-options-noko icon="icon-plus"></mi-more-options-noko>').attr('iconClass', 'icon-plus')
    }

    ];
    return buttons;
  }

  function loadMasterDetailTemplate(container, options) {
    var currentEmployeeData = options.data;
    container.append($('<div class="employeeInfo"><img class="employeePhoto" src="' + currentEmployeeData.Picture + '" /><p class="employeeNotes">' + currentEmployeeData.Notes + '</p></div>'));
  };
 

  //console.log($(datagrid)[0].loadJSONData);
  
 //Properties
 $(datagrid).attr('selectallmode', 'allPages');
 $(datagrid)[0].resourcestext = {'Dg_Sort_Ascending_Caption': 'Sort Ascending-new'};
  $(datagrid)[0].loadConfigurableButtons = loadButtons.bind(self, datagrid);
  $(datagrid)[0].loadMasterDetailTemplate = loadMasterDetailTemplate.bind(self);
  // $(datagrid)[0].handleRemoteDataLoad = loadData.bind(self, datagrid);
  // //$(datagrid)[0].loadJSONData = loadData.bind(self, datagrid);
  // $(datagrid)[0].totalCountCB = handleTotalCount.bind(self, datagrid);
  
  
  /* $(datagrid)[0].loadJSONConfig = {
      masterDetail: {
        enabled: true,
        template: function(container, options) { 
          var currentEmployeeData = options.data;
          container.append($('<div class="employeeInfo"><img class="employeePhoto" src="' + currentEmployeeData.Picture + '" /><p class="employeeNotes">' + currentEmployeeData.Notes + '</p></div>'));
        }
    }
  } */

 

  //Attributes
  $(datagrid).attr('pagesize', 10);
  $(datagrid).attr('allowedpagesizes', JSON.stringify([10, 25, 50, 100]));
  $(datagrid).attr('datamode', 'remote');
  $(datagrid).attr('filterpanelvisible', false);
  $(datagrid).attr('allowColumnReordering', true);
  $(datagrid).attr('showsearchpanel', true);
  $(datagrid).attr('showgroupingpanel', true);
  $(datagrid).attr('allowcolumnresizing', true);
  $(datagrid).attr('columnautowidth', false);
  $(datagrid).attr('showrowfilter', true); 
  $(datagrid).attr('rowfilteradvancedoperators', true); 
  $(datagrid).attr('allowrowediting', true);
  $(datagrid).attr('allowrowadding', true);
  
  //$(datagrid).attr('showfooter', true);
  //$(datagrid).attr('selectionmode', 'multiple');
  $(datagrid).attr('selectallmode', 'allPages');

  $(datagrid).attr('hasColumnChooser', 'true');
  $(datagrid).attr('columnChooserMode', 'advanced');//select
  $(datagrid).attr('enableMasterDetail', false);

  //Callbacks
  $(datagrid)[0].onRowSelectCB = onRowSelected.bind(datagrid, self);
  $(datagrid)[0].onPageChangeCB = onPageChanged.bind(datagrid, self);
  $(datagrid)[0].onRowMultiSelectCB = onRowMultiSelected.bind(datagrid, self);
  $(datagrid)[0].cellTemplateCB = cellTemplate.bind(datagrid, self);
  $(datagrid)[0].onRowPreparedCB = onRowPrepared.bind(datagrid, self);
  $(datagrid)[0].cellPreparedCB = onCellPrepared.bind(datagrid, self);
  $(datagrid)[0].editorPreparedCB = onEditorPrepared.bind(datagrid, self);
  $(datagrid)[0].onInitNewRowCB = onInitNewRow.bind(datagrid, self);
  $(datagrid)[0].gridLoadedCB = onGridLoaded.bind(datagrid, self);
  $(datagrid)[0].toolbarItemClickCallback = toolbarItemClicked.bind(datagrid, self);
  $(datagrid)[0].customizeColumnsCB = customizeColumns.bind(datagrid, self);

  //$(datagrid)[0].loadJSONData = loadMasterDetailData.bind(self, datagrid);
  //$(datagrid)[0].loadJSONData = loadData.bind(self, datagrid);
  //$(datagrid)[0].handleRemoteDataLoad = loadData.bind(self, datagrid);
  $(datagrid)[0].handleRemoteDataLoad = getData.bind(self, datagrid);
  //$(datagrid)[0].loadJSONData = loadData.bind(self, datagrid);
  $(datagrid)[0].totalCountCB = handleTotalCount.bind(self, datagrid);

  datagrid.disableButton('delete-selected', false)
  
  
  function onRowSelected(self){
    console.log('onRowSelected', arguments);
  }

  function onPageChanged(self){
    console.log('onPageChanged', arguments);
  }

  function onRowMultiSelected(self){
    console.log('onRowMultiSelected', arguments);
  }

  function cellTemplate(self){
    console.log('cellTemplate', arguments);
  }

  function onRowPrepared(self){
    //console.log('onRowPrepared', arguments);
  }

  function onCellPrepared(self, e){
   //console.log('onCellPrepared', arguments);
  }

  function onEditorPrepared(self){
   //console.log('onEditorPrepared', arguments);
  }

  function onInitNewRow(self){
    console.log('onInitNewRowCB', arguments);
  }

  function onGridLoaded(self){
    console.log('onGridLoaded', arguments);
  }

  function toolbarItemClicked(self) {
    console.log('toolbarItemClicked', arguments);
  }

  function handleTotalCount(self, dfd) {
    console.log('handleTotalCount');
    //var dfd = $.Deferred();  
    dfd.resolve(39);
    //return dfd;
  }

  function customizeColumns(self,dxDataColumns){
    console.log('customizeColumns');
    console.log(dxDataColumns);
    //format for binding lookup while passing columns
    // dataSource: lookupData,
    // displayExpr: "Name",
    // valueExpr: "ID",
    // allowClearing: false
  }
});
