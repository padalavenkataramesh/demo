define(function(require) {
    require("dist/datagrid");

    const datagrid = document.querySelector("aux-datagrid");
    var master_detail_data = require("text!demos/config-provider/employee-data.json"); //master-detail-data
    var testData = require("text!demos/config-provider/master-detail-data.json"); //master-detail-data

    function isNotEmpty(value) {
        return value !== undefined && value !== null && value !== "";
    }

    var store = new DevExpress.data.CustomStore({
        key: "OrderNumber",
        load: function (loadOptions) {
          var deferred = $.Deferred(),
            args = {};
  
          [
            "skip",
            "take",
            "requireTotalCount",
            "requireGroupCount",
            "sort",
            "filter",
            "totalSummary",
            "group",
            "groupSummary"
          ].forEach(function (i) {
            if (i in loadOptions && loadOptions[i] !== undefined && loadOptions[i] !== null && loadOptions[i] !== "")
              args[i] = JSON.stringify(loadOptions[i]);
          });
          $.ajax({
            url: "https://js.devexpress.com/Demos/WidgetsGalleryDataService/api/orders",
            dataType: "json",
            data: args,
            success: function (result) {
              deferred.resolve(result.data, {
                totalCount: result.totalCount,
                summary: result.summary,
                groupCount: result.groupCount
              });
            },
            error: function () {
              deferred.reject("Data Loading Error");
            },
            timeout: 5000
          });
  
          return deferred.promise();
        }
      });

    // $(datagrid)[0].loadJSONData = loadData.bind(self, datagrid);
    // $(datagrid)[0].configOptionsCB = bingConfig(datagrid);
    $(datagrid)[0].loadConfigurableButtons = loadButtons.bind(self, datagrid);

    setTimeout(function() {
        // $(datagrid)[0].onInitializedCB = gridIntialized.bind(self, datagrid);
        //$(datagrid)[0].setAttribute('datamode', 'remote');
        $(datagrid)[0].configOptionsCB = configOptionsCallback(datagrid);
    }, 1000);
    $(datagrid).on("gridInitialized", gridIntializedEvent);

    function loadButtons() {
      var buttons = [          
          { btnClass: '', align: 'right', action: 'save', text: 'Save', title: 'Save', disabled: false },
          { btnClass: '', align: 'right', action: 'sendTo', text: 'Send To', title: 'Send To', disabled: false },
          {
              icon: 'icon-options',
              height: '350px',
              align: 'right',
              action: 'sendTo',
              title: 'Send To',
              type: 'more-options',
              options: [
                  { text: 'ACA Analysis', action: 'aca-analysis', noaccess: false, 'disabled': this.hasACAAnalysis },
                  { text: 'ASSET_STRATEGY', action: 'asset-strategy', noaccess: false, 'disabled': this.hasStrategy },
                  { text: 'SYSTEM_STRATEGY_CAPTION', action: 'sys-strategy', noaccess: false, 'disabled': this.hasSystemStrategy },
                  { text: 'FMEA_ANALYSIS', action: 'fmea-analysis', noaccess: true, 'disabled': this.hasFMEAAnalysis },
                  { text: 'RCM_ANALYSIS', action: 'rcm-analysis', noaccess: false, 'disabled': this.hasRCMAnalysis },
                  { text: 'RBI_ASSET_VIEW', action: 'rbi-assset', noaccess: false, 'disabled': this.disableRBI }
              ]
          },
          // {
          //   align: 'left', type: 'customhtml', 'title': "ACTIVE_MEASUREMENTS_ONLY", content: $('<button>placeholder</button>').attr('title', 'ACTIVE_MEASUREMENTS_ONLY')
          // },
          {
              align: 'left',
              type: 'customhtml',
              'btnClass': 'btn btn-icon icon-plus pull-left',
              'title': "ADD",
              'iconClass': 'icon-plus',
              content: $('<mi-more-options-noko icon="icon-plus"></mi-more-options-noko>').attr('iconClass', 'icon-plus')
          }

      ];
      return buttons;
  }

    function gridIntializedEvent(datagrid) {
        console.log("gridIntializedEvent");
        // $(datagrid)[0].configOptionsCB = bindConfig(datagrid);
    }

    function contentReady(self) {
        // console.log("from consumer");
    }

    function configOptionsCallback(grid) {
        var config = {
            dataSource: store, //store, //,JSON.parse(testData)
            rowAlternationEnabled: false,
            isRowFilterOpened: true,
            filterPanelVisible: true,
            showsearchpanel: true,
            columnChooserMode: ["SelecT", "aDvanced"],
            isRowFilterOpened: false,
            showheaderfilter: true,
            // columnChooserMode: "advanced",
            // columnChooserMode: "select",
            showTextForColumnChooserButton: true,
            hideSortFromGroupingPanel: true,
            hasColumnChooser: true,
            showRowFilter: true,
            showGroupingPanel: true,
            pageSize: 5,
            // showBorders: false,
            onContentReady: contentReady.bind(null, self),
            remoteOperations: true,
            groupPanel: {
                visible: true,
            },
            // editing: {
            //   mode: "batch", //Accepted Values: 'batch' | 'cell' | 'row' | 'form' | 'popup'
            //   allowUpdating: true,
            //   allowAdding: false,
            //   allowDeleting: false,
            // },
            selection: {
                allowSelectAll: true,
                mode: "multiple", //default: single: Accepted Values: 'multiple' | 'none' | 'single'
                selectAllMode: "page", //Accepted Values: 'allPages' | 'page'
                showCheckBoxesMode: "always", //Accepted Values:'always' | 'none' | 'onClick' | 'onLongTap'
            },
            grouping: {
                autoExpandAll: false,
                contextMenuEnabled: false,
            },
            paging: {
                pageSize: 25,
            },
            // focusedRowEnabled: true,
            pager: {
                showPageSizeSelector: true,
                allowedPageSizes: [10, 25, 50, 100],
            },            
            columns: [{
              dataField: "Employee",
              caption: "Employee",
              dataType: "string",
              fixed: false,
              visible: true,
              inActive: false
            },
            {
              dataField: "OrderDate",
              caption: "Order Date",
              dataType: "datetime",
              fixed: false,
              visible: true,
              inActive: false
            },
            {
              dataField: "OrderNumber",
              caption: "Order Number",
              dataType: "number",
              fixed: false,
              visible: true,
              inActive: false
            },
            {
              dataField: "SaleAmount",
              caption: "Sale Amount",
              dataType: "number",
              fixed: true,
              groupIndex: 0,
              // fixedPosition: "left",
              visible: true,
              inActive: false
            },
            {
              dataField: "StoreState",
              caption: "Store State",
              dataType: "string",
              fixed: false,
              visible: true,
              inActive: false
            },
            {
              dataField: "StoreCity",
              caption: "Store City",
              dataType: "string",
              fixed: false,
              visible: true,
              inActive: true
            }
          ]
            // columns: [{
            //         dataField: "ID",
            //         caption: "ID",
            //         width: 70,
            //         visible: false,
            //         inActive: true
            //     },
            //     "Prefix",
            //     "FirstName",
            //     "LastName",
            //     {
            //         dataField: "Position",
            //         width: 170,
            //         visible: false,
            //         inActive: true
            //     },
            //     {
            //         dataField: "State",
            //         width: 125,
            //     },
            //     {
            //         dataField: "BirthDate",
            //         dataType: "date",
            //     },
            // ],
            // masterDetail: {
            //   enabled: true,
            //   template: function(container, options) {
            //       var currentEmployeeData = options.data;

            //       $("<div>")
            //           .addClass("master-detail-caption")
            //           .text(currentEmployeeData.FirstName + " " + currentEmployeeData.LastName + "'s Tasks:")
            //           .appendTo(container);

            //       $("<div>")
            //           .dxDataGrid({
            //               columnAutoWidth: true,
            //               showBorders: true,
            //               columns: ["Subject", {
            //                   dataField: "StartDate",
            //                   dataType: "date"
            //               }, {
            //                   dataField: "DueDate",
            //                   dataType: "date"
            //               }, "Priority", {
            //                   caption: "Completed",
            //                   dataType: "boolean",
            //                   calculateCellValue: function(rowData) {
            //                       return rowData.Status == "Completed";
            //                   }
            //               }],
            //               dataSource: new DevExpress.data.DataSource({
            //                   store: new DevExpress.data.ArrayStore({
            //                       key: "ID",
            //                       data: master_detail_data
            //                   }),
            //                   filter: ["EmployeeID", "=", options.key]
            //               })
            //           }).appendTo(container);
            //   }
            //   },
            //     columns: [{
            //       dataField: "Prefix",
            //       caption: "Title",
            //       width: 70
            //   },
            //   "FirstName",
            //   "LastName", {
            //       dataField: "Position",
            //       width: 170
            //   }, {
            //       dataField: "State",
            //       width: 125
            //   }, {
            //       dataField: "BirthDate",
            //       dataType: "date"
            //   }
            // ]
        };
        return config;
    }

    // function bingConfig(grid) {
    //   var dfd = $.Deferred();
    //   dfd.done(store);
    //   console.log('bingConfig function');
    //   return dfd;
    // }
});