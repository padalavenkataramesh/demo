define(function(require) {

    // var testData1 = require('text!demos/data-objects/test-data.json');
    // var testData = require('text!demos/data-objects/test-data1.json');
    var testData = require('text!demos/config-provider/employee-data.json');
    // console.log(JSON.parse(testData1));
    //    console.log(JSON.parse(testData));

    require('dist/datagrid');

    var masterDetailData = require("text!demos/data-objects/test-master-details-data.json");
    //code for creating datagrid in js
    // var element = document.createElement('aux-datagrid');
    // document.getElementById('dataGridContainer').append(element);
    const datagrid = document.querySelector('aux-datagrid');

    function loadData(grid, options) {
        var dfd = $.Deferred(),
            parsedData,
            pageIndex,
            pageSize;
        parsedData = JSON.parse(testData);
        // parsedData = testData;
        if (options && (options.skip || options.take)) {
            pageSize = options.take; // options.sort && options.sort.length ? $(grid).find('.gridContainer').dxDataGrid('instance').pageSize(): options.take;
            pageIndex = options.skip / pageSize;
            dfd.resolve(parsedData.data.slice(pageIndex, pageSize));
        } else {
            dfd.resolve(parsedData);
        }

        //console.log(arguments);
        return dfd;
    }

    function loadButtons() {
        var buttons = [
            /*{
                  type: 'customhtml',
                  iconClass: 'icon-collection-filter',
                  btnClass: 'btn btn-icon',
                  align: 'left',
                  content: $('<mi-filter-no-ko class="date-filter-" custom-filter="true" data-bind="attr: {title: "Filter")}" title="Filter">'+
                          '<div class="icon-filter-container">'+
                            '<button class="icon-container btn btn-icon">'+
                                '<i class="icon-collection-filter"></i>'+
                            '</button>'+
                          '</div>'+
                        '</mi-filter-no-ko>')
                  },*/
            //   {
            //   btnClass: 'icon-list2', height: '350px', align: 'right', action: 'sendTo', text: 'Send To', title: 'Send To', type: 'more-options', options: [
            //     { text: 'ACA Analysis', action: 'aca-analysis', noaccess: false, 'disabled': this.hasACAAnalysis },
            //     { text: 'ASSET_STRATEGY', action: 'asset-strategy', noaccess: false, 'disabled': this.hasStrategy },
            //     { text: 'SYSTEM_STRATEGY_CAPTION', action: 'sys-strategy', noaccess: false, 'disabled': this.hasSystemStrategy },
            //     { text: 'FMEA_ANALYSIS', action: 'fmea-analysis', noaccess: true, 'disabled': this.hasFMEAAnalysis },
            //     { text: 'RCM_ANALYSIS', action: 'rcm-analysis', noaccess: false, 'disabled': this.hasRCMAnalysis },
            //     { text: 'RBI_ASSET_VIEW', action: 'rbi-assset', noaccess: false, 'disabled': this.disableRBI }
            //   ]
            // }, { 'align': 'right', 'action': 'DeleteItem', 'title': 'Delete', 'iconClass': 'icon-delete-selected', 'btnClass': 'delete-selected', 'disabled': true },
            // { 'align': 'right', 'action': 'ExportItem', 'title': 'Export', 'iconClass': 'icon-upload', 'btnClass': 'export-selected' },
            // {
            //   align: 'left', type: 'customhtml', 'title': "ACTIVE_MEASUREMENTS_ONLY", content: $('<mi-checkbox-noko checked="true" text="i am checked"></mi-checkbox-noko>')
            //  },
            { btnClass: '', align: 'right', action: 'save', text: 'Save', title: 'Save', disabled: false },
            { btnClass: '', align: 'right', action: 'sendTo', text: 'Send To', title: 'Send To', disabled: false },
            {
                icon: 'icon-options',
                height: '350px',
                align: 'right',
                action: 'sendTo',
                title: 'Send To',
                type: 'more-options',
                options: [
                    { text: 'ACA Analysis', action: 'aca-analysis', noaccess: false, 'disabled': this.hasACAAnalysis },
                    { text: 'ASSET_STRATEGY', action: 'asset-strategy', noaccess: false, 'disabled': this.hasStrategy },
                    { text: 'SYSTEM_STRATEGY_CAPTION', action: 'sys-strategy', noaccess: false, 'disabled': this.hasSystemStrategy },
                    { text: 'FMEA_ANALYSIS', action: 'fmea-analysis', noaccess: true, 'disabled': this.hasFMEAAnalysis },
                    { text: 'RCM_ANALYSIS', action: 'rcm-analysis', noaccess: false, 'disabled': this.hasRCMAnalysis },
                    { text: 'RBI_ASSET_VIEW', action: 'rbi-assset', noaccess: false, 'disabled': this.disableRBI }
                ]
            },
            // {
            //   align: 'left', type: 'customhtml', 'title': "ACTIVE_MEASUREMENTS_ONLY", content: $('<button>placeholder</button>').attr('title', 'ACTIVE_MEASUREMENTS_ONLY')
            // },
            {
                align: 'left',
                type: 'customhtml',
                'btnClass': 'btn btn-icon icon-plus pull-left',
                'title': "ADD",
                'iconClass': 'icon-plus',
                content: $('<mi-more-options-noko icon="icon-plus"></mi-more-options-noko>').attr('iconClass', 'icon-plus')
            }

        ];
        return buttons;
    }

    function loadMasterDetailTemplate(container, options) {
        var currentEmployeeData = options.data;
        container.append($('<div class="employeeInfo"><img class="employeePhoto" src="' + currentEmployeeData.Picture + '" /><p class="employeeNotes">' + currentEmployeeData.Notes + '</p></div>'));
    };

    var employees = [{
        "ID": 1,
        "Prefix": "Mr.",
        "FirstName": "John",
        "LastName": "Heart",
        "Position": "CEO",
        "State": "California",
        "BirthDate": "1964/03/16"
    },
    {
        "ID": 2,
        "Prefix": "Mrs.",
        "FirstName": "Olivia",
        "LastName": "Peyton",
        "Position": "Sales Assistant",
        "State": "California",
        "BirthDate": "1981/06/03"
    },
    {
        "ID": 3,
        "Prefix": "Mr.",
        "FirstName": "Robert",
        "LastName": "Reagan",
        "Position": "CMO",
        "State": "Arkansas",
        "BirthDate": "1974/09/07"
    },
    {
        "ID": 4,
        "Prefix": "Ms.",
        "FirstName": "Greta",
        "LastName": "Sims",
        "Position": "HR Manager",
        "State": "Georgia",
        "BirthDate": "1977/11/22"
    },
    {
        "ID": 5,
        "Prefix": "Mr.",
        "FirstName": "Brett",
        "LastName": "Wade",
        "Position": "IT Manager",
        "State": "Idaho",
        "BirthDate": "1968/12/01"
    },
    {
        "ID": 6,
        "Prefix": "Mrs.",
        "FirstName": "Sandra",
        "LastName": "Johnson",
        "Position": "Controller",
        "State": "Utah",
        "BirthDate": "1974/11/15"
    },
    {
        "ID": 7,
        "Prefix": "Mr.",
        "FirstName": "Kevin",
        "LastName": "Carter",
        "Position": "Shipping Manager",
        "State": "California",
        "BirthDate": "1978/01/09"
    },
    {
        "ID": 8,
        "Prefix": "Ms.",
        "FirstName": "Cynthia",
        "LastName": "Stanwick",
        "Position": "HR Assistant",
        "State": "Arkansas",
        "BirthDate": "1985/06/05"
    },
    {
        "ID": 9,
        "Prefix": "Dr.",
        "FirstName": "Kent",
        "LastName": "Samuelson",
        "Position": "Ombudsman",
        "State": "Missouri",
        "BirthDate": "1972/09/11"
    }]
    
    var tasks = [{
        "ID": 1,
        "Subject": "Prepare 2013 Financial",
        "StartDate": "2013/01/15",
        "DueDate": "2013/01/31",
        "Status": "Completed",
        "Priority": "High",
        "Completion": 100,
        "EmployeeID": 8
    },
    {
        "ID": 2, "Subject": "Prepare 3013 Marketing Plan",
        "StartDate": "2013/01/01",
        "DueDate": "2013/01/31",
        "Status": "Completed",
        "Priority": "High",
        "Completion": 100,
        "EmployeeID": 5
    },
    {
        "ID": 3,
        "Subject": "Update Personnel Files",
        "StartDate": "2013/02/03",
        "DueDate": "2013/02/28",
        "Status": "Completed",
        "Priority": "High",
        "Completion": 100,
        "EmployeeID": 2
    },
    {
        "ID": 4,
        "Subject": "Review Health Insurance Options Under the Affordable Care Act",
        "StartDate": "2013/02/12",
        "DueDate": "2013/04/25",
        "Status": "In Progress",
        "Priority": "High",
        "Completion": 50,
        "EmployeeID": 2
    },
    {
        "ID": 5,
        "Subject": "Choose between PPO and HMO Health Plan",
        "StartDate": "2013/02/15",
        "DueDate": "2013/04/15",
        "Status": "In Progress", "Priority": "High",
        "Completion": 75,
        "EmployeeID": 1
    },
    {
        "ID": 6,
        "Subject": "Google AdWords Strategy",
        "StartDate": "2013/02/16",
        "DueDate": "2013/02/28",
        "Status": "Completed",
        "Priority": "High",
        "Completion": 100,
        "EmployeeID": 1
    },
    {
        "ID": 7,
        "Subject": "New Brochures",
        "StartDate": "2013/02/17",
        "DueDate": "2013/02/24",
        "Status": "Completed",
        "Priority": "Normal",
        "Completion": 100,
        "EmployeeID": 1
    },
    {
        "ID": 11,
        "Subject": "Rollout of New Website and Marketing Brochures",
        "StartDate": "2013/02/20",
        "DueDate": "2013/02/28",
        "Status": "Completed",
        "Priority": "High",
        "Completion": 100,
        "EmployeeID": 5
    },
    {
        "ID": 12,
        "Subject": "Update Sales Strategy Documents",
        "StartDate": "2013/02/20",
        "DueDate": "2013/02/22",
        "Status": "Completed",
        "Priority": "Normal",
        "Completion": 100,
        "EmployeeID": 9
    },
    {
        "ID": 15,
        "Subject": "Review 2012 Sales Report and Approve 2013 Plans",
        "StartDate": "2013/02/23",
        "DueDate": "2013/02/28",
        "Status": "Completed",
        "Priority": "Normal",
        "Completion": 100,
        "EmployeeID": 5
    },
    {
        "ID": 16,
        "Subject": "Deliver R&D Plans for 2013",
        "StartDate": "2013/03/01",
        "DueDate": "2013/03/10",
        "Status": "Completed",
        "Priority": "High",
        "Completion": 100,
        "EmployeeID": 3
    },
    {
        "ID": 20,
        "Subject": "Approve Hiring of John Jeffers",
        "StartDate": "2013/03/02",
        "DueDate": "2013/03/12",
        "Status": "Completed",
        "Priority": "Normal",
        "Completion": 100,
        "EmployeeID": 4
    },
    {
        "ID": 20,
        "Subject": "Approve Hiring of John Jeffers",
        "StartDate": "2013/03/02",
        "DueDate": "2013/03/12",
        "Status": "Completed",
        "Priority": "Normal",
        "Completion": 100,
        "EmployeeID": 6
    },
    {
        "ID": 21,
        "Subject": "Non-Compete Agreements",
        "StartDate": "2013/03/12",
        "DueDate": "2013/03/14",
        "Status": "Completed",
        "Priority": "Low",
        "Completion": 100,
        "EmployeeID": 2
    },
    {
        "ID": 22,
        "Subject": "Update NDA Agreement",
        "StartDate": "2013/03/14",
        "DueDate": "2013/03/16",
        "Status": "Completed",
        "Priority": "High",
        "Completion": 100,
        "EmployeeID": 1
    },
    {
        "ID": 23,
        "Subject": "Update Employee Files with New NDA",
        "StartDate": "2013/03/16",
        "DueDate": "2013/03/26",
        "Status": "Need Assistance",
        "Priority": "Normal",
        "Completion": 90,
        "EmployeeID": 4
    },
    {
        "ID": 24,
        "Subject": "Update Employee Files with New NDA",
        "StartDate": "2013/03/16",
        "DueDate": "2013/03/26",
        "Status": "Need Assistance",
        "Priority": "Normal",
        "Completion": 90,
        "EmployeeID": 6
    },
    {
        "ID": 25,
        "Subject": "Sign Updated NDA",
        "StartDate": "2013/03/20",
        "DueDate": "2013/03/25",
        "Status": "Completed",
        "Priority": "Urgent",
        "Completion": 100,
        "EmployeeID": 7
    },
    {
        "ID": 26,
        "Subject": "Sign Updated NDA",
        "StartDate": "2013/03/20",
        "DueDate": "2013/03/25",
        "Status": "Completed",
        "Priority": "Urgent",
        "Completion": 100,
        "EmployeeID": 8
    },
    {
        "ID": 27,
        "Subject": "Sign Updated NDA",
        "StartDate": "2013/03/20",
        "DueDate": "2013/03/25",
        "Status": "Need Assistance",
        "Priority": "Urgent",
        "Completion": 25,
        "EmployeeID": 9
    },
    {
        "ID": 35,
        "Subject": "Update Revenue Projections",
        "StartDate": "2013/03/24",
        "DueDate": "2013/04/07",
        "Status": "Completed",
        "Priority": "Normal",
        "Completion": 100,
        "EmployeeID": 8
    },
    {
        "ID": 36,
        "Subject": "Review Revenue Projections",
        "StartDate": "2013/03/25",
        "DueDate": "2013/04/06",
        "Status": "Completed",
        "Priority": "High",
        "Completion": 100,
        "EmployeeID": 9
    },
    {
        "ID": 40,
        "Subject": "Provide New Health Insurance Docs",
        "StartDate": "2013/03/28",
        "DueDate": "2013/04/07",
        "Status": "Completed",
        "Priority": "Normal",
        "Completion": 100,
        "EmployeeID": 4
    },
    {
        "ID": 41,
        "Subject": "Provide New Health Insurance Docs",
        "StartDate": "2013/03/28",
        "DueDate": "2013/04/07",
        "Status": "Completed",
        "Priority": "Normal",
        "Completion": 100,
        "EmployeeID": 6
    },
    {
        "ID": 50,
        "Subject": "Give Final Approval for Refunds",
        "StartDate": "2013/05/05",
        "DueDate": "2013/05/15",
        "Status": "Completed",
        "Priority": "Normal",
        "Completion": 100,
        "EmployeeID": 2
    },
    {
        "ID": 52,
        "Subject": "Review Product Recall Report by Engineering Team",
        "StartDate": "2013/05/17",
        "DueDate": "2013/05/20",
        "Status": "Completed",
        "Priority": "High",
        "Completion": 100,
        "EmployeeID": 1
    },
    {
        "ID": 55,
        "Subject": "Review Overtime Report",
        "StartDate": "2013/06/10",
        "DueDate": "2013/06/14",
        "Status": "Completed",
        "Priority": "Normal",
        "Completion": 100,
        "EmployeeID": 7
    },
    {
        "ID": 60,
        "Subject": "Refund Request Template",
        "StartDate": "2013/06/17",
        "DueDate": "2014/04/01",
        "Status": "Deferred",
        "Priority": "Normal",
        "Completion": 0,
        "EmployeeID": 9
    },
    {
        "ID": 71,
        "Subject": "Upgrade Server Hardware",
        "StartDate": "2013/07/22",
        "DueDate": "2013/07/31",
        "Status": "Completed",
        "Priority": "Urgent",
        "Completion": 100,
        "EmployeeID": 7
    },
    {
        "ID": 72,
        "Subject": "Upgrade Personal Computers",
        "StartDate": "2013/07/24",
        "DueDate": "2014/04/30",
        "Status": "In Progress",
        "Priority": "Normal",
        "Completion": 85,
        "EmployeeID": 7
    },
    {
        "ID": 74,
        "Subject": "Decide on Mobile Devices to Use in the Field",
        "StartDate": "2013/07/30",
        "DueDate": "2013/08/02",
        "Status": "Completed",
        "Priority": "High",
        "Completion": 100,
        "EmployeeID": 3
    },
    {
        "ID": 78,
        "Subject": "Try New Touch-Enabled WinForms Apps",
        "StartDate": "2013/08/11",
        "DueDate": "2013/08/15",
        "Status": "Completed",
        "Priority": "Normal",
        "Completion": 100,
        "EmployeeID": 3
    },
    {
        "ID": 81,
        "Subject": "Review Site Up-Time Report",
        "StartDate": "2013/08/24",
        "DueDate": "2013/08/30",
        "Status": "Completed",
        "Priority": "Urgent",
        "Completion": 100,
        "EmployeeID": 5
    },
    {
        "ID": 99,
        "Subject": "Submit D&B Number to ISP for Credit Approval",
        "StartDate": "2013/11/04",
        "DueDate": "2013/11/07",
        "Status": "Completed",
        "Priority": "High",
        "Completion": 100,
        "EmployeeID": 8
    },
    {
        "ID": 117,
        "Subject": "Approval on Converting to New HDMI Specification",
        "StartDate": "2014/01/11",
        "DueDate": "2014/01/31",
        "Status": "Deferred",
        "Priority": "Normal",
        "Completion": 75,
        "EmployeeID": 3
    },
    {
        "ID": 138,
        "Subject": "Review HR Budget Company Wide",
        "StartDate": "2014/03/20",
        "DueDate": "2014/03/25",
        "Status": "In Progress",
        "Priority": "Normal",
        "Completion": 40,
        "EmployeeID": 6
    },
    {
        "ID": 145,
        "Subject": "Final Budget Review",
        "StartDate": "2014/03/26",
        "DueDate": "2014/03/27",
        "Status": "In Progress",
        "Priority": "High",
        "Completion": 25,
        "EmployeeID": 6
    }];

    //Properties
    $(datagrid)[0].resourcestext = { 'Dg_Sort_Ascending_Caption': 'Sort Ascending-new', "DG_NO_DATA_CAPTION": "empty"};
    //$(datagrid)[0].loadConfigurableButtons = loadButtons.bind(self, datagrid);
    $(datagrid)[0].loadMasterDetailTemplate = loadMasterDetailTemplate.bind(self);
    //$(datagrid)[0].handleRemoteDataLoad = loadData.bind(self, datagrid);
    //$(datagrid)[0].loadJSONData = loadData.bind(self, datagrid);
    //$(datagrid)[0].totalCountCB = handleTotalCount.bind(self, datagrid);


    /* $(datagrid)[0].loadJSONConfig = {
        masterDetail: {
          enabled: true,
          template: function(container, options) { 
            var currentEmployeeData = options.data;
            container.append($('<div class="employeeInfo"><img class="employeePhoto" src="' + currentEmployeeData.Picture + '" /><p class="employeeNotes">' + currentEmployeeData.Notes + '</p></div>'));
          }
      }
    } */



    //Attributes
    //$(datagrid).attr('datamode', 'remote');
    $(datagrid).attr('filterpanelvisible', false);
    $(datagrid).attr('allowColumnReordering', true);
    $(datagrid).attr('showsearchpanel', true);
    $(datagrid).attr('showgroupingpanel', true);
    $(datagrid).attr('autoexpandgroup', false);
    $(datagrid).attr('columnresizingmode', 'nextColumn');
    $(datagrid).attr('allowcolumnresizing', true);
    $(datagrid).attr('columnautowidth', false);
    // $(datagrid).attr('isrowfilteropened', true);
    $(datagrid).attr('showrowfilter', true);
    //$(datagrid).attr('allowrowediting', true);
    $(datagrid).attr('sortingmode', 'multiple');
    $(datagrid).attr('rowfilteradvancedoperators', true);
    $(datagrid).attr('contextmenuenabled', true);
    $(datagrid).attr('showheaderfilter', true);

    //$(datagrid).attr('showfooter', true);
    $(datagrid).attr('allowedpagesizes', JSON.stringify([10, 25, 50, 100]));
    $(datagrid).attr('pagesize', 10);
    $(datagrid).attr('selectionmode', 'multiple');
    $(datagrid).attr('selectallmode', 'allPages');
    $(datagrid).attr('allowrowediting', false);
    $(datagrid).attr('allowrowadding', false);
    $(datagrid).attr('allowexportdata', true);
    $(datagrid).attr('allowexportselecteddata', true);
    $(datagrid).attr('exporttocsvenabled', false);

    $(datagrid).attr('hasColumnChooser', 'true');
    //$(datagrid).attr('columnChooserMode', ["SelecT", "aDvanced"]); //select
    $(datagrid).attr('columnChooserMode', "SelecT"); //select
    $(datagrid).attr('enableMasterDetail', false);
    datagrid.resourcestext = {
        "DG_NO_DATA_CAPTION": "empty"
    };

    //Callbacks
    $(datagrid)[0].onRowSelectCB = onRowSelected.bind(datagrid, self);
    $(datagrid)[0].onPageChangeCB = onPageChanged.bind(datagrid, self);
    $(datagrid)[0].onRowMultiSelectCB = onRowMultiSelected.bind(datagrid, self);
    $(datagrid)[0].cellTemplateCB = cellTemplate.bind(datagrid, self);
    $(datagrid)[0].onRowPreparedCB = onRowPrepared.bind(datagrid, self);
    $(datagrid)[0].cellPreparedCB = onCellPrepared.bind(datagrid, self);
    $(datagrid)[0].editorPreparedCB = onEditorPrepared.bind(datagrid, self);
    $(datagrid)[0].onInitNewRowCB = onInitNewRow.bind(datagrid, self);
    $(datagrid)[0].gridLoadedCB = onGridLoaded.bind(datagrid, self);
    $(datagrid)[0].toolbarItemClickCallback = toolbarItemClicked.bind(datagrid, datagrid);
    $(datagrid)[0].onRowInsertingCB = handleRowInserting.bind(datagrid, self);
    $(datagrid)[0].onRowUpdatingCB = handleRowUpdating.bind(datagrid, self);
    $(datagrid)[0].onRowRemovingCB = handleRowRemoving.bind(datagrid, self);
    $(datagrid)[0].onCustomizeExportDataCB = customizeExportData.bind(datagrid, self);
    $(datagrid)[0].onExportingCB = onExportingData.bind(datagrid, self);
    $(datagrid)[0].onExportedCB = onExported.bind(datagrid, self);
    $(datagrid)[0].onEditorPreparingCB = onEditorPreparing.bind(datagrid, self);
    $(datagrid)[0].onOptionChangedCB = onOptionChanged.bind(datagrid, self);
    $(datagrid)[0].onToolbarPreparingCB = onToolbarPreparing.bind(datagrid, self);
    $(datagrid)[0].onEditingStartCB = onEditingStart.bind(datagrid, self);
    $(datagrid)[0].onInitializedCB = onInitializedCallback.bind(datagrid, self);
    $(datagrid)[0].customizeColumns = customizeColumns.bind(datagrid, self);

    //$(datagrid)[0].loadJSONData = loadMasterDetailData.bind(self, datagrid);
    //$(datagrid)[0].loadJSONData = loadData.bind(self, datagrid);
    datagrid.addEventListener('auxdatagrid.registered', () => { console.log('auxdatagrid.registered'); })

    datagrid.disableButton('delete-selected', false);
    setTimeout(function() {
        // $(datagrid)[0].onInitializedCB = gridIntialized.bind(self, datagrid);
        //$(datagrid)[0].setAttribute('datamode', 'remote');
        $(datagrid)[0].configOptionsCB = configOptionsCallback(datagrid);
    }, 1000);

    function configOptionsCallback(){
        var config = { dataSource: employees,
        keyExpr: "ID",
        pageSize: 50,
        //showBorders: true,
        columns: [{
                dataField: "Prefix",
                caption: "Title",
                width: 70
            },
            "FirstName",
            "LastName", {
                dataField: "Position",
                width: 170
            }, {
                dataField: "State",
                width: 125
            }, {
                dataField: "BirthDate",
                dataType: "date"
            }
        ],
        masterDetail: {
            enabled: true,
            template: function(container, options) { 
                var currentEmployeeData = options.data;

                $("<div>")
                    .addClass("master-detail-caption")
                    .text(currentEmployeeData.FirstName + " " + currentEmployeeData.LastName + "'s Tasks:")
                    .appendTo(container);

                $("<div>")
                    .dxDataGrid({
                        columnAutoWidth: true,
                        showBorders: true,
                        columns: ["Subject", {
                            dataField: "StartDate",
                            dataType: "date"
                        }, {
                            dataField: "DueDate",
                            dataType: "date"
                        }, "Priority", {
                            caption: "Completed",
                            dataType: "boolean",
                            calculateCellValue: function(rowData) {
                                return rowData.Status == "Completed";
                            }
                        }],
                        dataSource: new DevExpress.data.DataSource({
                            store: new DevExpress.data.ArrayStore({
                                key: "ID",
                                data: tasks
                            }),
                            filter: ["EmployeeID", "=", options.key]
                        })
                    }).appendTo(container);
            }
        }
    }
        
        return config;
    }

    function customizeColumns(self, columns) {
        //debugger;
        //console.log(columns[1]);
        //columns[1].groupIndex = 0;//showWhenGrouped
        columns[1].visible = false; //showWhenGrouped
        // columns[0].showWhenGrouped = true;//
        // columns[1].showWhenGrouped = true;//
        //if(converter.toBoolean(self.showGroupingPanel, true)){
        columns.forEach(column => {
            //console.log('column.caption: ', column.caption +" column.showWhenGrouped: ", column.showWhenGrouped);
        });
        //}
        columns[2].encodeHtml = false;
        // console.log('customizeColumns');
    }

    function onInitializedCallback(self) {
        // console.log('onInitializedCallback', arguments);
    }

    function onEditingStart(self) {
        console.log('onEditingStart', arguments);
    }

    function onToolbarPreparing(self) {
        //console.log('onToolbarPreparing', arguments);
    }

    function onOptionChanged(self) {
        //console.log('onOptionChanged', arguments);
    }

    function customizeExportData(self, data, rowsData) {
        console.log('customizeExportData', arguments);
    }

    function onExportingData(self) {
        console.log('onExportingCB', arguments);
    }

    function onExported(self) {
        console.log('onExported', arguments);
    }

    function onEditorPreparing(self) {
        //console.log('onEditorPreparingCallback', arguments);
    }

    function handleRowInserting(self) {
        console.log('handleRowInserting', arguments);
    }

    function handleRowUpdating(self) {
        console.log('handleRowUpdating', arguments);
    }

    function handleRowRemoving(self) {
        console.log('handleRowRemoving', arguments);
    }


    function onRowSelected(self) {
        console.log('onRowSelected', arguments);
    }

    function onPageChanged(self) {
        console.log('onPageChanged', arguments);
    }

    function onRowMultiSelected(self) {
        console.log('onRowMultiSelected', arguments);
    }

    function cellTemplate(self) {
        console.log('cellTemplate', arguments);
    }

    function onRowPrepared(self) {
        //console.log('onRowPrepared', arguments);
    }

    function onCellPrepared(self, tableData, e) {
        //console.log(e.rowType);
        if (e.column.dataField === "entityKey") {
            if (e.rowType == 'header') {
                e.cellElement.find(".dx-header-filter").hide();
            }
        }
        //console.log('onCellPrepared', arguments);
    }

    function onEditorPrepared(self) {
        //console.log('onEditorPrepared', arguments);
    }

    function onInitNewRow(self) {
        console.log('onInitNewRowCB', arguments);
    }

    function onGridLoaded(self) {
        //console.log('onGridLoaded', arguments);
    }

    function toolbarItemClicked(self, action) {
        if (action === 'sendTo') {
            //self.gridInstance.getRowIndexByKey(self.gridInstance.getSelectedRowsData()[0])
            if (!!this.gridInstance.getSelectedRowsData().length) {
                var selectedRowsLength = this.gridInstance.getSelectedRowsData().length;
                $('.editor-panel').css('display', 'block');
                for (var i = 0; i < selectedRowsLength; i++) {

                }
            }
        } else if (action === 'save') {
            $('.editor-panel').css('display', 'none');


        }
        //console.log('toolbarItemClicked', arguments);
    }

    function handleTotalCount(self, dfd) {
        console.log('handleTotalCount');
        //var dfd = $.Deferred();  
        dfd.resolve(39);
        //return dfd;
    }
});