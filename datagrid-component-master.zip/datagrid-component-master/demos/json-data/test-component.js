define(function(require) {

    // var testData1 = require('text!demos/data-objects/test-data.json');
    // var testData = require('text!demos/data-objects/test-data1.json');
    var testData = require('text!demos/config-provider/employee-data.json');
    // console.log(JSON.parse(testData1));
    //    console.log(JSON.parse(testData));

    require('dist/datagrid');

    var masterDetailData = require("text!demos/data-objects/test-master-details-data.json");
    //code for creating datagrid in js
    // var element = document.createElement('aux-datagrid');
    // document.getElementById('dataGridContainer').append(element);
    const datagrid = document.querySelector('aux-datagrid');

    function loadData(grid, options) {
        var dfd = $.Deferred(),
            parsedData,
            pageIndex,
            pageSize;
        parsedData = JSON.parse(testData);
        // parsedData = testData;
        if (options && (options.skip || options.take)) {
            pageSize = options.take; // options.sort && options.sort.length ? $(grid).find('.gridContainer').dxDataGrid('instance').pageSize(): options.take;
            pageIndex = options.skip / pageSize;
            dfd.resolve(parsedData.data.slice(pageIndex, pageSize));
        } else {
            dfd.resolve(parsedData);
        }

        //console.log(arguments);
        return dfd;
    }

    function loadButtons() {
        var buttons = [
            { btnClass: '', align: 'right', action: 'save', text: 'Save', title: 'Save', disabled: false },
            { btnClass: '', align: 'right', action: 'sendTo', text: 'Send To', title: 'Send To', disabled: false },
            {
                icon: 'icon-options',
                height: '350px',
                align: 'right',
                action: 'sendTo',
                title: 'Send To',
                type: 'more-options',
                options: [
                    { text: 'ACA Analysis', action: 'aca-analysis', noaccess: false, 'disabled': this.hasACAAnalysis },
                    { text: 'ASSET_STRATEGY', action: 'asset-strategy', noaccess: false, 'disabled': this.hasStrategy },
                    { text: 'SYSTEM_STRATEGY_CAPTION', action: 'sys-strategy', noaccess: false, 'disabled': this.hasSystemStrategy },
                    { text: 'FMEA_ANALYSIS', action: 'fmea-analysis', noaccess: true, 'disabled': this.hasFMEAAnalysis },
                    { text: 'RCM_ANALYSIS', action: 'rcm-analysis', noaccess: false, 'disabled': this.hasRCMAnalysis },
                    { text: 'RBI_ASSET_VIEW', action: 'rbi-assset', noaccess: false, 'disabled': this.disableRBI }
                ]
            },
            // {
            //   align: 'left', type: 'customhtml', 'title': "ACTIVE_MEASUREMENTS_ONLY", content: $('<button>placeholder</button>').attr('title', 'ACTIVE_MEASUREMENTS_ONLY')
            // },
            {
                align: 'left',
                type: 'customhtml',
                'btnClass': 'btn btn-icon icon-plus pull-left',
                'title': "ADD",
                'iconClass': 'icon-plus',
                content: $('<mi-more-options-noko icon="icon-plus"></mi-more-options-noko>').attr('iconClass', 'icon-plus')
            }

        ];
        return buttons;
    }

    function loadMasterDetailTemplate(container, options) {
        var currentEmployeeData = options.data;
        container.append($('<div class="employeeInfo"><img class="employeePhoto" src="' + currentEmployeeData.Picture + '" /><p class="employeeNotes">' + currentEmployeeData.Notes + '</p></div>'));
    };

    //Properties
    $(datagrid)[0].resourcestext = { 'Dg_Sort_Ascending_Caption': 'Sort Ascending-new', "DG_NO_DATA_CAPTION": "empty"};
    //$(datagrid)[0].loadConfigurableButtons = loadButtons.bind(self, datagrid);
    $(datagrid)[0].loadMasterDetailTemplate = loadMasterDetailTemplate.bind(self);
    //$(datagrid)[0].handleRemoteDataLoad = loadData.bind(self, datagrid);
    //$(datagrid)[0].loadJSONData = loadData.bind(self, datagrid);
    //$(datagrid)[0].totalCountCB = handleTotalCount.bind(self, datagrid);


    /* $(datagrid)[0].loadJSONConfig = {
        masterDetail: {
          enabled: true,
          template: function(container, options) { 
            var currentEmployeeData = options.data;
            container.append($('<div class="employeeInfo"><img class="employeePhoto" src="' + currentEmployeeData.Picture + '" /><p class="employeeNotes">' + currentEmployeeData.Notes + '</p></div>'));
          }
      }
    } */



    //Attributes
    //$(datagrid).attr('datamode', 'remote');
    $(datagrid).attr('filterpanelvisible', false);
    $(datagrid).attr('allowColumnReordering', true);
    $(datagrid).attr('showsearchpanel', true);
    $(datagrid).attr('showgroupingpanel', true);
    $(datagrid).attr('autoexpandgroup', false);
    $(datagrid).attr('columnresizingmode', 'nextColumn');
    $(datagrid).attr('allowcolumnresizing', true);
    $(datagrid).attr('columnautowidth', false);
    $(datagrid).attr('isrowfilteropened', true);
    $(datagrid).attr('showrowfilter', true);
    //$(datagrid).attr('allowrowediting', true);
    $(datagrid).attr('sortingmode', 'multiple');
    $(datagrid).attr('rowfilteradvancedoperators', true);
    $(datagrid).attr('contextmenuenabled', true);
    $(datagrid).attr('showheaderfilter', true);
    $(datagrid).attr('hidesortfromgroupingpanel', true);
    //$(datagrid).attr('showfooter', true);
    $(datagrid).attr('allowedpagesizes', JSON.stringify([10, 25, 50, 100]));
    $(datagrid).attr('pagesize', 10);
    $(datagrid).attr('selectionmode', 'multiple');
    $(datagrid).attr('selectallmode', 'allPages');
    $(datagrid).attr('allowrowediting', false);
    $(datagrid).attr('allowrowadding', false);
    $(datagrid).attr('allowexportdata', true);
    $(datagrid).attr('allowexportselecteddata', true);
    $(datagrid).attr('exporttocsvenabled', false);

    $(datagrid).attr('hasColumnChooser', 'true');
    // $(datagrid).attr('columnChooserMode', ["select", "advanced"]); //select
    $(datagrid).attr('columnChooserMode', "select"); //select
    $(datagrid).attr('enableMasterDetail', false);
    datagrid.resourcestext = {
        "DG_NO_DATA_CAPTION": "empty"
    };

    //Callbacks
    $(datagrid)[0].onRowSelectCB = onRowSelected.bind(datagrid, self);
    $(datagrid)[0].onPageChangeCB = onPageChanged.bind(datagrid, self);
    $(datagrid)[0].onRowMultiSelectCB = onRowMultiSelected.bind(datagrid, self);
    $(datagrid)[0].cellTemplateCB = cellTemplate.bind(datagrid, self);
    $(datagrid)[0].onRowPreparedCB = onRowPrepared.bind(datagrid, self);
    $(datagrid)[0].cellPreparedCB = onCellPrepared.bind(datagrid, self);
    $(datagrid)[0].editorPreparedCB = onEditorPrepared.bind(datagrid, self);
    $(datagrid)[0].onInitNewRowCB = onInitNewRow.bind(datagrid, self);
    $(datagrid)[0].gridLoadedCB = onGridLoaded.bind(datagrid, self);
    $(datagrid)[0].toolbarItemClickCallback = toolbarItemClicked.bind(datagrid, datagrid);
    $(datagrid)[0].onRowInsertingCB = handleRowInserting.bind(datagrid, self);
    $(datagrid)[0].onRowUpdatingCB = handleRowUpdating.bind(datagrid, self);
    $(datagrid)[0].onRowRemovingCB = handleRowRemoving.bind(datagrid, self);
    $(datagrid)[0].onCustomizeExportDataCB = customizeExportData.bind(datagrid, self);
    $(datagrid)[0].onExportingCB = onExportingData.bind(datagrid, self);
    $(datagrid)[0].onExportedCB = onExported.bind(datagrid, self);
    $(datagrid)[0].onEditorPreparingCB = onEditorPreparing.bind(datagrid, self);
    $(datagrid)[0].onOptionChangedCB = onOptionChanged.bind(datagrid, self);
    $(datagrid)[0].onToolbarPreparingCB = onToolbarPreparing.bind(datagrid, self);
    $(datagrid)[0].onEditingStartCB = onEditingStart.bind(datagrid, self);
    $(datagrid)[0].onInitializedCB = onInitializedCallback.bind(datagrid, self);
    $(datagrid)[0].customizeColumns = customizeColumns.bind(datagrid, self);
    $(datagrid)[0].gridPreferencesCB = gridPreferencesChanged.bind(datagrid, self);
   
    
    //$(datagrid)[0].loadJSONData = loadMasterDetailData.bind(self, datagrid);
    $(datagrid)[0].loadJSONData = loadData.bind(self, datagrid);
    datagrid.addEventListener('auxdatagrid.registered', () => { console.log('auxdatagrid.registered'); })

    datagrid.disableButton('delete-selected', false);

    function gridPreferencesChanged(self, columnsData){
        console.log(columnsData);
    }

    function customizeColumns(self, columns) {
        //debugger;
        //console.log(columns[1]);
        //columns[1].groupIndex = 0;//showWhenGrouped
        columns[1].visible = false; //showWhenGrouped
        // columns[0].showWhenGrouped = true;//
        // columns[1].showWhenGrouped = true;//
        //if(converter.toBoolean(self.showGroupingPanel, true)){
        columns.forEach(column => {
            //console.log('column.caption: ', column.caption +" column.showWhenGrouped: ", column.showWhenGrouped);
        });
        //}
        columns[2].encodeHtml = false;
        // console.log('customizeColumns');
    }

    function onInitializedCallback(self) {
        // console.log('onInitializedCallback', arguments);
    }

    function onEditingStart(self) {
        console.log('onEditingStart', arguments);
    }

    function onToolbarPreparing(self) {
        //console.log('onToolbarPreparing', arguments);
    }

    function onOptionChanged(self) {
        //console.log('onOptionChanged', arguments);
    }

    function customizeExportData(self, data, rowsData) {
        console.log('customizeExportData', arguments);
    }

    function onExportingData(self) {
        console.log('onExportingCB', arguments);
    }

    function onExported(self) {
        console.log('onExported', arguments);
    }

    function onEditorPreparing(self) {
        //console.log('onEditorPreparingCallback', arguments);
    }

    function handleRowInserting(self) {
        console.log('handleRowInserting', arguments);
    }

    function handleRowUpdating(self) {
        console.log('handleRowUpdating', arguments);
    }

    function handleRowRemoving(self) {
        console.log('handleRowRemoving', arguments);
    }


    function onRowSelected(self) {
        console.log('onRowSelected', arguments);
    }

    function onPageChanged(self) {
        console.log('onPageChanged', arguments);
    }

    function onRowMultiSelected(self) {
        console.log('onRowMultiSelected', arguments);
    }

    function cellTemplate(self) {
        console.log('cellTemplate', arguments);
    }

    function onRowPrepared(self) {
        //console.log('onRowPrepared', arguments);
    }

    function onCellPrepared(self, tableData, e) {
        //console.log(e.rowType);
        if (e.column.dataField === "entityKey") {
            if (e.rowType == 'header') {
                e.cellElement.find(".dx-header-filter").hide();
            }
        }
        //console.log('onCellPrepared', arguments);
    }

    function onEditorPrepared(self) {
        //console.log('onEditorPrepared', arguments);
    }

    function onInitNewRow(self) {
        console.log('onInitNewRowCB', arguments);
    }

    function onGridLoaded(self) {
        //console.log('onGridLoaded', arguments);
    }

    function toolbarItemClicked(self, action) {
        if (action === 'sendTo') {
            //self.gridInstance.getRowIndexByKey(self.gridInstance.getSelectedRowsData()[0])
            if (!!this.gridInstance.getSelectedRowsData().length) {
                var selectedRowsLength = this.gridInstance.getSelectedRowsData().length;
                $('.editor-panel').css('display', 'block');
                for (var i = 0; i < selectedRowsLength; i++) {

                }
            }
        } else if (action === 'save') {
            $('.editor-panel').css('display', 'none');


        }
        //console.log('toolbarItemClicked', arguments);
    }

    function handleTotalCount(self, dfd) {
        console.log('handleTotalCount');
        //var dfd = $.Deferred();  
        dfd.resolve(39);
        //return dfd;
    }
});