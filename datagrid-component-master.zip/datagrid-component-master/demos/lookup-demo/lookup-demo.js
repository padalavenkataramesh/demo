define(function(require) {
  var testData = require("text!demos/data-objects/test-data.json");
  require("dist/datagrid");

  var masterDetailData = require("text!demos/data-objects/test-master-details-data.json");
  var employeesData = require("text!demos/data-objects/test-employees-data.json");
  var statesData = require("text!demos/data-objects/test-states-data.json");
  var citiesData = require("text!demos/data-objects/test-cities-data.json");

  const datagrid = document.querySelector("aux-datagrid");

  const states = JSON.parse(statesData);
  const cities = JSON.parse(citiesData);
  
  function loadMasterDetailTemplate(container, options) {
    var currentEmployeeData = options.data;
    container.append(
      $(
        '<div class="employeeInfo"><img class="employeePhoto" src="' +
          currentEmployeeData.Picture +
          '" /><p class="employeeNotes">' +
          currentEmployeeData.Notes +
          "</p></div>"
      )
    );
  }

  //Properties
  $(datagrid)[0].resourcestext = {
    Dg_Sort_Ascending_Caption: "Sort Ascending-new"
  };
  //$(datagrid)[0].loadConfigurableButtons = loadButtons.bind(self, datagrid);
  //$(datagrid)[0].handleRemoteDataLoad = loadData.bind(self, datagrid);
  //$(datagrid)[0].totalCountCB = handleTotalCount.bind(self, datagrid);

  function loadData(grid, options) {
    var dfd = $.Deferred(),
      parsedData,
      pageIndex,
      pageSize;
    parsedData = JSON.parse(employeesData);
    if (options && (options.skip || options.take)) {
      pageSize = options.take; // options.sort && options.sort.length ? $(grid).find('.gridContainer').dxDataGrid('instance').pageSize(): options.take;
      pageIndex = options.skip / pageSize;
      dfd.resolve(parsedData.data.slice(pageIndex, pageSize));
    } else {
      dfd.resolve(parsedData);
      //console.log("loadData", employeesData);
    }

    return dfd;
  }

  //Attributes
  $(datagrid).attr("datamode", "remote");
  $(datagrid).attr("filterpanelvisible", false);
  $(datagrid).attr("allowColumnReordering", true);
  $(datagrid).attr("showsearchpanel", true);
  $(datagrid).attr("showgroupingpanel", true);
  $(datagrid).attr("allowcolumnresizing", true);
  $(datagrid).attr("columnautowidth", false);
  $(datagrid).attr("showrowfilter", true);
  //$(datagrid).attr('allowrowediting', true);
  $(datagrid).attr("sortingmode", "none");
  $(datagrid).attr("rowfilteradvancedoperators", true);
  $(datagrid).attr("contextmenuenabled", false);
  $(datagrid).attr("showheaderfilter", true);

  //$(datagrid).attr('showfooter', true);
  $(datagrid).attr("allowedpagesizes", JSON.stringify([10, 50, 100, 250]));
  $(datagrid).attr("pagesize", 10);
  $(datagrid).attr("selectionmode", "multiple");
  $(datagrid).attr("selectallmode", "allPages");
  $(datagrid).attr("allowrowediting", true);
  $(datagrid).attr("allowrowadding", true);
  $(datagrid).attr("allowexportdata", true);
  $(datagrid).attr("allowexportselecteddata", true);
  $(datagrid).attr("exporttocsvenabled", false);

  $(datagrid).attr("hasColumnChooser", "true");
  $(datagrid).attr("columnChooserMode", "advanced"); //select
  $(datagrid).attr("enableMasterDetail", false);

  //Callbacks
  $(datagrid)[0].onRowSelectCB = onRowSelected.bind(datagrid, self);
  $(datagrid)[0].onPageChangeCB = onPageChanged.bind(datagrid, self);
  $(datagrid)[0].onRowMultiSelectCB = onRowMultiSelected.bind(datagrid, self);
  $(datagrid)[0].cellTemplateCB = cellTemplate.bind(datagrid, self);
  $(datagrid)[0].onRowPreparedCB = onRowPrepared.bind(datagrid, self);
  $(datagrid)[0].cellPreparedCB = onCellPrepared.bind(datagrid, self);
  $(datagrid)[0].editorPreparedCB = onEditorPrepared.bind(datagrid, self);
  $(datagrid)[0].onInitNewRowCB = onInitNewRow.bind(datagrid, self);
  $(datagrid)[0].gridLoadedCB = onGridLoaded.bind(datagrid, self);
  $(datagrid)[0].toolbarItemClickCallback = toolbarItemClicked.bind(
    datagrid,
    datagrid
  );
  $(datagrid)[0].onRowInsertingCB = handleRowInserting.bind(datagrid, self);
  $(datagrid)[0].onRowUpdatingCB = handleRowUpdating.bind(datagrid, self);
  $(datagrid)[0].onRowRemovingCB = handleRowRemoving.bind(datagrid, self);
  $(datagrid)[0].onCustomizeExportDataCB = customizeExportData.bind(
    datagrid,
    self
  );
  $(datagrid)[0].onExportingCB = onExportingData.bind(datagrid, self);
  $(datagrid)[0].onExportedCB = onExported.bind(datagrid, self);
  $(datagrid)[0].onEditorPreparingCB = onEditorPreparing.bind(datagrid, self);
  $(datagrid)[0].onOptionChangedCB = onOptionChanged.bind(datagrid, self);
  $(datagrid)[0].onToolbarPreparingCB = onToolbarPreparing.bind(datagrid, self);
  $(datagrid)[0].onEditingStartCB = onEditingStart.bind(datagrid, self);
  $(datagrid)[0].onInitializedCB = onInitializedCallback.bind(datagrid, self);
  $(datagrid)[0].customizeColumnsCB = customizeColumns.bind(self, datagrid);

  $(datagrid)[0].loadJSONData = loadData.bind(self, datagrid);
  //$(datagrid)[0].handleRemoteDataLoad = loadData.bind(self, datagrid);
  //$(datagrid)[0].totalCountCB = handleTotalCount.bind(self, datagrid);

  datagrid.disableButton("delete-selected", false);

  function customizeColumns(self, columns) {
    console.log("customizeColumns", arguments);
  }

  function onInitializedCallback(self) {
    console.log("onInitializedCallback", arguments);
  }

  function onEditingStart(self) {
    console.log("onEditingStart", arguments);
  }

  function onToolbarPreparing(self) {
    console.log("onToolbarPreparing", arguments);
  }

  function onOptionChanged(self) {
    console.log("onOptionChanged", arguments);
  }

  function customizeExportData(self, data, rowsData) {
    console.log("customizeExportData", arguments);
  }

  function onExportingData(self) {
    console.log("onExportingCB", arguments);
  }

  function onExported(self) {
    console.log("onExported", arguments);
  }

  function onEditorPreparing(self) {
    console.log("onEditorPreparingCallback", arguments);
  }

  function handleRowInserting(self) {
    console.log("handleRowInserting", arguments);
  }

  function handleRowUpdating(self) {
    console.log("handleRowUpdating", arguments);
  }

  function handleRowRemoving(self) {
    console.log("handleRowRemoving", arguments);
  }

  function onRowSelected(self) {
    console.log("onRowSelected", arguments);
  }

  function onPageChanged(self) {
    console.log("onPageChanged", arguments);
  }

  function onRowMultiSelected(self) {
    console.log("onRowMultiSelected", arguments);
  }

  function cellTemplate(self) {
    console.log("cellTemplate", arguments);
  }

  function onRowPrepared(self) {
    //console.log('onRowPrepared', arguments);
  }

  function onCellPrepared(self) {
    //console.log('onCellPrepared', arguments);
  }

  function onEditorPrepared(self) {
    //console.log('onEditorPrepared', arguments);
  }

  function onInitNewRow(self) {
    console.log("onInitNewRowCB", arguments);
  }

  function onGridLoaded(self) {
    //console.log('onGridLoaded', arguments);
  }

  function toolbarItemClicked(self, action) {
    debugger;
    if (action === "sendTo") {
      //self.gridInstance.getRowIndexByKey(self.gridInstance.getSelectedRowsData()[0])
      if (!!this.gridInstance.getSelectedRowsData().length) {
        var selectedRowsLength = this.gridInstance.getSelectedRowsData().length;
        $(".editor-panel").css("display", "block");
        for (var i = 0; i < selectedRowsLength; i++) {}
      }
    } else if (action === "save") {
      $(".editor-panel").css("display", "none");
    }
    console.log("toolbarItemClicked", arguments);
  }

  function handleTotalCount(self, dfd) {
    console.log("handleTotalCount");
    //var dfd = $.Deferred();
    dfd.resolve(12);
    //return dfd;
  }
});
